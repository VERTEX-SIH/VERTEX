import json
import logging
import httpx

from google import genai
from pydantic import ValidationError

from config import settings
from models.hotspot import FIRMSHotspot
from models.classification import (
    OSMContext,
    ClassificationResult,
    ClassificationEnum,
)

logger = logging.getLogger(__name__)


# =========================================================
# GEMINI CLIENT
# =========================================================

# Your config.py already loads backend/.env through Pydantic
# Settings, so use settings.GEMINI_API_KEY directly.
client = genai.Client(
    api_key=settings.GEMINI_API_KEY
)


# =========================================================
# HTTPX SSL PATCH
# =========================================================

# Keep the existing Windows SSL workaround used by VERTEX.
_original_client_init = httpx.Client.__init__


def _patched_client_init(
    self,
    *args,
    **kwargs,
):
    kwargs["verify"] = False
    _original_client_init(
        self,
        *args,
        **kwargs,
    )


httpx.Client.__init__ = _patched_client_init


# =========================================================
# CLASSIFICATION
# =========================================================

async def classify_with_gemini(
    hotspot: FIRMSHotspot,
    osm_context: OSMContext,
) -> ClassificationResult:

    nearby_facilities = (
        osm_context.nearby_facilities
        or []
    )

    facility_lines = []

    for facility in nearby_facilities[:5]:
        name = facility.get(
            "name",
            "Unknown Facility",
        )

        facility_type = facility.get(
            "type",
            "industrial",
        )

        distance = facility.get(
            "distance_m",
            facility.get(
                "distance_meters",
                0,
            ),
        )

        facility_lines.append(
            f"- {name} | "
            f"type={facility_type} | "
            f"distance={distance} m"
        )

    if not facility_lines:
        facility_lines.append(
            "- No nearby structured facility found."
        )

    facility_context = "\n".join(
        facility_lines
    )

    prompt = f"""
You are VERTEX-CLF, an AI system for classifying
satellite-detected thermal anomalies in India.

Classify the following FIRMS thermal anomaly into
exactly ONE of these categories:

INDUSTRIAL_FIRE
PERSISTENT_INDUSTRIAL_SOURCE
GAS_FLARE
WILDFIRE_FOREST_FIRE
AGRICULTURAL_BURN
MINING_THERMAL_ACTIVITY
OTHER_THERMAL_ANOMALY
UNKNOWN_UNCERTAIN

Do NOT assume every thermal anomaly is a fire.

Industrial infrastructure can produce genuine thermal
signatures without representing an abnormal fire.

Use the FIRMS measurements together with OSM/facility
context.

The facility NAME is important contextual evidence.

A nearby facility does NOT automatically mean
INDUSTRIAL_FIRE.

--------------------------------------------------
FIRMS SENSOR DATA
--------------------------------------------------

Latitude:
{hotspot.latitude}

Longitude:
{hotspot.longitude}

FRP:
{hotspot.frp} MW

Brightness:
{hotspot.brightness} K

Brightness T31:
{hotspot.bright_t31} K

Confidence:
{hotspot.confidence}

Day/Night:
{hotspot.daynight}

Acquisition:
{hotspot.acq_date} {hotspot.acq_time}

Satellite:
{hotspot.satellite}

Instrument:
{hotspot.instrument}

--------------------------------------------------
OSM / INDUSTRIAL CONTEXT
--------------------------------------------------

OSM source:
{osm_context.osm_source}

Nearest facility type:
{osm_context.nearest_facility_type}

Nearest facility distance:
{osm_context.nearest_facility_distance} m

Total facilities in radius:
{osm_context.facility_count_in_radius}

Nearby facilities:

{facility_context}

Land-use context:
{osm_context.land_use_context}

--------------------------------------------------
CLASSIFICATION GUIDANCE
--------------------------------------------------

INDUSTRIAL_FIRE:
Use when the anomaly is associated with an industrial
facility and the thermal evidence is more consistent
with an abnormal fire event.

PERSISTENT_INDUSTRIAL_SOURCE:
Use when the anomaly appears consistent with recurring
or routine industrial thermal activity.

GAS_FLARE:
Use when evidence suggests gas flaring or routine
combustion.

WILDFIRE_FOREST_FIRE:
Use when surrounding context and thermal characteristics
suggest vegetation or forest burning.

AGRICULTURAL_BURN:
Use when evidence suggests crop or agricultural burning.

MINING_THERMAL_ACTIVITY:
Use when the anomaly is associated with mining or
extraction activity.

OTHER_THERMAL_ANOMALY:
Use when the anomaly is real but does not fit the above
categories well.

UNKNOWN_UNCERTAIN:
Use when the available evidence is insufficient.

--------------------------------------------------
RISK
--------------------------------------------------

Also return:

confidence_score:
0.0 to 1.0

risk_score:
0.0 to 1.0

risk_level:
LOW
MODERATE
HIGH
CRITICAL

--------------------------------------------------
OUTPUT
--------------------------------------------------

Return JSON ONLY.

Schema:

{{
  "classification": "ONE_ENUM_VALUE",
  "confidence_score": 0.0,
  "risk_score": 0.0,
  "risk_level": "LOW",
  "explanation": "Evidence-based explanation.",
  "evidence": [
    "Evidence 1",
    "Evidence 2",
    "Evidence 3"
  ],
  "source_data": {{
    "model": "gemini-3.5-flash-lite"
  }}
}}
"""

    try:

        response = await client.aio.models.generate_content(
            model="gemini-3.5-flash-lite",
            contents=prompt,
            config={
                "response_mime_type": "application/json",
                "temperature": 0.1,
            },
        )

        raw = (
            response.text
            or ""
        ).strip()

        logger.info(
            "Gemini response received for "
            "%.6f, %.6f",
            hotspot.latitude,
            hotspot.longitude,
        )

        data = json.loads(raw)

        classification_value = data.get(
            "classification",
            ClassificationEnum.UNKNOWN_UNCERTAIN.value,
        )

        try:
            classification = ClassificationEnum(
                classification_value
            )
        except ValueError:
            logger.warning(
                "Invalid Gemini classification: %s",
                classification_value,
            )

            classification = (
                ClassificationEnum
                .UNKNOWN_UNCERTAIN
            )

        confidence = float(
            data.get(
                "confidence_score",
                0.5,
            )
        )

        risk_score = float(
            data.get(
                "risk_score",
                0.0,
            )
        )

        risk_level = str(
            data.get(
                "risk_level",
                "LOW",
            )
        ).upper()

        explanation = str(
            data.get(
                "explanation",
                "No explanation returned.",
            )
        )

        evidence = data.get(
            "evidence",
            [],
        )

        if not isinstance(
            evidence,
            list,
        ):
            evidence = [
                str(evidence)
            ]

        source_data = data.get(
            "source_data",
            {},
        )

        if not isinstance(
            source_data,
            dict,
        ):
            source_data = {}

        source_data["model"] = (
            "gemini-3.5-flash-lite"
        )

        source_data[
            "osm_source"
        ] = (
            osm_context.osm_source
        )

        source_data[
            "facility_context"
        ] = nearby_facilities

        return ClassificationResult(
            classification=classification,
            confidence_score=max(
                0.0,
                min(
                    1.0,
                    confidence,
                ),
            ),
            explanation=explanation,
            evidence=evidence,
            source_data=source_data,
            risk_score=max(
                0.0,
                min(
                    1.0,
                    risk_score,
                ),
            ),
            risk_level=risk_level,
        )

    except json.JSONDecodeError as exc:

        logger.error(
            "Gemini returned invalid JSON: %s",
            exc,
        )

        return ClassificationResult(
            classification=(
                ClassificationEnum
                .UNKNOWN_UNCERTAIN
            ),
            confidence_score=0.1,
            explanation=(
                "Gemini returned an invalid "
                "classification response."
            ),
            evidence=[
                "Gemini response could not be parsed."
            ],
            source_data={
                "error": str(exc),
                "model": (
                    "gemini-3.5-flash-lite"
                ),
            },
            risk_score=0.1,
            risk_level="LOW",
        )

    except Exception as exc:

        logger.error(
            "Gemini classification error: %s",
            exc,
            exc_info=True,
        )

        return ClassificationResult(
            classification=(
                ClassificationEnum
                .UNKNOWN_UNCERTAIN
            ),
            confidence_score=0.1,
            explanation=(
                f"Error calling Gemini: {exc}"
            ),
            evidence=[
                "Gemini classification request failed."
            ],
            source_data={
                "error": str(exc),
                "model": (
                    "gemini-3.5-flash-lite"
                ),
            },
            risk_score=0.1,
            risk_level="LOW",
        )