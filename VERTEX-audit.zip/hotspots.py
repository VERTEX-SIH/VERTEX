from fastapi import (
    APIRouter,
    Query,
    BackgroundTasks,
    HTTPException,
    Request,
    Depends,
)

from typing import (
    List,
    Dict,
    Any,
    Optional,
)

import logging

from services.classifier import classify_and_store
from db.supabase_client import supabase_service
from limiter import limiter
from core.security import verify_admin_user


logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/hotspots",
    tags=["Hotspots"],
)


# =========================================================
# MODULE CACHE
# =========================================================

latest_results = []


# =========================================================
# HELPERS
# =========================================================

def _coordinate_key(
    latitude: Any,
    longitude: Any,
) -> Optional[str]:
    """
    Create a stable coordinate key.

    The OSM cache is fundamentally keyed by hotspot
    coordinates, so this allows /classified to merge
    persistent OSM cache data back into hotspot results.
    """

    try:
        lat = float(latitude)
        lon = float(longitude)

        return f"{lat:.6f},{lon:.6f}"

    except (
        TypeError,
        ValueError,
    ):
        return None


def _normalize_osm_context(
    data: Any,
) -> Dict[str, Any]:
    """
    Normalize any stored OSM context into the structure
    expected by the frontend.
    """

    if not isinstance(data, dict):
        data = {}


    nearby_facilities = (
        data.get("nearby_facilities")
        or []
    )


    land_use_context = (
        data.get("land_use_context")
        or []
    )


    facility_count = (
        data.get("facility_count_in_radius")
    )


    if facility_count is None:
        facility_count = len(
            nearby_facilities
        )


    return {
        "nearby_facilities":
            nearby_facilities,

        "nearest_facility_distance":
            data.get(
                "nearest_facility_distance"
            ),

        "nearest_facility_type":
            data.get(
                "nearest_facility_type"
            ),

        "facility_count_in_radius":
            facility_count,

        "land_use_context":
            land_use_context,

        "osm_source":
            data.get(
                "osm_source",
                "PENDING",
            ),

        "queried_at":
            data.get(
                "queried_at"
            ),
    }


def _load_osm_cache() -> Dict[str, Dict[str, Any]]:
    """
    Load the persistent OSM cache once and index it by
    latitude/longitude.

    This is deliberately done as ONE Supabase query instead
    of querying the cache separately for every hotspot.

    Cache key:

        latitude + longitude

    The most recently queried cache row wins.
    """

    cache_by_coordinate: Dict[
        str,
        Dict[str, Any]
    ] = {}


    try:

        result = (
            supabase_service
            .table("osm_context_cache")
            .select("*")
            .order(
                "queried_at",
                desc=True,
            )
            .execute()
        )


        rows = (
            result.data
            or []
        )


        for row in rows:

            if not isinstance(
                row,
                dict,
            ):
                continue


            key = _coordinate_key(
                row.get("latitude"),
                row.get("longitude"),
            )


            if not key:
                continue


            # Because the query is ordered newest first,
            # don't overwrite an already indexed row.
            if key in cache_by_coordinate:
                continue


            context = _normalize_osm_context(
                row
            )


            # The cache row itself represents persisted
            # OSM knowledge. The original source is kept
            # as LIVE/OFFLINE_CATALOG etc. in the database,
            # but the frontend should know this result came
            # from the persistent cache.
            original_source = (
                context.get("osm_source")
            )


            if original_source in (
                "LIVE",
                "LIVE_NO_FACILITY",
                "OFFLINE_CATALOG",
            ):
                context["osm_source"] = (
                    "CACHED"
                    if context[
                        "facility_count_in_radius"
                    ] > 0
                    else "CACHED_NO_FACILITY"
                )


            cache_by_coordinate[key] = context


        logger.info(
            "Loaded %d persistent OSM cache entries",
            len(cache_by_coordinate),
        )


    except Exception as e:

        logger.warning(
            "Could not load persistent OSM cache: %s",
            e,
        )


    return cache_by_coordinate


def _select_primary_classification(
    class_data: Any,
) -> Dict[str, Any]:
    """
    Select the newest classification record.
    """

    if not isinstance(
        class_data,
        list,
    ):
        return {}


    valid = [
        item
        for item in class_data
        if isinstance(
            item,
            dict,
        )
    ]


    if not valid:
        return {}


    valid.sort(
        key=lambda x:
            x.get(
                "created_at",
                x.get(
                    "classified_at",
                    "",
                ),
            )
            or "",
        reverse=True,
    )


    return valid[0]


def _select_legacy_osm_context(
    stored_contexts: Any,
) -> Dict[str, Any]:
    """
    Select the newest context from the legacy
    osm_contexts table.
    """

    if not isinstance(
        stored_contexts,
        list,
    ):
        return {}


    valid = [
        item
        for item in stored_contexts
        if isinstance(
            item,
            dict,
        )
    ]


    if not valid:
        return {}


    valid.sort(
        key=lambda x:
            x.get(
                "id",
                0,
            )
            or 0,
        reverse=True,
    )


    row = valid[0]


    data = (
        row.get(
            "data",
            {},
        )
        or {}
    )


    if not isinstance(
        data,
        dict,
    ):
        data = {}


    data = dict(
        data
    )


    data.setdefault(
        "facility_count_in_radius",
        row.get(
            "facility_count_in_radius",
            0,
        ),
    )


    return _normalize_osm_context(
        data
    )


# =========================================================
# CLASSIFIED HOTSPOTS
# =========================================================

@router.get("/classified")
@limiter.limit("60/minute")
async def get_classified_hotspots(
    request: Request,
    country: str = Query("IND"),
    days: int = Query(1),
    classification: Optional[str] = None,
    min_frp: Optional[float] = None,
    max_frp: Optional[float] = None,
    min_confidence: Optional[str] = None,
    risk_level: Optional[str] = None,
    limit: int = Query(
        500,
        le=1000,
    ),
):

    try:

        # =================================================
        # LOAD HOTSPOTS
        # =================================================

        query = (
            supabase_service
            .table("hotspots")
            .select(
                "*, classifications(*), osm_contexts(*)"
            )
            .order(
                "created_at",
                desc=True,
            )
        )


        # =================================================
        # FRP FILTERS
        # =================================================

        if min_frp is not None:

            query = query.gte(
                "frp",
                min_frp,
            )


        if max_frp is not None:

            query = query.lte(
                "frp",
                max_frp,
            )


        # =================================================
        # EXECUTE HOTSPOT QUERY
        # =================================================

        res = query.execute()

        records = (
            res.data
            or []
        )


        # =================================================
        # LOAD PERSISTENT OSM CACHE
        # =================================================
        #
        # THIS WAS THE MISSING PIECE.
        #
        # We now load osm_context_cache once and merge
        # it into the returned hotspot data using
        # latitude/longitude.
        #
        # This means:
        #
        # Supabase cache
        #      ↓
        # /classified
        #      ↓
        # frontend
        #
        # instead of:
        #
        # Supabase cache
        #      ↓
        # ignored
        #      ↓
        # PENDING
        #

        osm_cache = (
            _load_osm_cache()
        )


        # =================================================
        # BUILD GEOJSON
        # =================================================

        features = []


        for r in records:

            if not isinstance(
                r,
                dict,
            ):
                continue


            # =================================================
            # CLASSIFICATION
            # =================================================

            class_data = (
                r.get(
                    "classifications",
                    [],
                )
                or []
            )


            primary_class = (
                _select_primary_classification(
                    class_data
                )
            )


            # =================================================
            # EXISTING / LEGACY OSM CONTEXT
            # =================================================

            primary_osm: Dict[
                str,
                Any
            ] = {}


            # First try classification.osm_context

            classification_osm = primary_class.get("osm_context")


            if isinstance(
                classification_osm,
                dict,
            ) and classification_osm:

                primary_osm = (
                    _normalize_osm_context(
                        classification_osm
                    )
                )


            # Second try legacy osm_contexts

            if not primary_osm:

                primary_osm = (
                    _select_legacy_osm_context(
                        r.get(
                            "osm_contexts",
                            [],
                        )
                    )
                )


            # =================================================
            # PERSISTENT OSM CACHE
            # =================================================
            #
            # CACHE TAKES PRIORITY over old classification
            # context because it is the persistent enrichment
            # source we just built.
            #

            cache_key = _coordinate_key(
                r.get("latitude"),
                r.get("longitude"),
            )


            cached_osm = (
                osm_cache.get(
                    cache_key
                )
                if cache_key
                else None
            )


            if cached_osm:

                primary_osm = (
                    cached_osm
                )


            # =================================================
            # NORMALIZE FINAL OSM CONTEXT
            # =================================================

            if not primary_osm:

                primary_osm = {
                    "nearby_facilities": [],
                    "nearest_facility_distance": None,
                    "nearest_facility_type": None,
                    "facility_count_in_radius": 0,
                    "land_use_context": [],
                    "osm_source": "PENDING",
                    "queried_at": None,
                }

            else:

                primary_osm = (
                    _normalize_osm_context(
                        primary_osm
                    )
                )


            # =================================================
            # CLASSIFICATION FILTER
            # =================================================

            if (
                classification
                and primary_class.get(
                    "classification"
                ) != classification
            ):
                continue


            # =================================================
            # RISK FILTER
            # =================================================

            if (
                risk_level
                and primary_class.get(
                    "risk_level"
                ) != risk_level
            ):
                continue


            # =================================================
            # CONFIDENCE FILTER
            # =================================================

            if min_confidence is not None:

                try:

                    confidence_value = float(
                        primary_class.get(
                            "confidence_score",
                            0,
                        )
                        or 0
                    )


                    requested_confidence = float(
                        min_confidence
                    )


                    if (
                        confidence_value
                        < requested_confidence
                    ):
                        continue

                except (
                    TypeError,
                    ValueError,
                ):

                    pass


            # =================================================
            # BUILD FEATURE
            # =================================================

            feature_id = r.get(
                "id"
            )


            latitude = (
                r.get(
                    "latitude",
                    0,
                )
                or 0
            )


            longitude = (
                r.get(
                    "longitude",
                    0,
                )
                or 0
            )


            features.append({

                "type":
                    "Feature",


                "id":
                    feature_id,


                "geometry": {

                    "type":
                        "Point",

                    "coordinates": [
                        longitude,
                        latitude,
                    ],
                },


                "properties": {

                    "hotspot":
                        r,


                    "classification":
                        primary_class,


                    "osm_context":
                        primary_osm,
                },
            })


            # =================================================
            # LIMIT
            # =================================================

            if len(features) >= limit:

                break


        # =================================================
        # RESPONSE
        # =================================================

        logger.info(
            "Returning %d classified hotspots "
            "with %d persistent OSM cache entries available",
            len(features),
            len(osm_cache),
        )


        return {

            "type":
                "FeatureCollection",

            "features":
                features,
        }


    except Exception as e:

        logger.error(
            "Database connection failed: %s",
            e,
            exc_info=True,
        )


        raise HTTPException(
            status_code=503,
            detail=(
                "Database connection failed: "
                f"{str(e)}"
            ),
        )


# =========================================================
# SINGLE HOTSPOT
# =========================================================

@router.get("/{id}")
@limiter.limit("60/minute")
async def get_hotspot_by_id(
    request: Request,
    id: str,
):
    """
    Fetch a single hotspot from Supabase.

    Also attaches the persistent OSM cache when one
    exists for the hotspot coordinates.
    """

    try:

        response = (
            supabase_service
            .table("hotspots")
            .select(
                "*, classifications(*)"
            )
            .eq(
                "id",
                id,
            )
            .single()
            .execute()
        )


        if not response.data:

            raise HTTPException(
                status_code=404,
                detail="Hotspot not found",
            )


        hotspot = (
            response.data
        )


        # -------------------------------------------------
        # Persistent OSM cache
        # -------------------------------------------------

        cache_key = _coordinate_key(
            hotspot.get("latitude"),
            hotspot.get("longitude"),
        )


        if cache_key:

            try:

                cache_result = (
                    supabase_service
                    .table(
                        "osm_context_cache"
                    )
                    .select("*")
                    .eq(
                        "latitude",
                        hotspot.get(
                            "latitude"
                        ),
                    )
                    .eq(
                        "longitude",
                        hotspot.get(
                            "longitude"
                        ),
                    )
                    .order(
                        "queried_at",
                        desc=True,
                    )
                    .limit(1)
                    .execute()
                )


                cache_rows = (
                    cache_result.data
                    or []
                )


                if cache_rows:

                    hotspot[
                        "osm_context"
                    ] = _normalize_osm_context(
                        cache_rows[0]
                    )

            except Exception as cache_error:

                logger.warning(
                    "Could not load OSM cache "
                    "for hotspot %s: %s",
                    id,
                    cache_error,
                )


        return hotspot


    except HTTPException:
        raise


    except Exception as e:

        logger.error(
            "Error fetching hotspot %s: %s",
            id,
            e,
        )


        raise HTTPException(
            status_code=500,
            detail=str(e),
        )


# =========================================================
# TRIGGER CLASSIFICATION
# =========================================================

@router.post("/classify")
@limiter.limit("5/minute")
async def trigger_classification(
    request: Request,
    background_tasks: BackgroundTasks,
    country: str = Query("IND"),
    days: int = Query(1),
    admin_user: Any = Depends(
        verify_admin_user
    ),
):
    """
    Triggers the classification pipeline as a
    background task.
    """

    background_tasks.add_task(
        classify_and_store,
        country,
        days,
    )


    return {
        "message":
            "Classification pipeline started"
    }


# =========================================================
# SWEEP PENDING
# =========================================================

@router.post("/sweep_pending")
async def sweep_pending_records():

    res = (
        supabase_service
        .table(
            "classifications"
        )
        .select("*")
        .limit(1)
        .execute()
    )


    if res.data:

        keys = list(
            res.data[0].keys()
        )


        return {
            "keys":
                keys
        }


    return {
        "message":
            "No data"
    }