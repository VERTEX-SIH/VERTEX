import base64
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

import httpx

from config import settings

logger = logging.getLogger(__name__)

TOKEN_URL = "https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token"
PROCESS_URL = "https://sh.dataspace.copernicus.eu/process/v1"

TRUE_COLOR_EVALSCRIPT = """
//VERSION=3
function setup() {
  return {
    input: ["B02", "B03", "B04"],
    output: {
      bands: 3,
      sampleType: "AUTO"
    }
  };
}
function evaluatePixel(sample) {
  return [2.5 * sample.B04, 2.5 * sample.B03, 2.5 * sample.B02];
}
"""


async def _get_access_token() -> Optional[str]:
    if not settings.CDSE_CLIENT_ID or not settings.CDSE_CLIENT_SECRET:
        logger.warning("CDSE credentials are not configured")
        return None

    data = {
        "grant_type": "client_credentials",
        "client_id": settings.CDSE_CLIENT_ID,
        "client_secret": settings.CDSE_CLIENT_SECRET,
    }

    try:
        async with httpx.AsyncClient(verify=False, timeout=20.0) as client:
            response = await client.post(TOKEN_URL, data=data)
            response.raise_for_status()
            payload = response.json()
            return payload.get("access_token")
    except Exception as exc:
        logger.error("CDSE token request failed: %s", exc)
        return None


def _parse_observation_datetime(acq_date: Any, acq_time: Any) -> datetime:
    date_text = str(acq_date or "").strip()[:10]
    time_text = str(acq_time or "").strip().zfill(4)[:4]
    try:
        hour = int(time_text[:2])
        minute = int(time_text[2:])
    except (ValueError, TypeError):
        hour, minute = 0, 0
    try:
        parsed = datetime.fromisoformat(date_text)
    except ValueError:
        parsed = datetime.now(timezone.utc).replace(tzinfo=None)
    return parsed.replace(hour=hour, minute=minute, second=0, microsecond=0, tzinfo=timezone.utc)


async def fetch_satellite_evidence(
    latitude: float,
    longitude: float,
    acq_date: Any,
    acq_time: Any,
    size_degrees: float = 0.012,
    width: int = 512,
    height: int = 512,
) -> Optional[Dict[str, Any]]:
    """Return a small recent Sentinel-2 L2A true-colour chip around a hotspot."""
    token = await _get_access_token()
    if not token:
        return None

    observation_time = _parse_observation_datetime(acq_date, acq_time)
    start = observation_time - timedelta(days=30)
    end = observation_time + timedelta(days=7)

    bbox = [
        float(longitude) - size_degrees,
        float(latitude) - size_degrees,
        float(longitude) + size_degrees,
        float(latitude) + size_degrees,
    ]

    payload = {
        "input": {
            "bounds": {
                "bbox": bbox,
                "properties": {
                    "crs": "http://www.opengis.net/def/crs/OGC/1.3/CRS84"
                },
            },
            "data": [
                {
                    "type": "sentinel-2-l2a",
                    "dataFilter": {
                        "timeRange": {
                            "from": start.isoformat().replace("+00:00", "Z"),
                            "to": end.isoformat().replace("+00:00", "Z"),
                        },
                        "mosaickingOrder": "leastCC",
                    },
                }
            ],
        },
        "output": {
            "width": width,
            "height": height,
            "responses": [
                {
                    "identifier": "default",
                    "format": {"type": "image/jpeg", "quality": 85},
                }
            ],
        },
        "evalscript": TRUE_COLOR_EVALSCRIPT,
    }

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }

    try:
        async with httpx.AsyncClient(verify=False, timeout=45.0) as client:
            response = await client.post(PROCESS_URL, json=payload, headers=headers)
            response.raise_for_status()
            image_bytes = response.content

        return {
            "available": True,
            "source": "Copernicus Data Space Ecosystem",
            "collection": "Sentinel-2 L2A",
            "product_type": "true_color",
            "observation_window_start": start.isoformat(),
            "observation_window_end": end.isoformat(),
            "hotspot_latitude": float(latitude),
            "hotspot_longitude": float(longitude),
            "bbox": bbox,
            "mime_type": "image/jpeg",
            "image_base64": base64.b64encode(image_bytes).decode("ascii"),
            "image_data_url": "data:image/jpeg;base64," + base64.b64encode(image_bytes).decode("ascii"),
        }
    except httpx.HTTPStatusError as exc:
        detail = exc.response.text[:500]
        logger.warning("CDSE Process API failed (%s): %s", exc.response.status_code, detail)
        return None
    except Exception as exc:
        logger.warning("Satellite evidence request failed: %s", exc)
        return None


async def fetch_satellite_image_bytes(
    latitude: float,
    longitude: float,
    acq_date: Any,
    acq_time: Any,
) -> Optional[bytes]:
    evidence = await fetch_satellite_evidence(latitude, longitude, acq_date, acq_time)
    if not evidence or not evidence.get("image_base64"):
        return None
    return base64.b64decode(evidence["image_base64"])
