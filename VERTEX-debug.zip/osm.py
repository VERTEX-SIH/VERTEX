from fastapi import APIRouter, Query, HTTPException
from services.osm_service import enrich_hotspot
from db.supabase_client import supabase_service
from models.hotspot import FIRMSHotspot
import asyncio
import logging

from services.facility_service import (
    find_nearby_facilities,
    invalidate_facility_cache,
)
from services.osm_service import query_overpass
from models.classification import OSMContext
from services.classifier import (
    classification_payload_for,
    classify_hotspot_with_context,
)


logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/osm",
    tags=["OpenStreetMap"],
)


# =========================================================
# INDUSTRIAL CONTEXT
# =========================================================

@router.get("/industrial")
async def get_industrial(
    lat: float = Query(...),
    lon: float = Query(...),
    radius: int = Query(5000),
):
    """Return industrial context for the requested coordinate."""

    context = await enrich_hotspot(
        FIRMSHotspot(
            latitude=lat,
            longitude=lon,
        ),
        force_refresh=False,
    )

    return {
        "facilities": context.nearby_facilities,
        "source": context.osm_source,
        "osm_source": context.osm_source,
        "query_status": "SUCCESS",
    }


# =========================================================
# FACILITY CATALOG CACHE
# =========================================================

@router.post("/facility-catalog/cache/refresh")
async def refresh_facility_catalog_cache():
    """Invalidate the in-process catalog cache."""

    invalidate_facility_cache()

    return {
        "status": "INVALIDATED"
    }


# =========================================================
# OSM HEALTH
# =========================================================

@router.get("/health")
async def check_osm_health():
    """
    Since we are using local india_industrial_facilities.json,
    we don't need to ping Overpass.
    """

    return {
        "mirrors": [
            {
                "mirror": "local_india_json",
                "status": "UP",
                "latency_s": 0.0,
            }
        ]
    }


# =========================================================
# TOP 50 ENRICHMENT
# IMPORTANT:
# This route MUST appear before /enrich/{hotspot_id}
# =========================================================

@router.post("/enrich/top50")
async def enrich_top50():
    """
    Enrich the current top 50 hotspots by FRP.

    The persistent OSM cache is handled by enrich_hotspot().
    Cached coordinates are reused automatically; missing or
    refreshed contexts are obtained through the OSM service.
    """

    try:
        response = (
            supabase_service
            .table("hotspots")
            .select("*")
            .order("frp", desc=True)
            .limit(50)
            .execute()
        )

        rows = response.data or []

    except Exception as e:
        logger.error(
            f"Error fetching top 50 hotspots: {e}"
        )
        raise HTTPException(
            status_code=500,
            detail="Database error while fetching top 50 hotspots",
        )

    if not rows:
        return {
            "status": "NO_HOTSPOTS",
            "count": 0,
            "results": [],
        }

    results = []

    # Keep concurrency controlled so a top-50 refresh does not
    # hammer Overpass or Supabase with 50 simultaneous requests.
    semaphore = asyncio.Semaphore(5)

    async def enrich_one(row):
        hotspot_id = row.get("id")

        try:
            hotspot = FIRMSHotspot(**row)

            async with semaphore:
                context = await asyncio.wait_for(
                    enrich_hotspot(
                        hotspot,
                        existing_context=None,
                        force_refresh=False,
                        hotspot_id=int(hotspot_id),
                    ),
                    timeout=20.0,
                )

            return {
                "hotspot_id": hotspot_id,
                "status": "SUCCESS",
                "osm_source": context.osm_source,
                "facility_count": (
                    context.facility_count_in_radius
                ),
                "nearby_facilities": (
                    context.nearby_facilities
                ),
            }

        except asyncio.TimeoutError:
            logger.warning(
                f"Top50 OSM enrichment timed out "
                f"for hotspot {hotspot_id}"
            )

            return {
                "hotspot_id": hotspot_id,
                "status": "TIMEOUT",
            }

        except Exception as e:
            logger.error(
                f"Top50 OSM enrichment failed "
                f"for hotspot {hotspot_id}: {e}"
            )

            return {
                "hotspot_id": hotspot_id,
                "status": "FAILED",
                "error": str(e),
            }

    results = await asyncio.gather(
        *(enrich_one(row) for row in rows)
    )

    successful = sum(
        1
        for result in results
        if result["status"] == "SUCCESS"
    )

    failed = sum(
        1
        for result in results
        if result["status"] == "FAILED"
    )

    timed_out = sum(
        1
        for result in results
        if result["status"] == "TIMEOUT"
    )

    return {
        "status": "COMPLETED",
        "count": len(results),
        "successful": successful,
        "failed": failed,
        "timed_out": timed_out,
        "results": results,
    }


# =========================================================
# SINGLE HOTSPOT ENRICHMENT
# IMPORTANT:
# This dynamic route comes AFTER /enrich/top50.
# =========================================================

@router.post("/enrich/{hotspot_id}")
async def manual_enrich_hotspot(
    hotspot_id: str,
    force: bool = Query(False),
):
    """
    Explicitly trigger OSM enrichment for a single hotspot.

    force=false:
        Reuse persistent OSM cache when available.

    force=true:
        Bypass the existing cache and refresh OSM context.
    """

    # -----------------------------------------------------
    # FETCH HOTSPOT
    # -----------------------------------------------------

    # Live FIRMS observations use IDs such as:
    # firms-10.236530-79.196130-2026-09-03-0852
    # while Supabase hotspots.id is bigint.  Numeric IDs use the
    # persistent hotspot row; FIRMS IDs are enriched directly from
    # their encoded coordinates and use the coordinate OSM cache.
    is_numeric_id = str(hotspot_id).strip().isdigit()
    database_hotspot_id = None

    if is_numeric_id:
        try:
            res = (
                supabase_service
                .table("hotspots")
                .select("*")
                .eq("id", int(hotspot_id))
                .single()
                .execute()
            )

            if not res.data:
                raise HTTPException(
                    status_code=404,
                    detail="Hotspot not found",
                )

            hotspot_data = res.data
            database_hotspot_id = int(hotspot_id)
            hotspot = FIRMSHotspot(**hotspot_data)

        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Error fetching hotspot {hotspot_id}: {e}")
            raise HTTPException(status_code=500, detail="Database error")
    else:
        parts = str(hotspot_id).split("-")
        if len(parts) < 5 or parts[0].lower() != "firms":
            raise HTTPException(status_code=400, detail="Invalid hotspot ID")

        try:
            hotspot = FIRMSHotspot(
                latitude=float(parts[1]),
                longitude=float(parts[2]),
                acq_date=parts[3],
                acq_time=parts[4],
            )
        except (TypeError, ValueError) as e:
            logger.error(f"Invalid FIRMS hotspot ID {hotspot_id}: {e}")
            raise HTTPException(status_code=400, detail="Invalid FIRMS hotspot ID")

    # -----------------------------------------------------
    # LOAD EXISTING OSM CONTEXT
    # -----------------------------------------------------

    try:
        existing_context = None
        existing_classification_id = None

        if database_hotspot_id is not None:
            classifications = (
                supabase_service
                .table("classifications")
                .select("id, osm_context, created_at")
                .eq("hotspot_id", database_hotspot_id)
                .order("created_at", desc=True)
                .limit(1)
                .execute()
                .data
                or []
            )

            existing_data = (
                classifications[0].get("osm_context")
                if classifications else None
            )
            existing_classification_id = (
                classifications[0].get("id")
                if classifications else None
            )

            if not existing_data:
                stored_contexts = (
                    supabase_service
                    .table("osm_contexts")
                    .select("*")
                    .eq("hotspot_id", database_hotspot_id)
                    .order("id", desc=True)
                    .limit(1)
                    .execute()
                    .data
                    or []
                )

                if stored_contexts:
                    existing_data = stored_contexts[0].get("data", {})
                    existing_data.setdefault(
                        "facility_count_in_radius",
                        stored_contexts[0].get("facility_count_in_radius", 0),
                    )

            if existing_data:
                existing_context = OSMContext(**existing_data)

        osm_context = await asyncio.wait_for(
            enrich_hotspot(
                hotspot,
                existing_context=None if force else existing_context,
                force_refresh=force,
                hotspot_id=database_hotspot_id,
            ),
            timeout=20.0,
        )

    except asyncio.TimeoutError:

        logger.warning(
            f"OSM enrichment timed out "
            f"for hotspot {hotspot_id}"
        )

        raise HTTPException(
            status_code=408,
            detail="OSM enrichment timed out",
        )

    except Exception as e:

        logger.error(
            f"OSM enrichment failed: {e}"
        )

        raise HTTPException(
            status_code=500,
            detail=str(e),
        )

    # -----------------------------------------------------
    # BUILD STORED OSM DATA
    # -----------------------------------------------------

    osm_data = {
        "nearby_facilities":
            osm_context.nearby_facilities,

        "nearest_facility_distance":
            osm_context.nearest_facility_distance,

        "nearest_facility_type":
            osm_context.nearest_facility_type,

        "land_use_context":
            osm_context.land_use_context,

        "osm_source":
            osm_context.osm_source,

        "queried_at":
            osm_context.queried_at,
    }

    # -----------------------------------------------------
    # PERSIST OSM CONTEXT
    # -----------------------------------------------------

    try:
        # enrich_hotspot() already saves the live FIRMS result in the
        # coordinate-based osm_context_cache. Do not write the FIRMS string
        # ID into bigint hotspot_id columns.
        if database_hotspot_id is not None:
            if existing_classification_id:
                if force:
                    # A forced refresh is only useful if Gemini evaluates the
                    # refreshed facility context too.  Update this exact latest
                    # row so historical duplicate rows are never created.
                    classified_hotspot = await classify_hotspot_with_context(
                        hotspot,
                        osm_context,
                    )
                    payload = classification_payload_for(
                        classified_hotspot,
                        database_hotspot_id,
                    )
                    supabase_service.table("classifications").update(
                        payload
                    ).eq("id", existing_classification_id).execute()
                else:
                    supabase_service.table("classifications").update({
                        "osm_context": osm_data
                    }).eq("id", existing_classification_id).execute()
            else:
                existing_context_rows = (
                    supabase_service
                    .table("osm_contexts")
                    .select("id")
                    .eq("hotspot_id", database_hotspot_id)
                    .limit(1)
                    .execute()
                    .data
                    or []
                )

                context_row = {
                    "data": osm_data,
                    "facility_count_in_radius": osm_context.facility_count_in_radius,
                }

                if existing_context_rows:
                    supabase_service.table("osm_contexts").update(context_row).eq(
                        "id", existing_context_rows[0]["id"]
                    ).execute()
                else:
                    supabase_service.table("osm_contexts").insert({
                        "hotspot_id": database_hotspot_id,
                        **context_row,
                    }).execute()

    except Exception as e:
        logger.error(f"Error updating classifications for hotspot {hotspot_id}: {e}")
        raise HTTPException(status_code=500, detail="Error saving facility data")

    return osm_context
