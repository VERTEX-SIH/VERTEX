'use client';

import { useEffect, useState, useMemo, useRef, useCallback } from 'react';
import Map, { Source, Layer, MapRef, Popup, ViewStateChangeEvent } from 'react-map-gl/maplibre';
import 'maplibre-gl/dist/maplibre-gl.css';
import maplibregl from 'maplibre-gl';
import { ClassifiedHotspot, CLASSIFICATION_COLORS, ClassificationType } from '@/types';
import { DEFAULT_CENTER, DEFAULT_ZOOM } from '@/lib/constants';
import { useGlobalState } from '@/lib/GlobalStateContext';
import { FirePopup } from './FirePopup';

interface MapViewProps {
  hotspots: ClassifiedHotspot[];
  selectedHotspot?: ClassifiedHotspot | null;
  onSelectHotspot?: (hotspot: ClassifiedHotspot | null) => void;
  center?: [number, number];
  zoom?: number;
}

export function MapView({ hotspots, selectedHotspot, onSelectHotspot, center = DEFAULT_CENTER, zoom = DEFAULT_ZOOM }: MapViewProps) {
  const { mapStyle, mapCenter: savedCenter, mapZoom: savedZoom, setMapCenter, setMapZoom } = useGlobalState();
  const [mounted, setMounted] = useState(false);
  const mapRef = useRef<MapRef>(null);

  // Track if we just mounted to avoid firing onMoveEnd immediately with defaults
  const isInitialMount = useRef(true);

  // Effective viewport
  const effectiveCenter = savedCenter || center;
  const effectiveZoom = savedZoom || zoom;

  const [viewState, setViewState] = useState({
    longitude: effectiveCenter[0],
    latitude: effectiveCenter[1],
    zoom: effectiveZoom,
  });

  useEffect(() => {
    setMounted(true);
    isInitialMount.current = false;
  }, []);

  // When selectedHotspot changes, fly to it
  useEffect(() => {
    if (selectedHotspot && mapRef.current) {
      mapRef.current.flyTo({
        center: [selectedHotspot.hotspot.longitude, selectedHotspot.hotspot.latitude],
        zoom: 14,
        duration: 1500
      });
    }
  }, [selectedHotspot]);

  const onMoveEnd = useCallback((e: ViewStateChangeEvent) => {
    const { longitude, latitude, zoom } = e.viewState;
    setViewState(e.viewState);
    if (!isInitialMount.current) {
      setMapCenter([longitude, latitude]);
      setMapZoom(zoom);
    }
  }, [setMapCenter, setMapZoom]);

  const onMove = useCallback((e: ViewStateChangeEvent) => {
    setViewState(e.viewState);
  }, []);

  // Prepare GeoJSON Source
  const geojsonData = useMemo(() => {
    return {
      type: 'FeatureCollection' as const,
      features: hotspots.map((h) => {
        const type = h.classification.classification as ClassificationType;
        const color = CLASSIFICATION_COLORS[type] || CLASSIFICATION_COLORS.UNKNOWN_UNCERTAIN;
        const isPending = type === ClassificationType.UNCLASSIFIED;
        const isHighRisk = h.classification.risk_level?.toUpperCase() === 'HIGH' || (h.classification.risk_score && h.classification.risk_score >= 70);
        
        return {
          type: 'Feature' as const,
          geometry: {
            type: 'Point' as const,
            coordinates: [h.hotspot.longitude, h.hotspot.latitude]
          },
          properties: {
            id: h.id,
            type,
            isPending,
            isHighRisk,
            color
          }
        };
      })
    };
  }, [hotspots]);

  // Handle Clicking on Map
  const onClick = useCallback((event: any) => {
    const feature = event.features?.[0];
    if (!feature) {
      if (onSelectHotspot) onSelectHotspot(null as any);
      return;
    }

    if (feature.layer.id === 'clusters') {
      const clusterId = feature.properties.cluster_id;
      const mapboxMap = mapRef.current?.getMap();
      if (!mapboxMap) return;
      
      const mapboxSource = mapboxMap.getSource('hotspots') as any;

      if (mapboxSource && mapboxSource.getClusterExpansionZoom) {
        // maplibre-gl v3+ often returns a Promise for getClusterExpansionZoom, or accepts a callback.
        // Let's use the Promise approach which is standard now.
        try {
          mapboxSource.getClusterExpansionZoom(clusterId)
            .then((zoom: number) => {
              mapRef.current?.easeTo({
                center: feature.geometry.coordinates as [number, number],
                zoom: zoom + 1, // Add 1 just to make sure it splits
                duration: 500
              });
            })
            .catch((err: any) => {
              // Fallback to callback if it's an older signature
              mapboxSource.getClusterExpansionZoom(clusterId, (err2: any, zoom2: number) => {
                if (err2) return;
                mapRef.current?.easeTo({
                  center: feature.geometry.coordinates as [number, number],
                  zoom: zoom2 + 1,
                  duration: 500
                });
              });
            });
        } catch (e) {}
      }
    } else if (feature.layer.id === 'unclustered-point') {
      const clickedId = feature.properties.id;
      const h = hotspots.find(hs => hs.id === clickedId);
      if (h && onSelectHotspot) {
        onSelectHotspot(h);
      }
    }
  }, [hotspots, onSelectHotspot]);

  if (!mounted) return null;

  // Determine basemap tiles based on mapStyle
  let tileUrls = ["https://tile.openstreetmap.org/{z}/{x}/{y}.png"];
  let attribution = '&copy; OpenStreetMap contributors';

  if (mapStyle === 'Esri Dark Canvas') {
    tileUrls = ["https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}"];
    attribution = 'Tiles &copy; Esri &mdash; Esri, DeLorme, NAVTEQ';
  } else if (mapStyle === 'Carto Dark') {
    tileUrls = ["https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}"];
    attribution = 'Tiles &copy; Esri &mdash; Esri, DeLorme, NAVTEQ';
  }

  const baseMapStyle = {
    version: 8,
    sources: {
      'osm-tiles': {
        type: 'raster',
        tiles: tileUrls,
        tileSize: 256,
        attribution,
        maxzoom: 19
      }
    },
    layers: [
      {
        id: 'osm-tiles-layer',
        type: 'raster',
        source: 'osm-tiles',
        minzoom: 0,
        maxzoom: 19
      }
    ]
  };

  return (
    <div className="relative w-full h-full overflow-hidden bg-background">
      <Map
        ref={mapRef}
        {...viewState}
        onMove={onMove}
        onMoveEnd={onMoveEnd}
        mapStyle={baseMapStyle as any}
        mapLib={maplibregl}
        interactiveLayerIds={['clusters', 'unclustered-point']}
        onClick={onClick}
        cursor={mounted ? 'pointer' : 'auto'}
        style={{ width: '100%', height: '100%' }}
      >
        <Source
          id="hotspots"
          type="geojson"
          data={geojsonData}
          cluster={true}
          clusterMaxZoom={14}
          clusterRadius={50}
        >
          {/* Clusters */}
          <Layer
            id="clusters"
            type="circle"
            filter={['has', 'point_count']}
            paint={{
              'circle-color': [
                'step',
                ['get', 'point_count'],
                '#51bbd6',
                10,
                '#f1f075',
                50,
                '#f28cb1'
              ],
              'circle-radius': [
                'step',
                ['get', 'point_count'],
                15,
                10,
                20,
                50,
                25
              ],
              'circle-opacity': 0.8,
              'circle-stroke-width': 2,
              'circle-stroke-color': '#ffffff'
            }}
          />

          {/* Cluster Counts */}
          <Layer
            id="cluster-count"
            type="symbol"
            filter={['has', 'point_count']}
            layout={{
              'text-field': '{point_count_abbreviated}',
              'text-font': ['Arial Unicode MS Bold', 'Open Sans Bold', 'sans-serif'],
              'text-size': 12
            }}
            paint={{
              'text-color': '#000000'
            }}
          />

          {/* Individual Points */}
          <Layer
            id="unclustered-point"
            type="circle"
            filter={['!', ['has', 'point_count']]}
            paint={{
              'circle-color': ['get', 'color'],
              'circle-radius': [
                'case',
                ['==', ['get', 'id'], selectedHotspot?.id || ''], 12,
                ['get', 'isHighRisk'], 8,
                ['get', 'isPending'], 4,
                5
              ],
              'circle-opacity': [
                'case',
                ['==', ['get', 'id'], selectedHotspot?.id || ''], 1,
                ['get', 'isHighRisk'], 0.9,
                ['get', 'isPending'], 0.3,
                0.7
              ],
              'circle-stroke-width': [
                'case',
                ['==', ['get', 'id'], selectedHotspot?.id || ''], 3,
                ['get', 'isHighRisk'], 2,
                1
              ],
              'circle-stroke-color': [
                'case',
                ['==', ['get', 'id'], selectedHotspot?.id || ''], '#ffffff',
                ['get', 'isHighRisk'], '#ff0000',
                ['get', 'isPending'], '#555555',
                '#000000'
              ]
            }}
          />
        </Source>

        {/* Selected Popup */}
        {selectedHotspot && (
          <Popup
            longitude={selectedHotspot.hotspot.longitude}
            latitude={selectedHotspot.hotspot.latitude}
            anchor="bottom"
            onClose={() => {
              if (onSelectHotspot) onSelectHotspot(null);
            }}
            closeOnClick={false}
            className="vertex-popup maplibre-popup"
          >
            <FirePopup hotspot={selectedHotspot} />
          </Popup>
        )}
      </Map>
    </div>
  );
}
