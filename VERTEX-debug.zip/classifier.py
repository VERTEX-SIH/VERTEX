import asyncio
import logging
from typing import List, Optional, Dict, Any

from models.hotspot import FIRMSHotspot
from models.classification import (
    ClassifiedHotspot,
    ClassificationResult,
    ClassificationEnum,
    OSMContext,
)
from services.firms_service import fetch_realtime_hotspots
from services.osm_service import enrich_hotspot
from services.gemini_service import classify_with_gemini

logger = logging.getLogger(__name__)


# This bounds the complete enrichment attempt (cache, Overpass mirrors, and
# offline fallback) for one observation.  The classification batch remains
# sequential so public Overpass instances are never burst with requests.
OSM_ENRICHMENT_TIMEOUT_SECONDS = 20.0


def calculate_risk_score(
    classification: ClassificationEnum,
    frp: float,
    dist: Optional[float],
    conf: str,
) -> tuple[float, str]:

    weights = {
        ClassificationEnum.INDUSTRIAL_FIRE: 0.9,
        ClassificationEnum.GAS_FLARE: 0.7,
        ClassificationEnum.WILDFIRE_FOREST_FIRE: 0.6,
        ClassificationEnum.PERSISTENT_INDUSTRIAL_SOURCE: 0.4,
        ClassificationEnum.MINING_THERMAL_ACTIVITY: 0.5,
        ClassificationEnum.AGRICULTURAL_BURN: 0.3,
        ClassificationEnum.OTHER_THERMAL_ANOMALY: 0.2,
        ClassificationEnum.UNKNOWN_UNCERTAIN: 0.1,
        ClassificationEnum.UNKNOWN: 0.1,
    }

    type_weight = weights.get(
        classification,
        0.1,
    )

    frp_norm = min(
        float(frp or 0) / 500.0,
        1.0,
    )

    dist_norm = 0.0

    if dist is not None and dist > 0:
        dist_norm = (
            min(1000.0 / dist, 1.0)
            if dist >= 100
            else 1.0
        )

    conf_score = 0.5

    conf_value = str(
        conf or ""
    ).lower()

    if conf_value in ("h", "high", "100"):
        conf_score = 1.0
    elif conf_value in ("l", "low", "0"):
        conf_score = 0.2

    score = (
        type_weight * 0.4
        + frp_norm * 0.3
        + dist_norm * 0.2
        + conf_score * 0.1
    ) * 100

    if score >= 80:
        return score, "CRITICAL"

    if score >= 60:
        return score, "HIGH"

    if score >= 40:
        return score, "MODERATE"

    return score, "LOW"


def _normalise_datetime(value: Any) -> str:
    if value is None:
        return ""

    return str(value)


def _classification_is_stale(
    classification_record: Dict[str, Any],
) -> bool:
    """
    Decide whether an existing classification should be
    reconsidered because its previous geographic context was
    unavailable or missing.

    We DO NOT automatically reclassify every record.

    Only classifications whose stored OSM context was:
        FAILED
        PENDING
        missing entirely

    are treated as stale.
    """

    osm_context = (
        classification_record.get(
            "osm_context"
        )
    )

    if not osm_context:
        return True

    if not isinstance(
        osm_context,
        dict,
    ):
        return True

    source = str(
        osm_context.get(
            "osm_source",
            "",
        )
    ).upper()

    return source in {
        "",
        "FAILED",
        "PENDING",
    }


def _select_latest_classification(
    records: List[Dict[str, Any]],
) -> Optional[Dict[str, Any]]:
    if not records:
        return None

    def sort_key(record: Dict[str, Any]):
        return (
            _normalise_datetime(
                record.get(
                    "created_at"
                )
            ),
            str(
                record.get(
                    "id",
                    ""
                )
            ),
        )

    return sorted(
        records,
        key=sort_key,
        reverse=True,
    )[0]


def _failed_osm_context() -> OSMContext:
    """Return usable context when enrichment raises or exceeds its budget."""
    return OSMContext(
        nearby_facilities=[],
        nearest_facility_distance=None,
        nearest_facility_type=None,
        facility_count_in_radius=0,
        land_use_context=[],
        osm_source="FAILED",
        queried_at=None,
    )


def _fallback_classification_result() -> ClassificationResult:
    return ClassificationResult(
        classification=ClassificationEnum.UNKNOWN_UNCERTAIN,
        confidence_score=0.1,
        explanation="Gemini did not return a usable classification.",
        evidence=["AI classification result unavailable."],
        risk_score=0.1,
        risk_level="LOW",
        source_data={"method": "fallback"},
    )


async def classify_hotspot_with_context(
    hotspot: FIRMSHotspot,
    osm_context: OSMContext,
) -> ClassifiedHotspot:
    """Run Gemini and attach provenance for an already-enriched hotspot."""
    try:
        classification_result = await classify_with_gemini(hotspot, osm_context)
    except Exception as exc:
        # Gemini normally converts its own failures into a result.  Keep this
        # guard so an unexpected client error never leaves the hotspot pending.
        logger.exception(
            "Unexpected Gemini failure for %.6f, %.6f: %s",
            hotspot.latitude,
            hotspot.longitude,
            exc,
        )
        classification_result = _fallback_classification_result()

    if not classification_result:
        classification_result = _fallback_classification_result()

    if not classification_result.source_data:
        classification_result.source_data = {}

    classification_result.source_data["osm_source"] = osm_context.osm_source
    classification_result.source_data["facility_context"] = {
        "osm_source": osm_context.osm_source,
        "nearby_facilities": osm_context.nearby_facilities,
        "nearest_facility_distance": osm_context.nearest_facility_distance,
        "nearest_facility_type": osm_context.nearest_facility_type,
        "facility_count_in_radius": osm_context.facility_count_in_radius,
        "land_use_context": osm_context.land_use_context,
    }

    if osm_context.nearby_facilities:
        nearest_facility = osm_context.nearby_facilities[0]
        classification_result.source_data["facility_name"] = nearest_facility.get("name")
        classification_result.source_data["facility_type"] = nearest_facility.get("type")
        classification_result.source_data["distance_m"] = nearest_facility.get(
            "distance_m",
            nearest_facility.get("distance_meters"),
        )

    risk_score, risk_level = calculate_risk_score(
        classification_result.classification,
        hotspot.frp,
        osm_context.nearest_facility_distance,
        hotspot.confidence,
    )
    classification_result.risk_score = risk_score
    classification_result.risk_level = risk_level

    return ClassifiedHotspot(
        hotspot=hotspot,
        classification=classification_result,
        osm_context=osm_context,
    )


async def classify_one_hotspot(
    hotspot: FIRMSHotspot,
    *,
    force_osm_refresh: bool = False,
    existing_context: Optional[OSMContext] = None,
    hotspot_id: Optional[int] = None,
) -> ClassifiedHotspot:
    """Bound OSM independently, then always send the observation to Gemini."""
    try:
        osm_context = await asyncio.wait_for(
            enrich_hotspot(
                hotspot,
                existing_context=existing_context,
                force_refresh=force_osm_refresh,
                hotspot_id=hotspot_id,
            ),
            timeout=OSM_ENRICHMENT_TIMEOUT_SECONDS,
        )
    except asyncio.TimeoutError:
        logger.warning(
            "OSM enrichment timed out after %.1fs for %.6f, %.6f; "
            "continuing with failed context.",
            OSM_ENRICHMENT_TIMEOUT_SECONDS,
            hotspot.latitude,
            hotspot.longitude,
        )
        osm_context = _failed_osm_context()
    except Exception as exc:
        logger.exception(
            "OSM enrichment failed for %.6f, %.6f: %s; continuing with "
            "failed context.",
            hotspot.latitude,
            hotspot.longitude,
            exc,
        )
        osm_context = _failed_osm_context()

    return await classify_hotspot_with_context(hotspot, osm_context)


async def classify_hotspots(
    hotspots: List[FIRMSHotspot],
) -> List[ClassifiedHotspot]:
    """Sequential batch helper; failures are isolated to each hotspot."""
    classified_results: List[ClassifiedHotspot] = []

    for hotspot in hotspots:
        if hotspot.frp is None or hotspot.frp <= 0:
            continue

        try:
            classified_results.append(
                await classify_one_hotspot(
                    hotspot,
                    hotspot_id=getattr(hotspot, "_db_id", None),
                )
            )
        except Exception as exc:
            logger.exception(
                "Failed to classify hotspot %.6f, %.6f: %s",
                hotspot.latitude,
                hotspot.longitude,
                exc,
            )

    return classified_results


def classification_payload_for(
    classified_hotspot: ClassifiedHotspot,
    hotspot_id: int,
) -> Dict[str, Any]:
    """Build the single persistence shape used by the job and force endpoint."""
    classification = classified_hotspot.classification
    osm = classified_hotspot.osm_context

    return {
        "hotspot_id": hotspot_id,
        "classification": classification.classification.value,
        "confidence_score": classification.confidence_score,
        "explanation": classification.explanation,
        "evidence": classification.evidence,
        "risk_score": classification.risk_score,
        "risk_level": classification.risk_level,
        "source_data": classification.source_data,
        "osm_context": {
            "nearby_facilities": osm.nearby_facilities,
            "nearest_facility_distance": osm.nearest_facility_distance,
            "nearest_facility_type": osm.nearest_facility_type,
            "facility_count_in_radius": osm.facility_count_in_radius,
            "land_use_context": osm.land_use_context,
            "osm_source": osm.osm_source,
            "queried_at": osm.queried_at,
        },
    }


def persist_classification(
    classified_hotspot: ClassifiedHotspot,
    supabase_service: Any,
) -> str:
    """Insert once or update the stale row; never create a stale duplicate."""
    hotspot = classified_hotspot.hotspot
    hotspot_id = getattr(hotspot, "_db_id", None)
    if not hotspot_id:
        raise ValueError("Cannot persist classification without a hotspot id")

    payload = classification_payload_for(classified_hotspot, hotspot_id)
    stale_classification_id = getattr(hotspot, "_stale_classification_id", None)

    if stale_classification_id:
        (
            supabase_service
            .table("classifications")
            .update(payload)
            .eq("id", stale_classification_id)
            .execute()
        )
        return "updated"

    (
        supabase_service
        .table("classifications")
        .insert(payload)
        .execute()
    )
    return "inserted"


async def classify_and_store(
    country: str = "IND",
    days: int = 1,
) -> List[ClassifiedHotspot]:

    from config import settings
    from db.supabase_client import supabase_service

    # =========================================================
    # 1. Fetch current FIRMS observations
    # =========================================================

    hotspots = await fetch_realtime_hotspots(
        country=country,
        days=days,
    )

    if not hotspots:
        logger.info(
            "No FIRMS hotspots returned."
        )
        return []

    # =========================================================
    # 2. Load existing hotspot + classification state
    # =========================================================

    try:
        recent_records = (
            supabase_service
            .table("hotspots")
            .select(
                "id, latitude, longitude, "
                "acq_date, acq_time, "
                "classifications("
                "id, created_at, "
                "classification, osm_context"
                ")"
            )
            .order(
                "created_at",
                desc=True,
            )
            .limit(5000)
            .execute()
            .data
        )

        db_lookup: Dict[str, Dict[str, Any]] = {}

        for record in (
            recent_records or []
        ):

            key = (
                f"{record.get('latitude')}_"
                f"{record.get('longitude')}_"
                f"{record.get('acq_date')}_"
                f"{record.get('acq_time')}"
            )

            db_lookup[key] = record

    except Exception as exc:

        logger.warning(
            "Failed to fetch recent DB hotspots: %s",
            exc,
        )

        db_lookup = {}

    new_hotspots_to_insert: List[
        FIRMSHotspot
    ] = []

    unclassified_candidates: List[
        FIRMSHotspot
    ] = []

    stale_candidates: List[
        FIRMSHotspot
    ] = []

    existing_classified_count = 0

    # =========================================================
    # 3. Decide what needs classification
    # =========================================================

    for hotspot in hotspots:

        key = (
            f"{hotspot.latitude}_"
            f"{hotspot.longitude}_"
            f"{str(hotspot.acq_date)}_"
            f"{hotspot.acq_time}"
        )

        db_record = db_lookup.get(
            key
        )

        # -----------------------------------------------------
        # Brand-new FIRMS observation
        # -----------------------------------------------------

        if not db_record:

            new_hotspots_to_insert.append(
                hotspot
            )
            continue

        db_id = db_record.get(
            "id"
        )

        if db_id:
            setattr(
                hotspot,
                "_db_id",
                db_id,
            )

        classification_records = (
            db_record.get(
                "classifications"
            )
            or []
        )

        latest_classification = (
            _select_latest_classification(
                classification_records
            )
        )

        # -----------------------------------------------------
        # No classification exists
        # -----------------------------------------------------

        if not latest_classification:

            unclassified_candidates.append(
                hotspot
            )
            continue

        # -----------------------------------------------------
        # Existing classification
        # -----------------------------------------------------

        existing_classified_count += 1

        if _classification_is_stale(
            latest_classification
        ):
            logger.info(
                "Reclassifying stale hotspot %s "
                "(old classification id=%s, "
                "old OSM source=%s)",
                db_id,
                latest_classification.get(
                    "id"
                ),
                (
                    (
                        latest_classification.get(
                            "osm_context"
                        )
                        or {}
                    ).get(
                        "osm_source",
                        "MISSING",
                    )
                ),
            )

            setattr(
                hotspot,
                "_stale_classification_id",
                latest_classification.get(
                    "id"
                ),
            )

            stale_candidates.append(
                hotspot
            )

    # =========================================================
    # 4. Insert brand-new hotspots
    # =========================================================

    if new_hotspots_to_insert:

        try:

            insert_payload = []

            for hotspot in (
                new_hotspots_to_insert
            ):

                insert_payload.append(
                    {
                        "latitude": (
                            hotspot.latitude
                        ),
                        "longitude": (
                            hotspot.longitude
                        ),
                        "brightness": (
                            hotspot.brightness
                        ),
                        "scan": (
                            hotspot.scan
                        ),
                        "track": (
                            hotspot.track
                        ),
                        "acq_date": str(
                            hotspot.acq_date
                        ),
                        "acq_time": (
                            hotspot.acq_time
                        ),
                        "satellite": (
                            hotspot.satellite
                        ),
                        "instrument": (
                            hotspot.instrument
                        ),
                        "confidence": (
                            hotspot.confidence
                        ),
                        "version": (
                            hotspot.version
                        ),
                        "bright_t31": (
                            hotspot.bright_t31
                        ),
                        "frp": (
                            hotspot.frp
                        ),
                        "daynight": (
                            hotspot.daynight
                        ),
                        "raw_data": hotspot.model_dump(
                            mode="json"
                        ),
                    }
                )

            chunk_size = 300

            for start in range(
                0,
                len(insert_payload),
                chunk_size,
            ):

                chunk = insert_payload[
                    start:start + chunk_size
                ]

                response = (
                    supabase_service
                    .table("hotspots")
                    .insert(chunk)
                    .execute()
                )

                if response.data:

                    for index, row in enumerate(
                        response.data
                    ):

                        hotspot = (
                            new_hotspots_to_insert[
                                start + index
                            ]
                        )

                        setattr(
                            hotspot,
                            "_db_id",
                            row["id"],
                        )

                        unclassified_candidates.append(
                            hotspot
                        )

        except Exception as exc:

            logger.error(
                "Bulk insert of new hotspots failed: %s",
                exc,
                exc_info=True,
            )

    # =========================================================
    # 5. Combine:
    #    - brand-new
    #    - previously unclassified
    #    - stale/failed-context records
    # =========================================================

    ai_candidates = (
        unclassified_candidates
        + stale_candidates
    )

    # Highest FRP first.
    ai_candidates.sort(
        key=lambda hotspot: (
            hotspot.frp or 0
        ),
        reverse=True,
    )

    limit = getattr(
        settings,
        "AI_CLASSIFICATION_LIMIT",
        50,
    )

    selected_for_ai = ai_candidates[
        :limit
    ]

    remaining = (
        len(ai_candidates)
        - len(selected_for_ai)
    )

    logger.info(
        "Candidates: %d | Existing classified: %d | "
        "Stale context: %d | Selected for AI: %d | "
        "Remaining: %d",
        len(hotspots),
        existing_classified_count,
        len(stale_candidates),
        len(selected_for_ai),
        remaining,
    )

    # =========================================================
    # 6. Process and persist one observation at a time
    #
    # This is intentionally sequential: it is safe for public Overpass
    # infrastructure, and a timeout/failure cannot keep later FIRMS rows
    # pending.  Persisting within the loop also makes completed work durable
    # if a later observation or the job itself is interrupted.
    # =========================================================

    classified_subset: List[ClassifiedHotspot] = []
    inserted_count = 0
    updated_count = 0

    for hotspot in selected_for_ai:
        db_id = getattr(hotspot, "_db_id", None)
        if not db_id:
            logger.warning(
                "Skipping classification persistence because hotspot has no "
                "DB id: %.6f, %.6f",
                hotspot.latitude,
                hotspot.longitude,
            )
            continue

        try:
            classified_hotspot = await classify_one_hotspot(
                hotspot,
                hotspot_id=db_id,
            )
            classified_subset.append(classified_hotspot)

            action = persist_classification(
                classified_hotspot,
                supabase_service,
            )
            if action == "updated":
                updated_count += 1
                logger.info(
                    "Updated stale classification %s for hotspot %s",
                    getattr(hotspot, "_stale_classification_id", None),
                    db_id,
                )
            else:
                inserted_count += 1
                logger.info("Inserted classification for hotspot %s", db_id)
        except Exception as exc:
            logger.exception(
                "Failed to process or persist classification for hotspot %s: %s",
                db_id,
                exc,
            )

    logger.info(
        "Classification job finished: "
        "%d inserted, %d stale classifications updated",
        inserted_count,
        updated_count,
    )

    return classified_subset
