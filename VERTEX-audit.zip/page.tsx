'use client';

import { useEffect, useState, useMemo } from 'react';
import { ClassifiedHotspot, ClassificationType } from '@/types';
import dynamic from 'next/dynamic';

const MapView = dynamic(
  () =>
    import('@/components/map/MapView').then(
      (mod) => mod.MapView
    ),
  {
    ssr: false,
  }
);

import { Sidebar } from '@/components/layout/Sidebar';
import { RightPanel } from '@/components/layout/RightPanel';
import { BottomTicker } from '@/components/layout/BottomTicker';

import {
  INDIA_CENTER,
  INDIA_ZOOM,
} from '@/lib/constants';

import { useGlobalState } from '@/lib/GlobalStateContext';


interface FilterState {
  classifications: ClassificationType[];
  minFrp: number;
  maxFrp: number;
  minConfidence: number;
  riskLevels: string[];
}


export default function DashboardPage() {

  const {
    hotspots,
    loading,
    error,
    selectedHotspot,
    setSelectedHotspot,
  } = useGlobalState();


  /*
   * =========================================================
   * FILTERS
   * =========================================================
   */

  const [
    filters,
    setFilters,
  ] = useState<FilterState>({
    classifications: [],
    minFrp: 0,
    maxFrp: 1000,
    minConfidence: 0,
    riskLevels: [],
  });


  /*
   * =========================================================
   * PERSISTED / FRESH OSM CONTEXT
   * =========================================================
   *
   * Stores freshly enriched OSM context by hotspot ID.
   *
   * RightPanel emits:
   *
   * vertex:osm-context-updated
   *
   * after a manual refresh.
   *
   * This lets the context remain visible when switching
   * between hotspots without relying on localStorage.
   *
   * The actual persistent source of truth is Supabase.
   */

  const [
    enrichedContexts,
    setEnrichedContexts,
  ] = useState<Record<string | number, any>>({});


  /*
   * =========================================================
   * LISTEN FOR OSM CONTEXT UPDATES
   * =========================================================
   */

  useEffect(() => {

    const handleContextUpdate = (
      event: Event
    ) => {

      const customEvent =
        event as CustomEvent<{
          hotspotId: string | number;
          context: any;
        }>;


      const detail =
        customEvent.detail;


      /*
       * Ignore malformed events.
       */

      if (
        detail?.hotspotId === undefined ||
        detail?.hotspotId === null ||
        !detail?.context
      ) {
        return;
      }


      /*
       * Store the newly enriched context under
       * the hotspot's ID.
       */

      setEnrichedContexts(
        (previous) => ({
          ...previous,
          [detail.hotspotId]:
            detail.context,
        })
      );
    };


    window.addEventListener(
      'vertex:osm-context-updated',
      handleContextUpdate
    );


    return () => {

      window.removeEventListener(
        'vertex:osm-context-updated',
        handleContextUpdate
      );

    };

  }, []);


  /*
   * =========================================================
   * MERGE ENRICHED CONTEXT INTO HOTSPOTS
   * =========================================================
   *
   * If a hotspot has freshly enriched OSM context in local
   * page state, use that context.
   *
   * Otherwise use whatever context came from the backend.
   */

  const hotspotsWithEnrichedContext =
    useMemo(() => {

      return hotspots.map(
        (hotspot) => {

          const enrichedContext =
            enrichedContexts[
              hotspot.id
            ];


          if (!enrichedContext) {
            return hotspot;
          }


          return {
            ...hotspot,
            context: enrichedContext,
          } as ClassifiedHotspot;
        }
      );

    }, [
      hotspots,
      enrichedContexts,
    ]);


  /*
   * =========================================================
   * KEEP SELECTED HOTSPOT IN SYNC
   * =========================================================
   */

  const persistedSelectedHotspot =
    useMemo(() => {

      /*
       * Nothing selected.
       */

      if (!selectedHotspot) {
        return null;
      }


      /*
       * Look for freshly enriched OSM context.
       */

      const enrichedContext =
        enrichedContexts[
          selectedHotspot.id
        ];


      /*
       * No newer context available.
       */

      if (!enrichedContext) {
        return selectedHotspot;
      }


      /*
       * Merge the fresh context into the selected hotspot.
       */

      return {
        ...selectedHotspot,
        context: enrichedContext,
      } as ClassifiedHotspot;

    }, [
      selectedHotspot,
      enrichedContexts,
    ]);


  /*
   * =========================================================
   * FILTER HOTSPOTS
   * =========================================================
   */

  const filteredHotspots =
    useMemo(() => {

      return hotspotsWithEnrichedContext.filter(
        (h) => {

          /*
           * Classification filter
           */

          if (
            filters.classifications.length > 0 &&
            !filters.classifications.includes(
              h.classification.classification
            )
          ) {
            return false;
          }


          /*
           * FRP filter
           */

          if (
            h.hotspot.frp <
              filters.minFrp ||
            h.hotspot.frp >
              filters.maxFrp
          ) {
            return false;
          }


          /*
           * AI confidence filter
           */

          if (
            h.classification.confidence_score <
            filters.minConfidence
          ) {
            return false;
          }


          /*
           * Risk filter
           */

          if (
            filters.riskLevels.length > 0 &&
            h.classification.risk_level &&
            !filters.riskLevels.includes(
              h.classification.risk_level
            )
          ) {
            return false;
          }


          return true;
        }
      );

    }, [
      hotspotsWithEnrichedContext,
      filters,
    ]);


  /*
   * =========================================================
   * SELECT HOTSPOT
   * =========================================================
   *
   * IMPORTANT:
   *
   * MapView may call this with null when the map selection
   * is cleared.
   *
   * Previously we had:
   *
   *   hotspot.id
   *
   * immediately.
   *
   * That caused:
   *
   *   Cannot read properties of null (reading 'id')
   *
   * Now null is handled safely.
   */

  const handleSelectHotspot = (
    hotspot: ClassifiedHotspot | null
  ) => {

    /*
     * Map selection cleared.
     */

    if (!hotspot) {

      setSelectedHotspot(
        null
      );

      return;
    }


    /*
     * Check whether this hotspot has a newer OSM
     * context stored in page state.
     */

    const enrichedContext =
      enrichedContexts[
        hotspot.id
      ];


    /*
     * If fresh context exists, merge it.
     */

    if (enrichedContext) {

      setSelectedHotspot({
        ...hotspot,
        context: enrichedContext,
      } as ClassifiedHotspot);

      return;
    }


    /*
     * Otherwise use the hotspot exactly as supplied.
     */

    setSelectedHotspot(
      hotspot
    );
  };


  /*
   * =========================================================
   * RENDER
   * =========================================================
   */

  return (
    <>

      <div
        className="
          flex-1
          relative
          w-full
          overflow-hidden
          mt-[40px]
          mb-[32px]
        "
      >

        {/* =================================================
            SIDEBAR
            ================================================= */}

        <Sidebar
          hotspots={
            filteredHotspots
          }

          selectedId={
            persistedSelectedHotspot?.id
          }

          onSelect={
            handleSelectHotspot
          }

          onFiltersChange={
            setFilters
          }
        />


        {/* =================================================
            MAIN MAP
            ================================================= */}

        <main
          className="
            absolute
            inset-0
            z-0
            bg-surface-dim
            ml-[300px]
            mr-[340px]
            overflow-hidden
          "
        >

          {/* ===============================================
              LOADING
              =============================================== */}

          {loading ? (

            <div
              className="
                w-full
                h-full
                flex
                flex-col
                items-center
                justify-center
                bg-surface-dim
                text-secondary
                space-y-4
              "
            >

              <span
                className="
                  material-symbols-outlined
                  text-4xl
                  animate-spin
                "
              >
                refresh
              </span>


              <span
                className="
                  font-mono
                  text-sm
                  tracking-widest
                  uppercase
                "
              >
                Initializing Geospatial Telemetry...
              </span>

            </div>

          ) : error ? (

            /* =============================================
               ERROR
               ============================================= */

            <div
              className="
                w-full
                h-full
                flex
                items-center
                justify-center
                bg-surface-dim
              "
            >

              <div
                className="
                  bg-error-container
                  border
                  border-error
                  p-6
                  max-w-md
                  text-center
                  text-on-error-container
                "
              >

                <span
                  className="
                    material-symbols-outlined
                    text-4xl
                    mb-2
                    text-error
                  "
                >
                  warning
                </span>


                <div
                  className="
                    font-headline-sm
                    uppercase
                    tracking-widest
                    mb-2
                  "
                >
                  SYSTEM ERROR
                </div>


                <div
                  className="
                    font-mono
                    text-xs
                  "
                >
                  {error}
                </div>

              </div>

            </div>

          ) : (

            /* =============================================
               MAP
               ============================================= */

            <div
              className="
                w-full
                h-full
              "
            >

              <MapView
                hotspots={
                  filteredHotspots
                }

                selectedHotspot={
                  persistedSelectedHotspot
                }

                onSelectHotspot={
                  handleSelectHotspot
                }

                center={
                  INDIA_CENTER
                }

                zoom={
                  INDIA_ZOOM
                }
              />

            </div>

          )}

        </main>


        {/* =================================================
            RIGHT PANEL
            ================================================= */}

        <RightPanel
          hotspot={
            persistedSelectedHotspot
          }
        />

      </div>


      {/* ===================================================
          BOTTOM TICKER
          =================================================== */}

      <BottomTicker
        hotspots={
          hotspotsWithEnrichedContext
        }
      />

    </>
  );
}