service_status = {
    "firms": {"status": "NOMINAL", "last_success": "Just now"},
    "facility_data": {"status": "NOMINAL", "source": "SUPABASE CATALOG"},
    "gemini": {"status": "NOMINAL", "model": "gemini-3.5-flash-lite"},
    "database": {"status": "DEGRADED", "error": "DNS resolution failed"}
}
