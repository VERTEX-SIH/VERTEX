from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from enum import Enum
from models.hotspot import FIRMSHotspot

class ClassificationEnum(str, Enum):
    INDUSTRIAL_FIRE = 'INDUSTRIAL_FIRE'
    PERSISTENT_INDUSTRIAL_SOURCE = 'PERSISTENT_INDUSTRIAL_SOURCE'
    GAS_FLARE = 'GAS_FLARE'
    WILDFIRE_FOREST_FIRE = 'WILDFIRE_FOREST_FIRE'
    AGRICULTURAL_BURN = 'AGRICULTURAL_BURN'
    MINING_THERMAL_ACTIVITY = 'MINING_THERMAL_ACTIVITY'
    OTHER_THERMAL_ANOMALY = 'OTHER_THERMAL_ANOMALY'
    UNKNOWN_UNCERTAIN = 'UNKNOWN_UNCERTAIN'
    UNKNOWN = 'UNKNOWN' # Keep for backwards compatibility if needed

class OSMSourceEnum(str, Enum):
    LIVE = 'LIVE'
    CACHED = 'CACHED'
    CACHED_NO_FACILITY = 'CACHED_NO_FACILITY'  # legacy persisted value; never emitted by new enrichment
    OFFLINE_CATALOG = 'OFFLINE_CATALOG'
    LIVE_NO_FACILITY = 'LIVE_NO_FACILITY'
    FAILED = 'FAILED'
    PENDING = 'PENDING'

class OSMContext(BaseModel):
    nearby_facilities: List[Dict[str, Any]] = []
    nearest_facility_distance: Optional[float] = None
    nearest_facility_type: Optional[str] = None
    facility_count_in_radius: int = 0
    land_use_context: List[str] = []
    osm_source: OSMSourceEnum = OSMSourceEnum.PENDING
    # Timestamp is only set for context produced by a successful live OSM query.
    # It lets a later failed query distinguish a valid OSM cache from old data.
    queried_at: Optional[str] = None

    class Config:
        use_enum_values = True

class ClassificationResult(BaseModel):
    classification: ClassificationEnum
    confidence_score: float
    explanation: str
    evidence: List[str]
    source_data: Dict[str, Any]
    risk_score: float = 0.0
    risk_level: str = 'LOW'

class ClassifiedHotspot(BaseModel):
    hotspot: FIRMSHotspot
    classification: ClassificationResult
    osm_context: OSMContext
