import logging
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from services.classifier import classify_and_store

logger = logging.getLogger(__name__)

scheduler = AsyncIOScheduler()

async def scheduled_classify_job():
    logger.info("Starting scheduled classification job...")
    try:
        await classify_and_store(country="IND", days=1)
        logger.info("Scheduled classification job completed successfully.")
    except Exception as e:
        logger.error(f"Error in scheduled classification job: {e}")

def setup_scheduler():
    # Run every 30 minutes
    scheduler.add_job(scheduled_classify_job, "interval", minutes=30, id="classify_job", replace_existing=True)
    logger.info("Scheduler configured.")

def start_scheduler():
    setup_scheduler()
    scheduler.start()
    logger.info("Scheduler started.")

def stop_scheduler():
    scheduler.shutdown()
    logger.info("Scheduler stopped.")
