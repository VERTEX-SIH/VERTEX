from fastapi import APIRouter
from config import settings
from services.status import service_status

router = APIRouter(prefix="/health", tags=["Health"])

@router.get("/")
async def health_check():
    return {
        "status": "operational",
        "services": service_status,
        "classification_model": "VERTEX-CLF-1.0",
        "version": "1.0.0"
    }
