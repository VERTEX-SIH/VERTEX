import httpx
import csv
from io import StringIO
from typing import List, Optional
import logging
from config import settings
from models.hotspot import FIRMSHotspot

logger = logging.getLogger(__name__)

# India bounding box: West, South, East, North
INDIA_BBOX = "68.0,6.0,97.5,37.0"
# Karnataka bounding box for faster testing
KARNATAKA_BBOX = "74.0,11.5,78.5,18.5"

import json
from pathlib import Path
from shapely.geometry import shape, Point

# Load high-fidelity India boundary GeoJSON
_INDIA_BOUNDARY_SHAPE = None
try:
    _geojson_path = Path(__file__).parent / 'india_boundary.geojson'
    with open(_geojson_path, 'r', encoding='utf-8') as f:
        _india_geojson = json.load(f)
        _INDIA_BOUNDARY_SHAPE = shape(_india_geojson['geometry'])
except Exception as e:
    logger.error(f"Failed to load India boundary GeoJSON: {e}")

def _point_in_india(lat: float, lon: float) -> bool:
    if _INDIA_BOUNDARY_SHAPE is not None:
        # Shapely Point expects (x, y) -> (longitude, latitude)
        return _INDIA_BOUNDARY_SHAPE.contains(Point(lon, lat))
    # Fallback if geojson is missing
    return False

async def fetch_realtime_hotspots(
    country: str = 'IND',
    days: int = 1,
    source: str = 'VIIRS_SNPP_NRT',
    bbox: Optional[str] = None
) -> List[FIRMSHotspot]:
    """
    Fetch real-time FIRMS hotspots. Uses area/bbox API (more reliable than country API).
    Defaults to Karnataka's bounding box when no bbox is provided to keep processing fast.
    """
    if bbox is None:
        bbox = INDIA_BBOX if country == 'IND' else INDIA_BBOX

    url = f"https://firms.modaps.eosdis.nasa.gov/api/area/csv/{settings.FIRMS_MAP_KEY}/{source}/{bbox}/{days}"
    hotspots = await _fetch_and_parse(url)
    
    if country == 'IND':
        before = len(hotspots)
        hotspots = [h for h in hotspots if _point_in_india(h.latitude, h.longitude)]
        logger.info(f"India boundary filter: {before} → {len(hotspots)} hotspots")
        
    # Sort by FRP descending so clients can easily slice highest priority if needed
    hotspots.sort(key=lambda h: h.frp, reverse=True)
    return hotspots

async def fetch_area_hotspots(
    bbox: str,
    days: int = 1,
    source: str = 'VIIRS_SNPP_NRT'
) -> List[FIRMSHotspot]:
    """Fetch FIRMS hotspots for a specific bounding box."""
    url = f"https://firms.modaps.eosdis.nasa.gov/api/area/csv/{settings.FIRMS_MAP_KEY}/{source}/{bbox}/{days}"
    return await _fetch_and_parse(url)

async def _fetch_and_parse(url: str) -> List[FIRMSHotspot]:
    async with httpx.AsyncClient(verify=False) as client:
        try:
            response = await client.get(url, timeout=60.0)
            response.raise_for_status()

            csv_data = response.text
            if not csv_data or csv_data.strip() == "Invalid API call.":
                logger.warning(f"FIRMS API returned invalid response for URL: {url[:80]}...")
                return []

            reader = csv.DictReader(StringIO(csv_data))

            hotspots = []
            for row in reader:
                try:
                    hotspot = FIRMSHotspot(
                        latitude=float(row['latitude']),
                        longitude=float(row['longitude']),
                        bright_ti4=float(row.get('bright_ti4', row.get('bright_ti5', 0))),
                        brightness=float(row.get('brightness', row.get('bright_ti4', 0))),
                        scan=float(row.get('scan', 0)),
                        track=float(row.get('track', 0)),
                        version=row.get('version'),
                        bright_t31=float(row.get('bright_t31', 0)),
                        frp=float(row.get('frp', 0)),
                        confidence=row.get('confidence'),
                        daynight=row.get('daynight'),
                        satellite=row.get('satellite'),
                        acq_date=row.get('acq_date'),
                        acq_time=row.get('acq_time'),
                        instrument=row.get('instrument')
                    )
                    hotspots.append(hotspot)
                except (ValueError, KeyError) as e:
                    logger.warning(f"Failed to parse FIRMS row: {e}")

            logger.info(f"Fetched {len(hotspots)} hotspots from FIRMS")
            return hotspots
        except httpx.HTTPStatusError as e:
            logger.error(f"FIRMS API HTTP error {e.response.status_code}: {e}")
            return []
        except Exception as e:
            logger.error(f"Error fetching FIRMS data: {e}")
            return []
