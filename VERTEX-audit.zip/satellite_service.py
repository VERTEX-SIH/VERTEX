import logging
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)

async def get_sentinel2_context(lat: float, lon: float, date: str) -> Optional[Dict[str, Any]]:
    """
    Stub for Phase 3: Planetary Computer / CDSE satellite context retrieval.
    """
    logger.warning("Satellite service is not yet fully implemented. Returning None.")
    return None
