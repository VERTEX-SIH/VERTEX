from enum import Enum
from typing import Optional, List, Dict, Any

from pydantic import BaseModel, Field

from models.hotspot import FIRMSHotspot


class ClassificationEnum(str, Enum):
    INDUSTRIAL_FIRE = "INDUSTRIAL_FIRE"
    PERSISTENT_INDUSTRIAL_SOURCE = "PERSISTENT_INDUSTRIAL_SOURCE"
    GAS_FLARE = "GAS_FLARE"
    WILDFIRE_FOREST_FIRE = "WILDFIRE_FOREST_FIRE"
    AGRICULTURAL_BURN = "AGRICULTURAL_BURN"
    MINING_THERMAL_ACTIVITY = "MINING_THERMAL_ACTIVITY"
    OTHER_THERMAL_ANOMALY = "OTHER_THERMAL_ANOMALY"
    UNKNOWN_UNCERTAIN = "UNKNOWN_UNCERTAIN"
    UNKNOWN = "UNKNOWN"


class OSMSourceEnum(str, Enum):
    LIVE = "LIVE"
    LIVE_NO_FACILITY = "LIVE_NO_FACILITY"
    CACHED = "CACHED"
    CACHED_NO_FACILITY = "CACHED_NO_FACILITY"
    OFFLINE_CATALOG = "OFFLINE_CATALOG"
    FAILED = "FAILED"
    PENDING = "PENDING"
    QUERY_FAILED = "QUERY_FAILED"
    SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE"
    NOT_QUERIED = "NOT_QUERIED"


class OSMContext(BaseModel):
    nearby_facilities: List[Dict[str, Any]] = Field(
        default_factory=list
    )
    nearest_facility_distance: Optional[float] = None
    nearest_facility_type: Optional[str] = None
    facility_count_in_radius: int = 0
    land_use_context: List[str] = Field(
        default_factory=list
    )
    osm_source: OSMSourceEnum = OSMSourceEnum.PENDING
    queried_at: Optional[str] = None

    class Config:
        use_enum_values = True


class ClassificationResult(BaseModel):
    classification: ClassificationEnum
    confidence_score: float
    explanation: str
    evidence: List[str] = Field(
        default_factory=list
    )
    source_data: Dict[str, Any] = Field(
        default_factory=dict
    )
    risk_score: float = 0.0
    risk_level: str = "LOW"


class ClassifiedHotspot(BaseModel):
    hotspot: FIRMSHotspot
    classification: ClassificationResult
    osm_context: OSMContext