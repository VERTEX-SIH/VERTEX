import os
from typing import List, Optional, Union
from pydantic import field_validator
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # Required
    FIRMS_MAP_KEY: str
    SUPABASE_URL: str
    SUPABASE_ANON_KEY: str
    SUPABASE_SERVICE_KEY: str
    # Some Windows development environments lack the corporate/root CA used by
    # the configured Supabase endpoint. Keep verification configurable rather
    # than silently changing production behavior.
    SUPABASE_VERIFY_SSL: bool = False
    GEMINI_API_KEY: str

    # Optional
    EARTHDATA_USER: Optional[str] = None
    EARTHDATA_PASS: Optional[str] = None
    CDSE_CLIENT_ID: Optional[str] = None
    CDSE_CLIENT_SECRET: Optional[str] = None

    # App Config
    APP_ENV: str = "development"
    CORS_ORIGINS: str = "http://localhost:3000"
    BACKEND_PORT: int = 8000
    AI_CLASSIFICATION_LIMIT: int = 50

    # Admin Seeding
    ADMIN_EMAIL: str = "admin@example.com"
    ADMIN_PASSWORD: str = "admin123"

    @property
    def cors_origins_list(self) -> List[str]:
        """Parse CORS_ORIGINS as comma-separated string into a list."""
        return [origin.strip() for origin in self.CORS_ORIGINS.split(",") if origin.strip()]

    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "extra": "ignore",
    }

settings = Settings()
