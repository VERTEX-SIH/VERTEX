'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { fetchSystemStatus } from '@/lib/api';
import { SystemStatus } from '@/types';
import { SettingsModal } from './SettingsModal';
import { AccountModal } from './AccountModal';

export function Header() {
  const [time, setTime] = useState<string>('');
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [showAccount, setShowAccount] = useState(false);

  useEffect(() => {
    const updateClock = () => {
      // Convert to IST (Asia/Kolkata)
      const istTime = new Date().toLocaleTimeString('en-IN', {
        timeZone: 'Asia/Kolkata',
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
      setTime(istTime);
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const loadStatus = async () => {
      try {
        const data = await fetchSystemStatus();
        setStatus(data);
      } catch (e) {
        console.error('Failed to fetch system status');
      }
    };
    loadStatus();
    const interval = setInterval(loadStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  const firmsStatus = status?.services?.firms?.status?.toUpperCase() || 'OFFLINE';
  const firmsDisplay = firmsStatus === 'OK' ? 'NOMINAL' : firmsStatus;
  const isFirmsError = firmsStatus !== 'OK' && firmsStatus !== 'NOMINAL';

  const getFacilityDisplay = () => {
    if (!status?.services?.facility_data) return 'OFFLINE';
    const s = status.services.facility_data.source || status.services.facility_data.status || 'UNKNOWN';
    return `${status.services.facility_data.status}/${s}`;
  };

  const facilityDisplay = getFacilityDisplay();
  const isFacilityError = facilityDisplay.includes('FAILED') || facilityDisplay === 'OFFLINE';
  const modelName = status?.classification_model || 'VERTEX-CLF-0.9';

  return (
    <header className="h-[50px] border-b border-outline-variant bg-surface flex items-center justify-between px-4 shrink-0">
      <div className="flex items-center gap-6 h-full">
        <div className="flex items-center gap-2 h-full">
          <span className="material-symbols-outlined text-primary text-[20px]">target</span>
          <span className="font-headline-sm text-primary text-[18px] tracking-wide">VERTEX</span>
        </div>
        
        <nav className="flex items-center h-full gap-4 border-l border-outline-variant pl-4">
          <Link href="/" className="font-mono-label text-[11px] h-full flex items-center px-2 hover:text-primary transition-colors text-secondary">HOME</Link>
          <Link href="/analytics" className="font-mono-label text-[11px] h-full flex items-center px-2 hover:text-primary transition-colors text-secondary">ANALYTICS</Link>
        </nav>

        <div className="flex items-center h-full gap-6 border-l border-outline-variant pl-4 ml-4 hidden md:flex">
          <span className="font-mono-data text-[12px] text-on-surface h-full flex items-center px-2">IST {time}</span>
          <span className={`font-medium font-headline-sm text-[14px] h-full flex items-center px-2 ${isFirmsError ? 'text-error' : 'text-secondary'}`}>
            FIRMS VIIRS: {firmsDisplay}
          </span>
          <span className={`font-medium font-headline-sm text-[14px] h-full flex items-center px-2 ${isFacilityError ? 'text-error' : 'text-secondary'}`}>
            FACILITIES: {facilityDisplay}
          </span>
          <span className="text-secondary font-medium font-headline-sm text-[14px] h-full flex items-center px-2">MODEL: {modelName}</span>
        </div>
      </div>
      <div className="flex items-center h-full">
        <button onClick={() => setShowSettings(true)} className="h-full px-2 text-primary hover:bg-surface-container-high transition-colors flex items-center justify-center cursor-pointer">
          <span className="material-symbols-outlined font-mono">settings</span>
        </button>
        <button className="h-full px-2 text-primary hover:bg-surface-container-high transition-colors flex items-center justify-center cursor-pointer">
          <span className="material-symbols-outlined font-mono">notifications</span>
        </button>
        <button onClick={() => setShowAccount(true)} className="h-full px-2 text-primary hover:bg-surface-container-high transition-colors flex items-center justify-center cursor-pointer">
          <span className="material-symbols-outlined font-mono">account_circle</span>
        </button>
      </div>

      {showSettings && <SettingsModal onClose={() => setShowSettings(false)} />}
      {showAccount && <AccountModal onClose={() => setShowAccount(false)} />}
    </header>
  );
}
