from google import genai
from pydantic import ValidationError
import json
import logging
from config import settings
from models.hotspot import FIRMSHotspot
from models.classification import OSMContext, ClassificationResult, ClassificationEnum

logger = logging.getLogger(__name__)

# Monkey-patch httpx to disable SSL verify for the Gemini client
import httpx
_original_client_init = httpx.Client.__init__
def _patched_client_init(self, *args, **kwargs):
    kwargs['verify'] = False
    _original_client_init(self, *args, **kwargs)
httpx.Client.__init__ = _patched_client_init

client = genai.Client(api_key=settings.GEMINI_API_KEY)
async def classify_with_gemini(
    hotspot: FIRMSHotspot,
    osm_context: OSMContext
) -> ClassificationResult:

    nearby_facilities = osm_context.nearby_facilities or []

    if nearby_facilities:
        facility_lines = "\n".join(
            [
                f"- {facility.get('name', 'Unknown facility')} "
                f"| type: {facility.get('type', 'unknown')} "
                f"| distance: {facility.get('distance_m', 'unknown')} m"
                for facility in nearby_facilities
            ]
        )
    else:
        facility_lines = "None identified."

    land_use = (
        ", ".join(osm_context.land_use_context)
        if osm_context.land_use_context
        else "None identified."
    )

    prompt = f"""
You are the primary classification intelligence system for VERTEX,
a satellite fire/hotspot analysis application.

Your task is to classify ONE FIRMS thermal hotspot using ONLY the
evidence supplied below.

Possible classifications:

INDUSTRIAL_FIRE
PERSISTENT_INDUSTRIAL_SOURCE
GAS_FLARE
WILDFIRE_FOREST_FIRE
AGRICULTURAL_BURN
MINING_THERMAL_ACTIVITY
OTHER_THERMAL_ANOMALY
UNKNOWN_UNCERTAIN

IMPORTANT EVIDENCE RULES:

1. FIRMS measurements are satellite observations, not ground truth.

2. OSM evidence is geographic evidence retrieved from OpenStreetMap.

3. OFFLINE_CATALOG is NOT OSM.
   It means the facility came from the VERTEX industrial facility
   catalog stored in Supabase.

4. CACHED means the facility/context came from previously successful
   OSM data.

5. LIVE means the facility/context came from a successful live OSM query.

6. LIVE_NO_FACILITY means OSM was successfully queried but no relevant
   facility was found and the offline catalog also produced no facility.

7. FAILED means OSM failed and no cached/offline facility context exists.

8. Missing OSM data is uncertainty.
   It is NOT proof that no facility, farmland, forest, mine, or other
   geographic feature exists.

9. The absence of an industrial facility does NOT automatically mean
   AGRICULTURAL_BURN.

10. Do NOT invent facilities, land use, geography, businesses,
    infrastructure, or other facts that were not supplied.

11. Use all available evidence together:
    FRP, brightness, confidence, day/night, acquisition time,
    satellite/instrument, facility proximity, facility type,
    land-use context, and data provenance.

12. Confidence must reflect the strength and completeness of the
    supplied evidence. If evidence is weak or conflicting, use a
    conservative confidence and consider UNKNOWN_UNCERTAIN or
    OTHER_THERMAL_ANOMALY.

HOTSPOT DATA:

Latitude: {hotspot.latitude}
Longitude: {hotspot.longitude}
Brightness: {hotspot.brightness}
FRP: {hotspot.frp} MW
Confidence: {hotspot.confidence}
Day/Night: {hotspot.daynight}
Acquisition Date: {hotspot.acq_date}
Acquisition Time: {hotspot.acq_time}
Satellite: {hotspot.satellite}
Instrument: {hotspot.instrument}

GEOSPATIAL CONTEXT:

Context source/provenance: {osm_context.osm_source}

Nearest facility type:
{osm_context.nearest_facility_type}

Nearest facility distance:
{osm_context.nearest_facility_distance} meters

Facility count in search radius:
{osm_context.facility_count_in_radius}

Nearby facilities:
{facility_lines}

Land-use context:
{land_use}

CLASSIFICATION GUIDANCE:

- GAS_FLARE may be appropriate when strong thermal activity is very
  close to a facility type capable of flaring and the supplied evidence
  supports that interpretation.

- PERSISTENT_INDUSTRIAL_SOURCE may be appropriate when the supplied
  evidence indicates a recurring/ongoing low-level industrial thermal
  source.

- INDUSTRIAL_FIRE may be appropriate when evidence supports an
  accidental or structural fire associated with industrial facilities.

- AGRICULTURAL_BURN may be appropriate when supplied geographic/context
  evidence supports agricultural land or crop burning. Do not select
  it merely because industry was not found.

- WILDFIRE_FOREST_FIRE may be appropriate when supplied evidence
  supports forest/woodland vegetation and the thermal characteristics
  are consistent with wildfire.

- MINING_THERMAL_ACTIVITY may be appropriate when supplied evidence
  supports mining/quarry activity.

- OTHER_THERMAL_ANOMALY should be used when the event appears real but
  does not fit the supported categories.

- UNKNOWN_UNCERTAIN should be used when the available evidence is
  insufficient for a defensible classification.

Return ONLY valid JSON with exactly this structure:

{{
  "classification": "ONE_ALLOWED_CLASSIFICATION",
  "confidence_score": 0.0,
  "explanation": "Concise explanation based only on supplied evidence.",
  "evidence": [
    "Evidence item 1",
    "Evidence item 2"
  ],
  "risk_level": "LOW",
  "source_data": {{
    "model": "gemini-3.5-flash-lite"
  }}
}}

Do not include markdown.
Do not include additional JSON fields.
"""

    try:
        response = client.models.generate_content(
            model="gemini-3.5-flash-lite",
            contents=prompt,
            config={
                "response_mime_type": "application/json"
            }
        )

        data = json.loads(response.text)

        return ClassificationResult(
            classification=ClassificationEnum(
                data.get("classification", "UNKNOWN_UNCERTAIN")
            ),
            confidence_score=float(
                data.get("confidence_score", 0.5)
            ),
            explanation=str(
                data.get(
                    "explanation",
                    "Could not fully parse reasoning."
                )
            ),
            evidence=data.get("evidence", []),
            risk_level=data.get("risk_level", "LOW"),
            source_data=data.get(
                "source_data",
                {"model": "gemini-3.5-flash-lite"}
            )
        )

    except Exception as e:
        logger.error(f"Gemini classification error: {e}")

        return ClassificationResult(
            classification=ClassificationEnum.UNKNOWN_UNCERTAIN,
            confidence_score=0.1,
            explanation=f"Error calling LLM: {str(e)}",
            evidence=[],
            risk_level="LOW",
            source_data={
                "error": str(e),
                "model": "gemini-3.5-flash-lite"
            }
        )