from fastapi import APIRouter, Query, HTTPException
from services.osm_service import enrich_hotspot
from db.supabase_client import supabase_service
from models.hotspot import FIRMSHotspot
from models.classification import OSMContext

import asyncio
import logging
from typing import List


logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/osm",
    tags=["OpenStreetMap"],
)


# =========================================================
# HELPERS
# =========================================================

def _context_to_dict(context: OSMContext):
    return {
        "nearby_facilities": context.nearby_facilities,
        "nearest_facility_distance": context.nearest_facility_distance,
        "nearest_facility_type": context.nearest_facility_type,
        "facility_count_in_radius": context.facility_count_in_radius,
        "land_use_context": context.land_use_context,
        "osm_source": context.osm_source,
        "queried_at": context.queried_at,
    }


def _get_hotspot(hotspot_id: str):
    try:
        result = (
            supabase_service
            .table("hotspots")
            .select("*")
            .eq("id", hotspot_id)
            .single()
            .execute()
        )

        if not result.data:
            raise HTTPException(
                status_code=404,
                detail="Hotspot not found",
            )

        return result.data

    except HTTPException:
        raise

    except Exception as e:
        logger.error(
            f"Error fetching hotspot {hotspot_id}: {e}"
        )

        raise HTTPException(
            status_code=500,
            detail="Database error",
        )


def _get_existing_context(
    hotspot_id: str,
) -> OSMContext | None:

    try:
        # -------------------------------------------------
        # FIRST: classifications.osm_context
        # -------------------------------------------------

        classifications = (
            supabase_service
            .table("classifications")
            .select("osm_context, created_at")
            .eq("hotspot_id", hotspot_id)
            .order("created_at", desc=True)
            .limit(1)
            .execute()
            .data
            or []
        )

        if classifications:
            data = classifications[0].get("osm_context")

            if data:
                try:
                    return OSMContext(**data)
                except Exception:
                    pass

        # -------------------------------------------------
        # SECOND: legacy osm_contexts table
        # -------------------------------------------------

        stored_contexts = (
            supabase_service
            .table("osm_contexts")
            .select("*")
            .eq("hotspot_id", hotspot_id)
            .order("id", desc=True)
            .limit(1)
            .execute()
            .data
            or []
        )

        if stored_contexts:
            row = stored_contexts[0]

            data = row.get("data", {}) or {}

            data.setdefault(
                "facility_count_in_radius",
                row.get("facility_count_in_radius", 0),
            )

            try:
                return OSMContext(**data)
            except Exception:
                pass

        return None

    except Exception as e:
        logger.warning(
            f"Could not read existing OSM context "
            f"for hotspot {hotspot_id}: {e}"
        )

        return None


def _save_context_to_existing_tables(
    hotspot_id: str,
    context: OSMContext,
):
    """
    Keep the existing application tables synchronized.

    The actual persistent OSM cache is handled by
    services.osm_service.enrich_hotspot().

    These writes maintain compatibility with the
    existing frontend/classification data.
    """

    osm_data = _context_to_dict(context)

    try:
        # -------------------------------------------------
        # classifications table
        # -------------------------------------------------

        classifications = (
            supabase_service
            .table("classifications")
            .select("id")
            .eq("hotspot_id", hotspot_id)
            .limit(1)
            .execute()
            .data
            or []
        )

        if classifications:

            (
                supabase_service
                .table("classifications")
                .update({
                    "osm_context": osm_data
                })
                .eq(
                    "hotspot_id",
                    hotspot_id,
                )
                .execute()
            )

        else:

            # -------------------------------------------------
            # legacy osm_contexts table
            # -------------------------------------------------

            existing_context_rows = (
                supabase_service
                .table("osm_contexts")
                .select("id")
                .eq(
                    "hotspot_id",
                    hotspot_id,
                )
                .limit(1)
                .execute()
                .data
                or []
            )

            context_row = {
                "data": osm_data,
                "facility_count_in_radius":
                    context.facility_count_in_radius,
            }

            if existing_context_rows:

                (
                    supabase_service
                    .table("osm_contexts")
                    .update(context_row)
                    .eq(
                        "id",
                        existing_context_rows[0]["id"],
                    )
                    .execute()
                )

            else:

                (
                    supabase_service
                    .table("osm_contexts")
                    .insert({
                        "hotspot_id": hotspot_id,
                        **context_row,
                    })
                    .execute()
                )

    except Exception as e:
        # Do NOT fail the actual enrichment if this
        # compatibility write fails.
        logger.warning(
            f"Could not update legacy OSM context "
            f"for hotspot {hotspot_id}: {e}"
        )


# =========================================================
# INDUSTRIAL CONTEXT
# =========================================================

@router.get("/industrial")
async def get_industrial(
    lat: float = Query(...),
    lon: float = Query(...),
    radius: int = Query(5000),
):
    """
    Return industrial context using the same enrichment
    state machine used by classification.

    enrich_hotspot() handles:
      - Supabase persistent cache
      - live Overpass
      - offline facility catalog
      - fallback logic
    """

    hotspot = FIRMSHotspot(
        latitude=lat,
        longitude=lon,
    )

    context = await enrich_hotspot(
        hotspot,
    )

    return {
        "facilities": context.nearby_facilities,
        "source": context.osm_source,
        "osm_source": context.osm_source,
        "query_status": "SUCCESS",
        "facility_count":
            context.facility_count_in_radius,
        "queried_at": context.queried_at,
    }


# =========================================================
# FACILITY CATALOG
# =========================================================

@router.post("/facility-catalog/cache/refresh")
async def refresh_facility_catalog_cache():

    from services.facility_service import (
        invalidate_facility_cache
    )

    invalidate_facility_cache()

    return {
        "status": "INVALIDATED"
    }


# =========================================================
# HEALTH
# =========================================================

@router.get("/health")
async def check_osm_health():

    return {
        "mirrors": [
            {
                "mirror": "overpass-api.de",
                "status": "AVAILABLE",
            },
            {
                "mirror": "overpass.kumi.systems",
                "status": "AVAILABLE",
            },
            {
                "mirror": "overpass.openstreetmap.ru",
                "status": "AVAILABLE",
            },
        ]
    }


# =========================================================
# SINGLE HOTSPOT ENRICHMENT
# =========================================================

@router.post("/enrich/{hotspot_id}")
async def enrich_single_hotspot(
    hotspot_id: str,
    force: bool = Query(
        False,
        description=(
            "Force a fresh OSM query instead "
            "of using the persistent cache."
        ),
    ),
):

    # -----------------------------------------------------
    # Fetch hotspot
    # -----------------------------------------------------

    hotspot_data = _get_hotspot(
        hotspot_id
    )

    hotspot = FIRMSHotspot(
        **hotspot_data
    )

    try:

        # -------------------------------------------------
        # ONE enrichment state machine
        #
        # Normal:
        #   cache -> Overpass -> fallback
        #
        # Force:
        #   bypass cache -> Overpass -> fallback
        # -------------------------------------------------

        context = await asyncio.wait_for(
            enrich_hotspot(
                hotspot,
                force_refresh=force,
                hotspot_id=int(hotspot_id),
            ),
            timeout=30.0,
        )

    except asyncio.TimeoutError:

        logger.warning(
            f"OSM enrichment timed out "
            f"for hotspot {hotspot_id}"
        )

        raise HTTPException(
            status_code=408,
            detail="OSM enrichment timed out",
        )

    except Exception as e:

        logger.error(
            f"OSM enrichment failed "
            f"for hotspot {hotspot_id}: {e}"
        )

        raise HTTPException(
            status_code=500,
            detail=str(e),
        )

    # -----------------------------------------------------
    # Keep legacy/application tables synchronized
    # -----------------------------------------------------

    _save_context_to_existing_tables(
        hotspot_id,
        context,
    )

    return context


# =========================================================
# TOP-50 AUTOMATIC ENRICHMENT
# =========================================================

@router.post("/enrich/top50")
async def enrich_top_50(
    hotspot_ids: List[str],
):
    """
    Enrich the current Top-50 hotspot working set.

    IMPORTANT:
      - Maximum 50 hotspots.
      - Supabase persistent cache is checked first.
      - Cache hits do NOT call Overpass.
      - Cache misses may call Overpass.
      - Successful live results are persisted.
      - Maximum 5 concurrent Overpass/enrichment operations.
    """

    if not hotspot_ids:
        return {
            "requested": 0,
            "processed": 0,
            "successful": 0,
            "failed": 0,
            "results": [],
        }

    # -----------------------------------------------------
    # Hard safety limit
    # -----------------------------------------------------

    hotspot_ids = hotspot_ids[:50]

    semaphore = asyncio.Semaphore(5)

    async def process_one(
        hotspot_id: str,
    ):

        async with semaphore:

            try:

                # -----------------------------------------
                # Fetch hotspot
                # -----------------------------------------

                hotspot_data = _get_hotspot(
                    hotspot_id
                )

                hotspot = FIRMSHotspot(
                    **hotspot_data
                )

                # -----------------------------------------
                # Existing application context is only a
                # compatibility fallback.
                #
                # enrich_hotspot() itself checks the
                # persistent coordinate-based Supabase
                # cache first.
                # -----------------------------------------

                existing_context = (
                    _get_existing_context(
                        hotspot_id
                    )
                )

                # -----------------------------------------
                # IMPORTANT:
                # Pass hotspot_id so any cache save is
                # associated with the actual hotspot.
                # -----------------------------------------

                context = await asyncio.wait_for(
                    enrich_hotspot(
                        hotspot,
                        existing_context,
                        hotspot_id=int(hotspot_id),
                    ),
                    timeout=30.0,
                )

                # -----------------------------------------
                # Keep classifications / legacy table
                # synchronized.
                # -----------------------------------------

                _save_context_to_existing_tables(
                    hotspot_id,
                    context,
                )

                return {
                    "hotspot_id":
                        hotspot_id,

                    "status":
                        "SUCCESS",

                    "osm_source":
                        context.osm_source,

                    "facility_count":
                        context.facility_count_in_radius,

                    "nearest_facility":
                        context.nearest_facility_type,

                    "nearest_distance_m":
                        context.nearest_facility_distance,
                }

            except Exception as e:

                logger.warning(
                    f"Top-50 enrichment failed "
                    f"for {hotspot_id}: {e}"
                )

                return {
                    "hotspot_id":
                        hotspot_id,

                    "status":
                        "FAILED",

                    "error":
                        str(e),
                }

    # -----------------------------------------------------
    # Process concurrently with max 5 workers
    # -----------------------------------------------------

    results = await asyncio.gather(
        *[
            process_one(hotspot_id)
            for hotspot_id in hotspot_ids
        ]
    )

    successful = sum(
        1
        for result in results
        if result["status"] == "SUCCESS"
    )

    failed = (
        len(results) - successful
    )

    return {
        "requested":
            len(hotspot_ids),

        "processed":
            len(results),

        "successful":
            successful,

        "failed":
            failed,

        "results":
            results,
    }