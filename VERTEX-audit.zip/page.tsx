'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        setError(error.message);
      } else {
        router.push('/admin');
      }
    } catch (err: any) {
      setError(err.message || 'Network error or Supabase is offline.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-screen items-center justify-center bg-surface p-4">
      <div className="w-full max-w-md border border-outline-variant bg-surface-container-low p-6 rounded-none shadow-sm">
        <div className="mb-6 flex items-center justify-between border-b border-outline-variant pb-4">
          <h1 className="font-headline-sm text-primary">SYSTEM AUTHENTICATION</h1>
          <span className="material-symbols-outlined text-primary">lock</span>
        </div>

        {error && (
          <div className="mb-4 bg-error-container text-on-error-container p-3 border border-error text-sm font-body-sm rounded-none">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1">
            <label className="font-mono-label text-on-surface-variant uppercase text-xs">Operator Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-surface border border-outline-variant p-2 font-mono-data-md text-on-surface focus:outline-none focus:border-primary rounded-none"
              required
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="font-mono-label text-on-surface-variant uppercase text-xs">Security Key</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-surface border border-outline-variant p-2 font-mono-data-md text-on-surface focus:outline-none focus:border-primary rounded-none"
              required
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="mt-4 bg-primary text-on-primary py-2 font-mono-label hover:bg-primary-container hover:text-on-primary-container transition-colors disabled:opacity-50 border border-transparent rounded-none uppercase flex items-center justify-center gap-2"
          >
            {loading ? 'Authenticating...' : 'Access Console'}
            {!loading && <span className="material-symbols-outlined text-sm">login</span>}
          </button>
        </form>
      </div>
    </div>
  );
}
