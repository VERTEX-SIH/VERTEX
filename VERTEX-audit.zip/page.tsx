'use client';
import { useGlobalState } from '@/lib/GlobalStateContext';
import { CLASSIFICATION_COLORS, CLASSIFICATION_LABELS, ClassificationType } from '@/types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';

export default function AnalyticsPage() {
  const { analyticsSummary: summary, loading, error } = useGlobalState();

  if (loading) {
    return (
      <div className="min-h-screen bg-background pt-[40px] flex items-center justify-center">
        <div className="flex flex-col items-center">
          <span className="material-symbols-outlined text-4xl text-primary animate-spin mb-4">sync</span>
          <span className="font-mono text-[10px] text-secondary uppercase tracking-widest">LOADING ANALYTICS</span>
        </div>
      </div>
    );
  }

  if (error && !summary) {
    return (
      <div className="min-h-screen bg-background pt-[40px] flex items-center justify-center">
        <div className="flex flex-col items-center bg-surface border border-error p-8 max-w-md text-center">
          <span className="material-symbols-outlined text-4xl text-error mb-4">database</span>
          <span className="font-headline-sm text-[14px] text-error uppercase tracking-widest mb-2">SYSTEM ERROR</span>
          <p className="font-body-sm text-secondary">{error}</p>
        </div>
      </div>
    );
  }

  let safeSummary: any = {
    totalDetections: 0,
    industrialEvents: 0,
    highRisk: 0,
    averageFrp: 0,
    classificationDistribution: [],
    frpDistribution: [],
    riskDistribution: [],
    topFacilities: []
  };

  if (summary) {
    if ('total_hotspots' in summary) {
      // It's the live backend API format
      const indTypes = ['INDUSTRIAL_FIRE', 'GAS_FLARE', 'PERSISTENT_INDUSTRIAL_SOURCE'];
      let indCount = 0;
      const classDist = [];
      for (const [k, v] of Object.entries(summary.classification_counts || {})) {
        classDist.push({ type: k, count: v });
        if (indTypes.includes(k)) indCount += (v as number);
      }
      
      let highR = 0;
      const riskDist = [];
      for (const [k, v] of Object.entries(summary.risk_level_counts || {})) {
        riskDist.push({ level: k, count: v });
        if (k === 'HIGH' || k === 'CRITICAL') highR += (v as number);
      }

      safeSummary = {
        totalDetections: summary.total_hotspots || 0,
        totalFirmsObservations: summary.total_firms_observations || summary.total_hotspots || 0,
        aiClassified: summary.ai_classified || 0,
        aiPending: summary.ai_pending || 0,
        industrialEvents: indCount,
        highRisk: highR,
        averageFrp: summary.frp_statistics?.avg || 0,
        classificationDistribution: classDist,
        frpDistribution: [], 
        riskDistribution: riskDist,
        topFacilities: [] 
      };
    } else {
      // It's the demo format
      safeSummary = { ...safeSummary, ...summary };
    }
  }

  const pieData = (safeSummary.classificationDistribution || []).map((item: any) => ({
    name: CLASSIFICATION_LABELS[item.type as ClassificationType] || item.type,
    value: item.count,
    color: CLASSIFICATION_COLORS[item.type as ClassificationType] || CLASSIFICATION_COLORS.UNKNOWN_UNCERTAIN
  }));

  return (
    <div className="bg-surface-dim min-h-screen text-on-surface pt-[40px] pb-[32px] overflow-auto">
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="border-b border-outline-variant pb-4 mb-6">
          <h1 className="font-headline-sm text-2xl text-primary uppercase tracking-widest">ANALYTICS</h1>
          <p className="font-body-sm text-secondary uppercase tracking-widest mt-1 text-xs">THERMAL EVENT ANALYSIS</p>
        </div>
        
        {/* Stat Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-surface border border-outline-variant p-4">
            <div className="font-mono-label text-[10px] text-secondary tracking-widest uppercase mb-2">TOTAL FIRMS OBSERVATIONS</div>
            <div className="font-mono-data-md text-3xl text-on-surface">{safeSummary.totalFirmsObservations || safeSummary.totalDetections || 0}</div>
          </div>
          <div className="bg-surface border border-outline-variant p-4">
            <div className="font-mono-label text-[10px] text-secondary tracking-widest uppercase mb-2">AI CLASSIFIED</div>
            <div className="font-mono-data-md text-3xl text-primary">{safeSummary.aiClassified || 0}</div>
          </div>
          <div className="bg-surface border border-outline-variant p-4">
            <div className="font-mono-label text-[10px] text-secondary tracking-widest uppercase mb-2">AI PENDING</div>
            <div className="font-mono-data-md text-3xl text-error">{safeSummary.aiPending || 0}</div>
          </div>
          <div className="bg-surface border border-outline-variant p-4">
            <div className="font-mono-label text-[10px] text-secondary tracking-widest uppercase mb-2">AVERAGE FRP (MW)</div>
            <div className="font-mono-data-md text-3xl text-on-surface">{(safeSummary.averageFrp || 0).toFixed(1)}</div>
          </div>
        </div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Pie Chart */}
          <div className="bg-surface border border-outline-variant p-4 flex flex-col h-[400px]">
            <div className="font-headline-sm text-[14px] text-primary uppercase mb-4">CLASSIFICATION DISTRIBUTION</div>
            <div className="flex-1 min-h-0">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={80}
                    outerRadius={120}
                    paddingAngle={2}
                    dataKey="value"
                    stroke="none"
                  >
                    {pieData.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <RechartsTooltip 
                    contentStyle={{ backgroundColor: '#1e1e1e', borderColor: '#333333', borderRadius: '0', fontFamily: 'JetBrains Mono' }}
                    itemStyle={{ color: '#e0e0e0', fontSize: '12px' }}
                  />
                  <Legend 
                    layout="vertical" 
                    verticalAlign="middle" 
                    align="right"
                    wrapperStyle={{ fontFamily: 'JetBrains Mono', fontSize: '10px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Bar Chart */}
          <div className="bg-surface border border-outline-variant p-4 flex flex-col h-[400px]">
            <div className="font-headline-sm text-[14px] text-primary uppercase mb-4">FRP DISTRIBUTION (MW)</div>
            <div className="flex-1 min-h-0">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={safeSummary.frpDistribution || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333333" vertical={false} />
                  <XAxis dataKey="range" stroke="#888888" tick={{ fill: '#888888', fontSize: 10, fontFamily: 'JetBrains Mono' }} />
                  <YAxis stroke="#888888" tick={{ fill: '#888888', fontSize: 10, fontFamily: 'JetBrains Mono' }} />
                  <RechartsTooltip 
                    contentStyle={{ backgroundColor: '#1e1e1e', borderColor: '#333333', borderRadius: '0', fontFamily: 'JetBrains Mono' }}
                    cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                  />
                  <Bar dataKey="count" fill="#a14000" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Charts Row 2 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           {/* Risk Distribution */}
           <div className="bg-surface border border-outline-variant p-4 flex flex-col h-[300px]">
            <div className="font-headline-sm text-[14px] text-primary uppercase mb-4">RISK LEVEL DISTRIBUTION</div>
            <div className="flex-1 min-h-0">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={safeSummary.riskDistribution || []} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#333333" horizontal={false} />
                  <XAxis type="number" stroke="#888888" tick={{ fill: '#888888', fontSize: 10, fontFamily: 'JetBrains Mono' }} />
                  <YAxis dataKey="level" type="category" stroke="#888888" width={80} tick={{ fill: '#888888', fontSize: 10, fontFamily: 'JetBrains Mono' }} />
                  <RechartsTooltip 
                    contentStyle={{ backgroundColor: '#1e1e1e', borderColor: '#333333', borderRadius: '0', fontFamily: 'JetBrains Mono' }}
                    cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                  />
                  <Bar dataKey="count" fill="#ea580c" radius={[0, 2, 2, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Top Facilities */}
          <div className="bg-surface border border-outline-variant p-4 flex flex-col h-[300px] overflow-hidden">
            <div className="font-headline-sm text-[14px] text-primary uppercase mb-4">TOP FACILITIES BY THERMAL ACTIVITY</div>
            <div className="flex-1 overflow-auto">
              <table className="w-full text-left border-collapse">
                <thead className="sticky top-0 bg-surface">
                  <tr>
                    <th className="font-mono-label text-[10px] text-secondary tracking-widest border-b border-outline-variant pb-2">FACILITY NAME</th>
                    <th className="font-mono-label text-[10px] text-secondary tracking-widest border-b border-outline-variant pb-2">TYPE</th>
                    <th className="font-mono-label text-[10px] text-secondary tracking-widest border-b border-outline-variant pb-2 text-right">EVENTS</th>
                  </tr>
                </thead>
                <tbody>
                  {(safeSummary.topFacilities || []).map((fac: any, i: number) => (
                    <tr key={i} className="hover:bg-surface-container-high transition-colors">
                      <td className="font-body-sm text-[12px] py-2 border-b border-outline-variant">{fac.name}</td>
                      <td className="font-body-sm text-[12px] py-2 border-b border-outline-variant text-secondary">{fac.type}</td>
                      <td className="font-mono-data-sm text-[12px] py-2 border-b border-outline-variant text-right text-primary">{fac.count}</td>
                    </tr>
                  ))}
                  {(!safeSummary.topFacilities || safeSummary.topFacilities.length === 0) && (
                    <tr>
                      <td colSpan={3} className="text-center py-4 font-mono text-[10px] text-secondary uppercase tracking-widest">
                        NO FACILITY DATA AVAILABLE
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
