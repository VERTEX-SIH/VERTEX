﻿'use client';
import { ClassifiedHotspot, CLASSIFICATION_COLORS, CLASSIFICATION_LABELS, ClassificationType } from '@/types';

interface EvidenceStackModalProps {
  hotspot: ClassifiedHotspot;
  onClose: () => void;
}

export function EvidenceStackModal({ hotspot, onClose }: EvidenceStackModalProps) {
  const { hotspot: firms, classification, context } = hotspot;
  const color = CLASSIFICATION_COLORS[classification.classification];
  const label = CLASSIFICATION_LABELS[classification.classification];

  return (
    <div className="fixed inset-0 z-[100] flex bg-surface/95 backdrop-blur-md">
      <div className="w-[300px] border-r border-outline-variant bg-surface-container-low flex flex-col">
        <div className="p-4 border-b border-outline-variant flex items-center gap-2 text-primary cursor-pointer hover:bg-surface-container transition-colors" onClick={onClose}>
          <span className="material-symbols-outlined">arrow_back</span>
          <span className="font-headline-sm uppercase tracking-widest text-[12px]">RETURN TO PLATFORM</span>
        </div>
        <div className="p-6 flex-1">
          <div className="font-headline-sm text-2xl text-on-surface uppercase tracking-widest mb-1">EVIDENCE STACK</div>
          <div className="font-mono text-[10px] text-secondary tracking-widest mb-8">EVENT ID: {hotspot.id}</div>
          
          <div className="space-y-6">
            <div>
              <div className="font-mono-label text-[10px] text-secondary tracking-widest mb-2 border-b border-outline-variant pb-1">AI CLASSIFICATION</div>
              <div className="font-headline-sm text-[16px] p-2 border border-outline-variant bg-surface" style={{ color, borderColor: color }}>
                {label}
              </div>
            </div>
            
            <div>
              <div className="font-mono-label text-[10px] text-secondary tracking-widest mb-2 border-b border-outline-variant pb-1">TELEMETRY DATA</div>
              <div className="bg-surface border border-outline-variant p-3 font-mono-data-sm text-[12px] space-y-2">
                <div className="flex justify-between"><span className="text-secondary">FRP</span><span className="text-primary">{firms.frp.toFixed(1)} MW</span></div>
                <div className="flex justify-between"><span className="text-secondary">BRIGHTNESS</span><span className="text-on-surface">{firms.brightness.toFixed(1)} K</span></div>
                <div className="flex justify-between"><span className="text-secondary">CONFIDENCE</span><span className="text-on-surface">{classification.confidence_score.toFixed(2)}</span></div>
                <div className="flex justify-between"><span className="text-secondary">INSTRUMENT</span><span className="text-on-surface">{firms.satellite} / {firms.instrument}</span></div>
                <div className="flex justify-between"><span className="text-secondary">LATITUDE</span><span className="text-on-surface">{firms.latitude.toFixed(5)}</span></div>
                <div className="flex justify-between"><span className="text-secondary">LONGITUDE</span><span className="text-on-surface">{firms.longitude.toFixed(5)}</span></div>
                <div className="flex justify-between"><span className="text-secondary">TIME (UTC)</span><span className="text-on-surface">{firms.acq_date} {firms.acq_time}</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex-1 flex flex-col p-6 overflow-y-auto">
        <div className="max-w-4xl w-full mx-auto space-y-6">
          <div className="bg-surface border border-outline-variant p-6 shadow-sm">
            <h2 className="font-headline-sm text-[16px] text-primary uppercase border-b border-outline-variant pb-2 mb-4">AI Analysis Report</h2>
            <div className="font-body-md text-on-surface leading-relaxed whitespace-pre-wrap">
              {classification.explanation}
            </div>
            {classification.evidence && classification.evidence.length > 0 && (
              <div className="mt-6">
                <h3 className="font-mono-label text-[10px] text-secondary tracking-widest mb-3">SUPPORTING EVIDENCE</h3>
                <ul className="space-y-2">
                  {classification.evidence.map((item, i) => (
                    <li key={i} className="flex gap-3 bg-surface-container-low p-3 border border-outline-variant">
                      <span className="material-symbols-outlined text-primary text-[16px] mt-0.5">check_circle</span>
                      <span className="font-body-sm text-[13px]">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
          
          <div className="bg-surface border border-outline-variant p-6 shadow-sm">
            <h2 className="font-headline-sm text-[16px] text-primary uppercase border-b border-outline-variant pb-2 mb-4">Proximity & Context</h2>
            {context.nearby_facilities && context.nearby_facilities.length > 0 ? (
              <div className="space-y-4">
                {context.nearby_facilities.map((fac, idx) => (
                  <div key={idx} className="flex justify-between items-center border border-outline-variant p-4 bg-surface-container-low">
                    <div>
                      <div className="font-headline-sm text-[14px] text-on-surface uppercase">{fac.name}</div>
                      <div className="font-mono text-[11px] text-secondary mt-1">{fac.type}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono-data-md text-primary text-[16px]">{fac.distance_m.toFixed(0)}m</div>
                      <div className="font-mono text-[9px] text-secondary uppercase">DISTANCE</div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-secondary font-body-sm p-4 border border-outline-variant bg-surface-container-low text-center italic">
                No recognized industrial facilities within 5km radius.
              </div>
            )}
            
            <div className="mt-6 border-t border-outline-variant pt-4">
              <div className="font-mono-label text-[10px] text-secondary tracking-widest mb-2">SYSTEM LOG</div>
              <div className="bg-black p-4 font-mono text-[10px] text-green-400 h-32 overflow-y-auto whitespace-pre">
                {`[SYS] Initializing classification pipeline...
[SYS] Fetched coordinates ${firms.latitude}, ${firms.longitude}
[OSM] Queried radius 5000m. Found ${context.facility_count_in_radius} facilities.
[AI]  Invoking model VERTEX-CLF-1.0
[AI]  Payload: FRP ${firms.frp}, DAYNIGHT ${firms.daynight}
[AI]  Response: ${classification.classification} (Conf: ${classification.confidence_score})
[DB]  Status: CACHED_DEMO
[SYS] Pipeline complete.`}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

