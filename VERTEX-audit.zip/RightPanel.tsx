'use client';

import {
  ClassifiedHotspot,
  CLASSIFICATION_LABELS,
  CLASSIFICATION_COLORS,
  ClassificationType,
} from '@/types';
import { useEffect, useState } from 'react';
import { EvidenceStackModal } from './EvidenceStackModal';
import { FacilityGraphModal } from './FacilityGraphModal';

interface RightPanelProps {
  hotspot?: ClassifiedHotspot | null;
}

const EMPTY_CONTEXT = {
  nearby_facilities: [],
  nearest_facility_distance: null,
  nearest_facility_type: null,
  facility_count_in_radius: 0,
  land_use_context: [],
  osm_source: 'PENDING',
  queried_at: null,
};

/*
 * Store refreshed OSM contexts separately for each hotspot.
 *
 * Example:
 * localStorage["vertex_osm_contexts"] = {
 *   "199": {...},
 *   "20": {...}
 * }
 */
const STORAGE_KEY = 'vertex_osm_contexts';

function getStoredContext(hotspotId: string | number) {
  if (typeof window === 'undefined') return null;

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;

    const contexts = JSON.parse(raw);
    return contexts[String(hotspotId)] ?? null;
  } catch (error) {
    console.error('Failed to read stored OSM context:', error);
    return null;
  }
}

function storeContext(
  hotspotId: string | number,
  context: any
) {
  if (typeof window === 'undefined') return;

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const contexts = raw ? JSON.parse(raw) : {};

    contexts[String(hotspotId)] = context;

    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(contexts)
    );
  } catch (error) {
    console.error('Failed to store OSM context:', error);
  }
}

function normalizeContext(context: any) {
  if (
    !context ||
    typeof context !== 'object' ||
    Array.isArray(context)
  ) {
    return EMPTY_CONTEXT;
  }

  return {
    nearby_facilities: context.nearby_facilities ?? [],
    nearest_facility_distance:
      context.nearest_facility_distance ?? null,
    nearest_facility_type:
      context.nearest_facility_type ?? null,
    facility_count_in_radius:
      context.facility_count_in_radius ?? 0,
    land_use_context:
      context.land_use_context ?? [],
    osm_source:
      context.osm_source ?? 'PENDING',
    queried_at:
      context.queried_at ?? null,
  };
}

function contextSourceLabel(source?: string) {
  switch (source) {
    case 'LIVE':
      return 'OSM LIVE';

    case 'CACHED':
      return 'OSM CACHED';

    case 'OFFLINE_CATALOG':
      return 'OFFLINE FACILITY CATALOG';

    case 'LIVE_NO_FACILITY':
      return 'OSM QUERY SUCCEEDED — NO FACILITY FOUND';

    case 'FAILED':
      return 'OSM/CONTEXT QUERY FAILED';

    case 'PENDING':
      return 'CONTEXT PENDING / NOT YET QUERIED';

    default:
      return 'CONTEXT PENDING / NOT YET QUERIED';
  }
}

function contextMessage(source?: string) {
  switch (source) {
    case 'LIVE_NO_FACILITY':
      return 'OSM query succeeded. No relevant facility was found within the search radius.';

    case 'FAILED':
      return 'OSM and the offline facility catalog did not return a facility context.';

    case 'PENDING':
      return 'Facility context has not been queried yet.';

    default:
      return 'No recognized facilities within the search radius.';
  }
}

export function RightPanel({ hotspot }: RightPanelProps) {
  const [activeTab, setActiveTab] = useState<
    'DOSSIER' | 'METRICS' | 'INSPECTOR' | 'LOGS'
  >('DOSSIER');

  const [showEvidence, setShowEvidence] = useState(false);
  const [showFacility, setShowFacility] = useState(false);

  const [isRefreshingContext, setIsRefreshingContext] =
    useState(false);

  const [contextRefreshError, setContextRefreshError] =
    useState<string | null>(null);

  const [displayContext, setDisplayContext] =
    useState<any>(EMPTY_CONTEXT);

  /*
   * IMPORTANT:
   *
   * Whenever hotspot changes:
   *
   * 1. First check localStorage.
   * 2. If a refreshed context exists, use it.
   * 3. Otherwise use the context returned by the backend.
   *
   * This means:
   *
   * hotspot 199
   *   -> refresh
   *   -> LIVE context saved
   *
   * navigate away
   *
   * come back to hotspot 199
   *   -> LIVE context restored
   */
  useEffect(() => {
    if (!hotspot) {
      setDisplayContext(EMPTY_CONTEXT);
      setContextRefreshError(null);
      setIsRefreshingContext(false);
      return;
    }

    const storedContext = getStoredContext(hotspot.id);

    if (storedContext) {
      setDisplayContext(normalizeContext(storedContext));
    } else {
      setDisplayContext(
        normalizeContext(hotspot.context ?? EMPTY_CONTEXT)
      );
    }

    setContextRefreshError(null);
    setIsRefreshingContext(false);
  }, [hotspot?.id]);

  /*
   * Refresh ONLY OSM/context.
   *
   * No page reload.
   *
   * After getting the backend result:
   *
   * - update React state
   * - save it to localStorage
   *
   * So navigating away and returning will not lose it.
   */
  const refreshContext = async () => {
    if (!hotspot) return;

    setIsRefreshingContext(true);
    setContextRefreshError(null);

    try {
      const { forceEnrichHotspot } =
        await import('@/lib/api');

      const result = await forceEnrichHotspot(
        String(hotspot.id)
      );

      /*
       * Backend currently returns the context directly.
       *
       * This also supports:
       *
       * {
       *   osm_context: {...}
       * }
       */
      const refreshedContext =
        (result as any)?.osm_context ??
        (result as any);

      if (
        refreshedContext &&
        typeof refreshedContext === 'object' &&
        !Array.isArray(refreshedContext)
      ) {
        const normalized = normalizeContext(
          refreshedContext
        );

        /*
         * Update UI immediately.
         */
        setDisplayContext(normalized);

        /*
         * Persist it for this hotspot.
         */
        storeContext(
          hotspot.id,
          normalized
        );
      } else {
        throw new Error(
          'Invalid context returned by backend'
        );
      }
    } catch (error) {
      console.error(
        'Context refresh failed:',
        error
      );

      setContextRefreshError(
        'Context refresh failed. Please try again.'
      );
    } finally {
      setIsRefreshingContext(false);
    }
  };

  /*
   * No hotspot selected.
   */
  if (!hotspot) {
    return (
      <aside className="bg-surface-container-low w-[340px] h-full flex flex-col border-l border-outline-variant fixed right-0 top-[40px] bottom-[32px] z-40">
        <div className="p-2 border-b border-outline-variant flex justify-between items-start">
          <div>
            <div className="font-headline-sm text-[14px] text-primary uppercase">
              TARGET DOSSIER
            </div>

            <div className="font-body-sm text-[11px] text-secondary mt-1 tracking-widest uppercase">
              EVENT METADATA
            </div>
          </div>

          <div className="font-mono text-[13px] text-on-surface bg-surface-container px-2 py-1 border border-outline-variant">
            N/A
          </div>
        </div>

        <div className="flex-1 p-4 flex flex-col items-center justify-center text-center text-secondary">
          <span className="material-symbols-outlined text-4xl mb-2 text-outline-variant">
            target
          </span>

          <div className="font-mono text-[11px] uppercase tracking-widest">
            NO TARGET SELECTED
          </div>

          <div className="font-body-sm text-[11px] mt-2 max-w-[200px] leading-relaxed text-outline-variant">
            Select an anomaly from the map or stream to view detailed AI
            classification evidence.
          </div>
        </div>
      </aside>
    );
  }

  const { hotspot: firms, classification } =
    hotspot;

  const context =
    displayContext ?? EMPTY_CONTEXT;

  const color =
    CLASSIFICATION_COLORS[
      classification.classification
    ];

  const label =
    CLASSIFICATION_LABELS[
      classification.classification
    ];

  return (
    <aside className="bg-surface-container-low w-[340px] h-full flex flex-col border-l border-outline-variant fixed right-0 top-[40px] bottom-[32px] z-40 overflow-hidden">

      {/* HEADER */}
      <div className="p-2 border-b border-outline-variant flex justify-between items-start shrink-0">
        <div>
          <div className="font-headline-sm text-[14px] text-primary uppercase">
            TARGET DOSSIER
          </div>

          <div className="font-body-sm text-[11px] text-secondary mt-1 tracking-widest uppercase">
            EVENT METADATA
          </div>
        </div>

        <div className="font-mono text-[13px] text-on-surface bg-surface-container px-2 py-1 border border-outline-variant">
          {String(hotspot.id).substring(0, 8)}
        </div>
      </div>

      {/* TABS */}
      <div className="flex border-b border-outline-variant shrink-0 bg-surface">
        {[
          'DOSSIER',
          'METRICS',
          'INSPECTOR',
          'LOGS',
        ].map((tab) => (
          <button
            key={tab}
            onClick={() =>
              setActiveTab(tab as any)
            }
            className={`flex-1 py-1.5 text-center font-mono-label text-[10px] tracking-widest uppercase transition-colors ${
              activeTab === tab
                ? 'bg-surface-container-highest text-on-surface border-b-2 border-primary'
                : 'text-secondary hover:bg-surface-container-high'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* CONTENT */}
      <div className="flex-1 overflow-y-auto overflow-x-hidden p-3 space-y-4">

        {activeTab === 'DOSSIER' && (
          <>
            {/* =========================================================
                UNCLASSIFIED / PENDING
            ========================================================= */}

            {classification.classification ===
            ClassificationType.UNCLASSIFIED ? (
              <>
                {/* PENDING */}
                <div className="border border-outline-variant p-3 bg-surface-container-high">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="material-symbols-outlined text-secondary">
                      hourglass_empty
                    </span>

                    <div className="font-headline-sm text-[14px] text-secondary uppercase tracking-widest">
                      AI CLASSIFICATION PENDING
                    </div>
                  </div>

                  <div className="font-body-sm text-[11px] text-outline-variant mt-1">
                    This observation has not been processed by the Gemini
                    classifier. It will be prioritized in the next
                    classification run based on FRP and recency.
                  </div>
                </div>

                {/* THERMAL SIGNATURE */}
                <div>
                  <div className="font-headline-sm text-[12px] text-on-surface mb-2 border-b border-outline-variant pb-1">
                    THERMAL SIGNATURE
                  </div>

                  <div className="grid grid-cols-2 gap-[1px] bg-outline-variant border border-outline-variant">

                    <div className="bg-surface p-2">
                      <div className="font-mono-label text-[10px] text-secondary mb-1">
                        FRP
                      </div>

                      <div className="font-mono-data-md text-[13px] text-primary">
                        {firms.frp.toFixed(1)} MW
                      </div>
                    </div>

                    <div className="bg-surface p-2">
                      <div className="font-mono-label text-[10px] text-secondary mb-1">
                        BRIGHT
                      </div>

                      <div className="font-mono-data-md text-[13px] text-on-surface">
                        {firms.brightness > 0
                          ? firms.brightness.toFixed(1)
                          : '0.0'}{' '}
                        K
                      </div>
                    </div>

                    <div className="bg-surface p-2">
                      <div className="font-mono-label text-[10px] text-secondary mb-1">
                        FIRMS CONF
                      </div>

                      <div className="font-mono-data-md text-[13px] text-on-surface">
                        {firms.confidence}
                      </div>
                    </div>

                    <div className="bg-surface p-2">
                      <div className="font-mono-label text-[10px] text-secondary mb-1">
                        AI CONFID
                      </div>

                      <div className="font-mono-data-md text-[13px] text-on-surface">
                        PENDING
                      </div>
                    </div>

                    <div className="bg-surface p-2 col-span-2">
                      <div className="font-mono-label text-[10px] text-secondary mb-1">
                        DAY/NGT
                      </div>

                      <div className="font-mono-data-md text-[13px] text-on-surface">
                        {firms.daynight === 'D'
                          ? 'DAY'
                          : 'NIGHT'}
                      </div>
                    </div>
                  </div>
                </div>

                {/* GEOSPATIAL */}
                <div>
                  <div className="font-headline-sm text-[12px] text-on-surface mb-2 border-b border-outline-variant pb-1">
                    GEOSPATIAL
                  </div>

                  <div className="bg-surface border border-outline-variant p-2 font-mono-data-sm text-[12px]">
                    <div>
                      LAT: {firms.latitude.toFixed(4)}°N
                    </div>

                    <div>
                      LNG: {firms.longitude.toFixed(4)}°E
                    </div>
                  </div>
                </div>

                {/* INDUSTRIAL CONTEXT */}
                <div>
                  <div className="flex justify-between items-end mb-2 border-b border-outline-variant pb-1">

                    <div className="font-headline-sm text-[12px] text-on-surface">
                      INDUSTRIAL CONTEXT
                    </div>

                    <button
                      onClick={refreshContext}
                      disabled={isRefreshingContext}
                      title="Refresh Context"
                      className="font-mono-label text-[9px] text-secondary hover:text-primary uppercase tracking-widest flex items-center bg-surface-container px-1 py-0.5 rounded cursor-pointer disabled:opacity-50"
                    >
                      <span
                        className={`material-symbols-outlined text-[12px] ${
                          isRefreshingContext
                            ? 'animate-spin'
                            : ''
                        }`}
                      >
                        refresh
                      </span>
                    </button>
                  </div>

                  <div className="bg-surface border border-outline-variant p-2 font-body-sm text-[12px] space-y-2">

                    {context.nearby_facilities?.length >
                    0 ? (
                      <div>
                        <div className="font-mono-label text-[13px] font-bold text-on-surface uppercase">
                          {
                            context
                              .nearby_facilities[0]
                              .name
                          }
                        </div>

                        <div className="text-secondary capitalize">
                          {
                            context
                              .nearby_facilities[0]
                              .type
                          .replace(/_/g, ' ')}
                        </div>

                        <div className="text-secondary">
                          Distance:{' '}
                          {(
                            context
                              .nearby_facilities[0]
                              .distance_meters ??
                            context
                              .nearby_facilities[0]
                              .distance_m ??
                            0
                          ).toFixed(0)}{' '}
                          m
                        </div>
                      </div>
                    ) : (
                      <div className="text-secondary italic">
                        {contextMessage(
                          context.osm_source
                        )}
                      </div>
                    )}

                    <div className="font-mono-label text-[10px] text-on-surface">
                      {contextSourceLabel(
                        context.osm_source
                      )}
                    </div>

                    {contextRefreshError && (
                      <div className="text-[10px] text-error">
                        {contextRefreshError}
                      </div>
                    )}
                  </div>
                </div>
              </>
            ) : (

              /* =========================================================
                 CLASSIFIED
              ========================================================= */

              <>
                {/* PREDICTED CLASS */}
                <div className="border border-outline-variant p-2 relative bg-surface">
                  <div
                    className="absolute top-0 left-0 w-1 h-full"
                    style={{
                      backgroundColor: color,
                    }}
                  />

                  <div className="font-mono-label text-[10px] text-secondary mb-1">
                    PREDICTED CLASS
                  </div>

                  <div
                    className="font-headline-sm text-[14px]"
                    style={{ color }}
                  >
                    [{label}]{' '}
                    {classification.risk_level &&
                      `${classification.risk_level} RISK`}
                  </div>
                </div>

                {/* THERMAL SIGNATURE */}
                <div>
                  <div>
                    <div className="font-headline-sm text-[12px] text-on-surface mb-2 border-b border-outline-variant pb-1">
                      THERMAL SIGNATURE
                    </div>

                    <div className="grid grid-cols-2 gap-[1px] bg-outline-variant border border-outline-variant">

                      <div className="bg-surface p-2">
                        <div className="font-mono-label text-[10px] text-secondary mb-1">
                          FRP
                        </div>

                        <div className="font-mono-data-md text-[13px] text-primary">
                          {firms.frp.toFixed(1)} MW
                        </div>
                      </div>

                      <div className="bg-surface p-2">
                        <div className="font-mono-label text-[10px] text-secondary mb-1">
                          BRIGHT
                        </div>

                        <div className="font-mono-data-md text-[13px] text-on-surface">
                          {firms.brightness > 0
                            ? firms.brightness.toFixed(1)
                            : '0.0'}{' '}
                          K
                        </div>
                      </div>

                      <div className="bg-surface p-2">
                        <div className="font-mono-label text-[10px] text-secondary mb-1">
                          FIRMS CONF
                        </div>

                        <div className="font-mono-data-md text-[13px] text-on-surface">
                          {firms.confidence}
                        </div>
                      </div>

                      <div className="bg-surface p-2">
                        <div className="font-mono-label text-[10px] text-secondary mb-1">
                          AI CONFID
                        </div>

                        <div className="font-mono-data-md text-[13px] text-on-surface">
                          {classification.confidence_score.toFixed(
                            2
                          )}
                        </div>
                      </div>

                      <div className="bg-surface p-2 col-span-2">
                        <div className="font-mono-label text-[10px] text-secondary mb-1">
                          DAY/NGT
                        </div>

                        <div className="font-mono-data-md text-[13px] text-on-surface">
                          {firms.daynight === 'D'
                            ? 'DAY'
                            : 'NIGHT'}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* GEOSPATIAL */}
                  <div className="mt-4">
                    <div className="font-headline-sm text-[12px] text-on-surface mb-2 border-b border-outline-variant pb-1">
                      GEOSPATIAL
                    </div>

                    <div className="bg-surface border border-outline-variant p-2 font-mono-data-sm text-[12px]">
                      <div>
                        LAT:{' '}
                        {firms.latitude.toFixed(4)}
                        °N
                      </div>

                      <div>
                        LNG:{' '}
                        {firms.longitude.toFixed(4)}
                        °E
                      </div>
                    </div>
                  </div>

                  {/* INDUSTRIAL CONTEXT */}
                  <div className="mt-4">
                    <div className="flex justify-between items-end mb-2 border-b border-outline-variant pb-1">

                      <div className="font-headline-sm text-[12px] text-on-surface">
                        INDUSTRIAL CONTEXT
                      </div>

                      <div className="flex gap-2">

                        {context.nearby_facilities?.length >
                          0 && (
                          <button
                            onClick={() =>
                              setShowFacility(
                                true
                              )
                            }
                            className="font-mono-label text-[9px] text-primary hover:underline uppercase tracking-widest flex items-center"
                          >
                            <span className="material-symbols-outlined text-[12px] mr-0.5">
                              account_tree
                            </span>

                            ASSET TREE
                          </button>
                        )}

                        <button
                          onClick={refreshContext}
                          disabled={
                            isRefreshingContext
                          }
                          title="Refresh Context"
                          className="font-mono-label text-[9px] text-secondary hover:text-primary uppercase tracking-widest flex items-center bg-surface-container px-1 py-0.5 rounded cursor-pointer disabled:opacity-50"
                        >
                          <span
                            className={`material-symbols-outlined text-[12px] ${
                              isRefreshingContext
                                ? 'animate-spin'
                                : ''
                            }`}
                          >
                            refresh
                          </span>
                        </button>
                      </div>
                    </div>

                    <div className="bg-surface border border-outline-variant p-2 font-body-sm text-[12px] space-y-3">

                      {/* FACILITY */}
                      {context.nearby_facilities?.length >
                      0 ? (
                        <div>
                          <div className="font-mono-label text-[13px] font-bold text-on-surface uppercase">
                            {
                              context
                                .nearby_facilities[0]
                                .name
                            }
                          </div>

                          <div className="text-secondary capitalize">
                            {
                              context
                                .nearby_facilities[0]
                                .type
                            .replace(
                              /_/g,
                              ' '
                            )}
                          </div>

                          <div className="text-secondary">
                            Distance:{' '}
                            {(
                              context
                                .nearby_facilities[0]
                                .distance_meters ??
                              context
                                .nearby_facilities[0]
                                .distance_m ??
                              0
                            ).toFixed(0)}{' '}
                            m
                          </div>
                        </div>
                      ) : (
                        <div className="text-secondary italic">
                          {contextMessage(
                            context.osm_source
                          )}
                        </div>
                      )}

                      {/* SOURCE */}
                      {context.osm_source && (
                        <div className="pt-2 border-t border-outline-variant">

                          <div className="font-mono-label text-[10px] text-secondary mb-1">
                            SOURCE
                          </div>

                          <div className="font-mono-label text-[11px] text-on-surface">
                            {contextSourceLabel(
                              context.osm_source
                            )}
                          </div>

                          {context.osm_source ===
                            'OFFLINE_CATALOG' && (
                            <div className="text-[10px] text-secondary mt-1 italic">
                              Showing facility context from the VERTEX
                              offline facility catalog.
                            </div>
                          )}

                          {contextRefreshError && (
                            <div className="text-[10px] text-error mt-1">
                              {
                                contextRefreshError
                              }
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* AI ANALYSIS */}
                <div>
                  <div className="flex justify-between items-end mb-2 border-b border-outline-variant pb-1">

                    <div className="font-headline-sm text-[12px] text-on-surface">
                      AI ANALYSIS
                    </div>

                    <button
                      onClick={() =>
                        setShowEvidence(true)
                      }
                      className="font-mono-label text-[9px] text-primary hover:underline uppercase tracking-widest flex items-center"
                    >
                      <span className="material-symbols-outlined text-[12px] mr-0.5">
                        stacks
                      </span>

                      EVIDENCE STACK
                    </button>
                  </div>

                  <div className="bg-surface border border-outline-variant p-2 text-[12px]">

                    <div className="font-body-sm mb-3 leading-relaxed">
                      {classification.explanation
                        .replace(
                          /knows|confirms/gi,
                          'suggests'
                        )
                        .replace(
                          /is a/gi,
                          'is likely a'
                        )}
                    </div>

                    {classification.evidence &&
                      classification.evidence.length >
                        0 && (
                        <div>
                          <div className="font-mono-label text-[10px] text-secondary mb-1">
                            EVIDENCE:
                          </div>

                          <ul className="list-disc pl-4 space-y-1 font-body-sm">
                            {classification.evidence.map(
                              (item, i) => (
                                <li key={i}>
                                  {item}
                                </li>
                              )
                            )}
                          </ul>
                        </div>
                      )}
                  </div>

                  <div className="flex items-center gap-1 mt-2 text-primary font-mono-label text-[9px] opacity-70">
                    <span className="material-symbols-outlined text-[12px]">
                      warning
                    </span>

                    AI-ASSISTED CLASSIFICATION (LIKELY)
                  </div>
                </div>
              </>
            )}
          </>
        )}

        {/* OTHER TABS */}
        {activeTab !== 'DOSSIER' && (
          <div className="flex flex-col items-center justify-center h-40 text-secondary">
            <span className="material-symbols-outlined text-3xl mb-2 opacity-50">
              construction
            </span>

            <div className="font-mono text-[10px] uppercase tracking-widest">
              MODULE OFFLINE
            </div>
          </div>
        )}
      </div>

      {/* MODALS */}
      {showEvidence && (
        <EvidenceStackModal
          hotspot={hotspot}
          onClose={() =>
            setShowEvidence(false)
          }
        />
      )}

      {showFacility && (
        <FacilityGraphModal
          hotspot={hotspot}
          onClose={() =>
            setShowFacility(false)
          }
        />
      )}
    </aside>
  );
}