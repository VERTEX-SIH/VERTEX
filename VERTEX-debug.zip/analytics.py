from datetime import date, timedelta
from collections import Counter
from typing import Any, Dict, List, Tuple

from fastapi import APIRouter, Request, HTTPException

from db.supabase_client import supabase_service
from limiter import limiter


router = APIRouter(
    prefix="/analytics",
    tags=["Analytics"],
)


# =========================================================
# HELPERS
# =========================================================

def _coordinate_key(
    latitude: Any,
    longitude: Any,
) -> str | None:
    """
    Stable coordinate key used to join hotspots with the
    persistent OSM cache.
    """
    try:
        lat = float(latitude)
        lon = float(longitude)
        return f"{lat:.6f},{lon:.6f}"
    except (TypeError, ValueError):
        return None


def _normalize_cache_rows(
    rows: List[Dict[str, Any]],
) -> Dict[str, Dict[str, Any]]:
    """
    Index OSM cache rows by latitude/longitude.

    The query is ordered newest-first, so the first row for a
    coordinate is treated as the current cached context.
    """
    cache_by_coordinate: Dict[str, Dict[str, Any]] = {}

    for row in rows:
        if not isinstance(row, dict):
            continue

        key = _coordinate_key(
            row.get("latitude"),
            row.get("longitude"),
        )

        if not key:
            continue

        if key in cache_by_coordinate:
            continue

        cache_by_coordinate[key] = row

    return cache_by_coordinate


def _latest_classification(
    classifications: Any,
) -> Dict[str, Any] | None:
    """
    Return the newest classification row.

    Multiple classification rows can exist for a hotspot,
    so analytics must only count the latest one.
    """
    if not isinstance(classifications, list):
        return None

    valid = [
        item
        for item in classifications
        if isinstance(item, dict)
    ]

    if not valid:
        return None

    valid.sort(
        key=lambda item: (
            item.get("created_at", "") or ""
        ),
        reverse=True,
    )

    return valid[0]


# =========================================================
# ANALYTICS SUMMARY
# =========================================================

@router.get("/summary")
@limiter.limit("30/minute")
async def get_analytics_summary(
    request: Request,
    days: int = 1,
):
    """
    Return analytics for the current FIRMS observation window.

    Important:
    - Uses FIRMS acq_date rather than database created_at.
    - Uses latest classification per hotspot.
    - Restricts India observations using the same India polygon
      used by the hotspot pipeline.
    - Prevents duplicate classification rows from inflating counts.
    - Loads OSM cache separately because osm_context_cache is not
      a direct Supabase relationship of hotspots.
    """

    try:
        from shapely.geometry import Point
        from services.firms_service import _INDIA_BOUNDARY_SHAPE

        days = max(
            1,
            min(days, 30),
        )

        cutoff = (
            date.today()
            - timedelta(days=days - 1)
        )

        # -----------------------------------------------------
        # LOAD HOTSPOTS
        # -----------------------------------------------------

        all_data: List[Dict[str, Any]] = []

        page_size = 1000
        start = 0

        while True:
            response = (
                supabase_service
                .table("hotspots")
                .select(
                    """
                    id,
                    latitude,
                    longitude,
                    acq_date,
                    frp,
                    classifications(
                        classification,
                        risk_level,
                        confidence_score,
                        created_at
                    )
                    """
                )
                .range(
                    start,
                    start + page_size - 1,
                )
                .execute()
            )

            rows = (
                response.data
                or []
            )

            if not rows:
                break

            all_data.extend(rows)

            if len(rows) < page_size:
                break

            start += page_size

        # -----------------------------------------------------
        # LOAD OSM CACHE SEPARATELY
        # -----------------------------------------------------

        cache_by_coordinate: Dict[
            str,
            Dict[str, Any],
        ] = {}

        try:
            cache_response = (
                supabase_service
                .table("osm_context_cache")
                .select("*")
                .order(
                    "queried_at",
                    desc=True,
                )
                .execute()
            )

            cache_rows = (
                cache_response.data
                or []
            )

            cache_by_coordinate = (
                _normalize_cache_rows(
                    cache_rows
                )
            )

        except Exception:
            # OSM cache must never make analytics fail.
            cache_by_coordinate = {}

        # -----------------------------------------------------
        # FILTER CURRENT INDIA OBSERVATIONS
        # -----------------------------------------------------

        current_data: List[
            Dict[str, Any]
        ] = []

        for row in all_data:

            if not isinstance(
                row,
                dict,
            ):
                continue

            # -------------------------------
            # Date filter
            # -------------------------------

            acq_date = row.get(
                "acq_date"
            )

            if not acq_date:
                continue

            try:
                observation_date = date.fromisoformat(
                    str(acq_date)[:10]
                )
            except ValueError:
                continue

            if observation_date < cutoff:
                continue

            # -------------------------------
            # Coordinate filter
            # -------------------------------

            try:
                latitude = float(
                    row.get("latitude")
                )

                longitude = float(
                    row.get("longitude")
                )

            except (
                TypeError,
                ValueError,
            ):
                continue

            # -------------------------------
            # India polygon
            # -------------------------------

            if (
                _INDIA_BOUNDARY_SHAPE is not None
                and not _INDIA_BOUNDARY_SHAPE.covers(
                    Point(
                        longitude,
                        latitude,
                    )
                )
            ):
                continue

            current_data.append(row)

        # -----------------------------------------------------
        # EMPTY RESULT
        # -----------------------------------------------------

        if not current_data:
            return {
                "total_hotspots": 0,
                "total_firms_observations": 0,
                "ai_classified": 0,
                "ai_pending": 0,
                "classification_counts": {},
                "risk_level_counts": {},
                "frp_statistics": {
                    "min": 0,
                    "max": 0,
                    "avg": 0,
                },
                "frpDistribution": [],
                "topFacilities": [],
                "osm_cache_statistics": {
                    "cached": 0,
                    "pending": 0,
                    "total": 0,
                },
            }

        # -----------------------------------------------------
        # ACCUMULATORS
        # -----------------------------------------------------

        classification_counts = Counter()
        risk_counts = Counter()

        frps: List[float] = []

        ai_classified = 0
        ai_pending = 0

        facility_counts: Counter[
            Tuple[str, str]
        ] = Counter()

        osm_cached = 0
        osm_pending = 0

        # -----------------------------------------------------
        # PROCESS EACH HOTSPOT ONCE
        # -----------------------------------------------------

        for row in current_data:

            # -------------------------------
            # FRP
            # -------------------------------

            frp = row.get("frp")

            if frp is not None:
                try:
                    frps.append(
                        float(frp)
                    )
                except (
                    TypeError,
                    ValueError,
                ):
                    pass

            # -------------------------------
            # LATEST CLASSIFICATION
            # -------------------------------

            latest = _latest_classification(
                row.get("classifications")
            )

            if latest:

                classification = (
                    latest.get(
                        "classification"
                    )
                    or "UNKNOWN"
                )

                risk_level = (
                    latest.get(
                        "risk_level"
                    )
                    or "LOW"
                )

                if (
                    str(
                        classification
                    ).upper()
                    != "PENDING"
                ):

                    classification_counts[
                        str(classification)
                    ] += 1

                    risk_counts[
                        str(risk_level)
                    ] += 1

                    ai_classified += 1

                else:
                    ai_pending += 1

            else:
                ai_pending += 1

            # -------------------------------
            # OSM CACHE
            # -------------------------------

            cache_key = _coordinate_key(
                row.get("latitude"),
                row.get("longitude"),
            )

            cache = (
                cache_by_coordinate.get(
                    cache_key
                )
                if cache_key
                else None
            )

            if cache:

                osm_cached += 1

                facilities = (
                    cache.get(
                        "nearby_facilities"
                    )
                    or []
                )

                if isinstance(
                    facilities,
                    list,
                ):
                    for facility in facilities:

                        if not isinstance(
                            facility,
                            dict,
                        ):
                            continue

                        name = (
                            facility.get(
                                "name"
                            )
                            or "UNKNOWN FACILITY"
                        )

                        facility_type = (
                            facility.get(
                                "type"
                            )
                            or facility.get(
                                "facility_type"
                            )
                            or "UNKNOWN"
                        )

                        facility_counts[
                            (
                                str(name),
                                str(facility_type),
                            )
                        ] += 1

            else:
                osm_pending += 1

        # -----------------------------------------------------
        # FRP DISTRIBUTION
        # -----------------------------------------------------

        frp_buckets = [
            ("0–1", 0),
            ("1–5", 0),
            ("5–10", 0),
            ("10–25", 0),
            ("25+", 0),
        ]

        for value in frps:

            if value < 1:
                frp_buckets[0] = (
                    frp_buckets[0][0],
                    frp_buckets[0][1] + 1,
                )

            elif value < 5:
                frp_buckets[1] = (
                    frp_buckets[1][0],
                    frp_buckets[1][1] + 1,
                )

            elif value < 10:
                frp_buckets[2] = (
                    frp_buckets[2][0],
                    frp_buckets[2][1] + 1,
                )

            elif value < 25:
                frp_buckets[3] = (
                    frp_buckets[3][0],
                    frp_buckets[3][1] + 1,
                )

            else:
                frp_buckets[4] = (
                    frp_buckets[4][0],
                    frp_buckets[4][1] + 1,
                )

        frp_distribution = [
            {
                "range": label,
                "count": count,
            }
            for label, count in frp_buckets
        ]

        # -----------------------------------------------------
        # TOP FACILITIES
        # -----------------------------------------------------

        top_facilities = []

        for (
            (name, facility_type),
            count,
        ) in facility_counts.most_common(10):

            top_facilities.append(
                {
                    "name": name,
                    "type": facility_type,
                    "count": count,
                }
            )

        # -----------------------------------------------------
        # RESPONSE
        # -----------------------------------------------------

        return {
            "total_hotspots":
                len(current_data),

            "total_firms_observations":
                len(current_data),

            "ai_classified":
                ai_classified,

            "ai_pending":
                ai_pending,

            "classification_counts":
                dict(
                    classification_counts
                ),

            "risk_level_counts":
                dict(
                    risk_counts
                ),

            "frp_statistics": {
                "min":
                    round(
                        min(frps),
                        2,
                    )
                    if frps
                    else 0,

                "max":
                    round(
                        max(frps),
                        2,
                    )
                    if frps
                    else 0,

                "avg":
                    round(
                        sum(frps)
                        / len(frps),
                        2,
                    )
                    if frps
                    else 0,
            },

            "frpDistribution":
                frp_distribution,

            "topFacilities":
                top_facilities,

            "osm_cache_statistics": {
                "cached":
                    osm_cached,

                "pending":
                    osm_pending,

                "total":
                    len(current_data),
            },
        }

    except Exception as e:

        raise HTTPException(
            status_code=503,
            detail=(
                "Analytics database "
                f"connection failed: {e}"
            ),
        )