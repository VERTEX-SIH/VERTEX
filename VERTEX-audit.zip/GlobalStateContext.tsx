'use client';

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from 'react';

import { ClassifiedHotspot } from '@/types';

import {
  fetchClassifiedHotspots,
  fetchAnalyticsSummary,
  enrichTop50Hotspots,
} from '@/lib/api';

import {
  DEMO_HOTSPOTS,
  generateDemoSummary,
} from './demo-data';

import {
  INDIA_CENTER,
  INDIA_ZOOM,
} from './constants';


/*
 * =========================================================
 * GLOBAL STATE INTERFACE
 * =========================================================
 */

interface GlobalState {
  hotspots: ClassifiedHotspot[];

  analyticsSummary: any;

  loading: boolean;

  error: string | null;

  isDemoMode: boolean;

  selectedHotspot: ClassifiedHotspot | null;

  setSelectedHotspot: (
    hotspot: ClassifiedHotspot | null
  ) => void;

  mapStyle: string;

  setMapStyle: (
    style: string
  ) => void;

  streamFilter: string;

  setStreamFilter: (
    filter: string
  ) => void;

  mapCenter: [number, number];

  setMapCenter: (
    center: [number, number]
  ) => void;

  mapZoom: number;

  setMapZoom: (
    zoom: number
  ) => void;

  refreshData: () => Promise<void>;
}


/*
 * =========================================================
 * CONTEXT
 * =========================================================
 */

const GlobalStateContext =
  createContext<GlobalState | undefined>(
    undefined
  );


/*
 * =========================================================
 * PROVIDER
 * =========================================================
 */

export function GlobalStateProvider({
  children,
}: {
  children: ReactNode;
}) {

  /*
   * -------------------------------------------------------
   * HOTSPOTS
   * -------------------------------------------------------
   */

  const [
    hotspots,
    setHotspots,
  ] = useState<ClassifiedHotspot[]>([]);


  /*
   * -------------------------------------------------------
   * ANALYTICS
   * -------------------------------------------------------
   */

  const [
    analyticsSummary,
    setAnalyticsSummary,
  ] = useState<any>(null);


  /*
   * -------------------------------------------------------
   * LOADING
   * -------------------------------------------------------
   */

  const [
    loading,
    setLoading,
  ] = useState(true);


  /*
   * -------------------------------------------------------
   * ERROR
   * -------------------------------------------------------
   */

  const [
    error,
    setError,
  ] = useState<string | null>(null);


  /*
   * -------------------------------------------------------
   * DEMO MODE
   * -------------------------------------------------------
   */

  const [
    isDemoMode,
    setIsDemoMode,
  ] = useState(false);


  /*
   * =======================================================
   * SELECTED HOTSPOT
   * =======================================================
   */

  const [
    selectedHotspot,
    setSelectedHotspotState,
  ] = useState<ClassifiedHotspot | null>(
    null
  );


  const setSelectedHotspot = (
    hotspot: ClassifiedHotspot | null
  ) => {

    setSelectedHotspotState(
      hotspot
    );


    /*
     * Persist ONLY the UI selection.
     *
     * OSM context itself is NOT stored in localStorage.
     * Supabase is the persistent OSM cache.
     */

    if (
      typeof window !== 'undefined'
    ) {

      if (hotspot) {

        localStorage.setItem(
          'vtx_selectedHotspot',
          hotspot.id
        );

      } else {

        localStorage.removeItem(
          'vtx_selectedHotspot'
        );
      }
    }
  };


  /*
   * =======================================================
   * MAP STYLE
   * =======================================================
   */

  const [
    mapStyle,
    setMapStyleState,
  ] = useState<string>(
    'Carto Dark Matter'
  );


  const setMapStyle = (
    style: string
  ) => {

    setMapStyleState(
      style
    );


    if (
      typeof window !== 'undefined'
    ) {

      localStorage.setItem(
        'vtx_mapStyle',
        style
      );
    }
  };


  /*
   * =======================================================
   * STREAM FILTER
   * =======================================================
   */

  const [
    streamFilter,
    setStreamFilterState,
  ] = useState<string>(
    'ALL'
  );


  const setStreamFilter = (
    filter: string
  ) => {

    setStreamFilterState(
      filter
    );


    if (
      typeof window !== 'undefined'
    ) {

      localStorage.setItem(
        'vtx_streamFilter',
        filter
      );
    }
  };


  /*
   * =======================================================
   * MAP CENTER
   * =======================================================
   */

  const [
    mapCenter,
    setMapCenterState,
  ] = useState<[number, number]>(
    INDIA_CENTER
  );


  const setMapCenter = (
    center: [number, number]
  ) => {

    setMapCenterState(
      center
    );


    if (
      typeof window !== 'undefined'
    ) {

      localStorage.setItem(
        'vtx_mapCenter',
        JSON.stringify(center)
      );
    }
  };


  /*
   * =======================================================
   * MAP ZOOM
   * =======================================================
   */

  const [
    mapZoom,
    setMapZoomState,
  ] = useState<number>(
    INDIA_ZOOM
  );


  const setMapZoom = (
    zoom: number
  ) => {

    setMapZoomState(
      zoom
    );


    if (
      typeof window !== 'undefined'
    ) {

      localStorage.setItem(
        'vtx_mapZoom',
        zoom.toString()
      );
    }
  };


  /*
   * =======================================================
   * RESTORE UI STATE
   * =======================================================
   *
   * localStorage is used only for:
   *
   *   - selected hotspot
   *   - map style
   *   - filter
   *   - map center
   *   - map zoom
   *
   * OSM enrichment is NOT stored here.
   */

  useEffect(() => {

    if (
      typeof window === 'undefined'
    ) {
      return;
    }


    /*
     * Map style
     */

    const savedStyle =
      localStorage.getItem(
        'vtx_mapStyle'
      );

    if (savedStyle) {

      setMapStyleState(
        savedStyle
      );
    }


    /*
     * Stream filter
     */

    const savedFilter =
      localStorage.getItem(
        'vtx_streamFilter'
      );

    if (savedFilter) {

      setStreamFilterState(
        savedFilter
      );
    }


    /*
     * Map center
     */

    const savedCenter =
      localStorage.getItem(
        'vtx_mapCenter'
      );


    if (savedCenter) {

      try {

        const parsed =
          JSON.parse(
            savedCenter
          );


        if (
          Array.isArray(parsed) &&
          parsed.length === 2 &&
          typeof parsed[0] === 'number' &&
          typeof parsed[1] === 'number'
        ) {

          setMapCenterState(
            parsed as [number, number]
          );
        }

      } catch {

        /*
         * Ignore malformed map center.
         */
      }
    }


    /*
     * Map zoom
     */

    const savedZoom =
      localStorage.getItem(
        'vtx_mapZoom'
      );


    if (savedZoom) {

      const parsedZoom =
        parseFloat(
          savedZoom
        );


      if (
        Number.isFinite(parsedZoom)
      ) {

        setMapZoomState(
          parsedZoom
        );
      }
    }

  }, []);


  /*
   * =======================================================
   * REFRESH DATA
   * =======================================================
   *
   * COMPLETE VERTEX DATA PIPELINE
   *
   * 1. Fetch current classified FIRMS hotspots.
   *
   * 2. Immediately display them.
   *
   * 3. Select current highest-priority 50.
   *
   * 4. Send ONLY those 50 to the backend.
   *
   * 5. Backend checks Supabase OSM cache.
   *
   * 6. Cache HIT:
   *        return cached context
   *        NO Overpass request.
   *
   * 7. Cache MISS:
   *        query Overpass
   *        save result to Supabase.
   *
   * 8. Refetch classified hotspots so the UI receives
   *    the newly persisted OSM contexts.
   *
   * 9. Fetch analytics.
   *
   */

  const refreshData = async () => {

    try {

      setLoading(
        true
      );

      setError(
        null
      );


      /*
       * =====================================================
       * STEP 1
       * FETCH CURRENT HOTSPOTS
       * =====================================================
       */

      const initialData =
        await fetchClassifiedHotspots(
          'IND',
          1
        );


      /*
       * Show FIRMS/classification data immediately.
       */

      setHotspots(
        initialData
      );


      setIsDemoMode(
        false
      );


      /*
       * =====================================================
       * RESTORE SELECTED HOTSPOT
       * =====================================================
       */

      if (
        typeof window !== 'undefined'
      ) {

        const savedId =
          localStorage.getItem(
            'vtx_selectedHotspot'
          );


        if (savedId) {

          const found =
            initialData.find(
              (
                hotspot: ClassifiedHotspot
              ) =>
                hotspot.id === savedId
            );


          setSelectedHotspotState(
            found || null
          );
        }
      }


      /*
       * =====================================================
       * STEP 2
       * TOP-50 OSM ENRICHMENT
       * =====================================================
       *
       * IMPORTANT:
       *
       * The API function handles the conversion:
       *
       *     VTX-506
       *
       * into:
       *
       *     506
       *
       * before sending the IDs to the backend.
       *
       * The backend then performs the persistent cache
       * lookup using coordinates.
       */

      await enrichTop50Hotspots(
        initialData
      );


      /*
       * =====================================================
       * STEP 3
       * REFETCH ENRICHED DATA
       * =====================================================
       *
       * The backend has now updated the persistent
       * classification/OSM context.
       *
       * Fetch the data again so the frontend gets the
       * newly available context.
       */

      const enrichedData =
        await fetchClassifiedHotspots(
          'IND',
          1
        );


      setHotspots(
        enrichedData
      );


      /*
       * =====================================================
       * RESTORE SELECTED HOTSPOT AGAIN
       * =====================================================
       *
       * This second restore is important because the first
       * selected object may have been created before the
       * OSM enrichment finished.
       */

      if (
        typeof window !== 'undefined'
      ) {

        const savedId =
          localStorage.getItem(
            'vtx_selectedHotspot'
          );


        if (savedId) {

          const found =
            enrichedData.find(
              (
                hotspot: ClassifiedHotspot
              ) =>
                hotspot.id === savedId
            );


          setSelectedHotspotState(
            found || null
          );
        }
      }


      /*
       * =====================================================
       * STEP 4
       * ANALYTICS
       * =====================================================
       */

      const summary =
        await fetchAnalyticsSummary();


      setAnalyticsSummary(
        summary
      );


      setIsDemoMode(
        false
      );

    } catch (err: any) {

      /*
       * =====================================================
       * DEMO FALLBACK
       * =====================================================
       *
       * If the database/backend is unavailable, keep the
       * dashboard usable with the local demo dataset.
       */

      console.warn(
        'Database connection failed. Falling back to offline demo cache.',
        err
      );


      setHotspots(
        DEMO_HOTSPOTS
      );


      setAnalyticsSummary(
        generateDemoSummary(
          DEMO_HOTSPOTS
        )
      );


      setIsDemoMode(
        true
      );


      setError(
        err?.message ||
        'Unable to connect to live backend.'
      );


      /*
       * Restore selected demo hotspot.
       */

      if (
        typeof window !== 'undefined'
      ) {

        const savedId =
          localStorage.getItem(
            'vtx_selectedHotspot'
          );


        if (savedId) {

          const found =
            DEMO_HOTSPOTS.find(
              (hotspot) =>
                hotspot.id === savedId
            );


          setSelectedHotspotState(
            found || null
          );
        }
      }

    } finally {

      setLoading(
        false
      );
    }
  };


  /*
   * =======================================================
   * INITIAL LOAD
   * =======================================================
   */

  useEffect(() => {

    refreshData();

  }, []);


  /*
   * =======================================================
   * PROVIDER
   * =======================================================
   */

  return (
    <GlobalStateContext.Provider
      value={{
        hotspots,

        analyticsSummary,

        loading,

        error,

        isDemoMode,

        selectedHotspot,

        setSelectedHotspot,

        mapStyle,

        setMapStyle,

        streamFilter,

        setStreamFilter,

        mapCenter,

        setMapCenter,

        mapZoom,

        setMapZoom,

        refreshData,
      }}
    >
      {children}
    </GlobalStateContext.Provider>
  );
}


/*
 * =========================================================
 * HOOK
 * =========================================================
 */

export function useGlobalState() {

  const context =
    useContext(
      GlobalStateContext
    );


  if (
    context === undefined
  ) {

    throw new Error(
      'useGlobalState must be used within a GlobalStateProvider'
    );
  }


  return context;
}