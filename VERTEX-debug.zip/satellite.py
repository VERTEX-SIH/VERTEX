from fastapi import APIRouter, Query, HTTPException

from services.satellite_service import fetch_satellite_evidence

router = APIRouter(prefix="/satellite", tags=["Satellite Data"])


@router.get("/evidence")
async def get_satellite_evidence(
    latitude: float = Query(..., ge=-90, le=90),
    longitude: float = Query(..., ge=-180, le=180),
    acq_date: str = Query(...),
    acq_time: str = Query("0000"),
):
    result = await fetch_satellite_evidence(latitude, longitude, acq_date, acq_time)
    if not result:
        raise HTTPException(status_code=404, detail="No Sentinel-2 satellite evidence available")
    return result
