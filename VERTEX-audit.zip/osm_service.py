import math
import logging
import httpx

from datetime import datetime, timedelta, timezone
from typing import Dict, Any, List, Optional

from models.hotspot import FIRMSHotspot
from models.classification import OSMContext
from services.status import service_status
from services.facility_service import find_nearby_facilities
from db.supabase_client import supabase_service


logger = logging.getLogger(__name__)


# =========================================================
# CONFIG
# =========================================================

OVERPASS_MIRRORS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://overpass.openstreetmap.ru/api/interpreter",
]

OVERPASS_TIMEOUT_SECONDS = 8.0

# Only used for temporary in-memory caching.
OSM_CACHE_TTL = timedelta(minutes=15)

_live_osm_cache: Dict[str, OSMContext] = {}

OVERPASS_HEADERS = {
    "User-Agent": "VERTEX/1.0 (OpenStreetMap facility context)",
    "Accept": "application/json",
}


# =========================================================
# BASIC HELPERS
# =========================================================

def _cache_key(
    lat: float,
    lon: float,
    radius: int,
) -> str:
    return f"{lat:.5f}:{lon:.5f}:{radius}"


def _now_iso() -> str:
    return datetime.now(
        timezone.utc
    ).isoformat()


# =========================================================
# PERSISTENT SUPABASE CACHE
# =========================================================

def _context_to_cache_row(
    hotspot: FIRMSHotspot,
    context: OSMContext,
    hotspot_id: Optional[int] = None,
) -> Dict[str, Any]:

    return {
        # Can be NULL because cache identity is lat/lon.
        "hotspot_id": hotspot_id,

        "latitude": hotspot.latitude,
        "longitude": hotspot.longitude,

        "nearby_facilities": (
            context.nearby_facilities or []
        ),

        "nearest_facility_distance": (
            context.nearest_facility_distance
        ),

        "nearest_facility_type": (
            context.nearest_facility_type
        ),

        "facility_count_in_radius": (
            context.facility_count_in_radius
        ),

        "land_use_context": (
            context.land_use_context or []
        ),

        "osm_source": context.osm_source,

        "queried_at": (
            context.queried_at
            or _now_iso()
        ),
    }


def _context_from_cache_row(
    row: Dict[str, Any],
) -> Optional[OSMContext]:

    try:

        return OSMContext(
            nearby_facilities=(
                row.get(
                    "nearby_facilities",
                    [],
                )
                or []
            ),

            nearest_facility_distance=(
                row.get(
                    "nearest_facility_distance"
                )
            ),

            nearest_facility_type=(
                row.get(
                    "nearest_facility_type"
                )
            ),

            facility_count_in_radius=int(
                row.get(
                    "facility_count_in_radius",
                    0,
                )
                or 0
            ),

            land_use_context=(
                row.get(
                    "land_use_context",
                    [],
                )
                or []
            ),

            osm_source=(
                row.get(
                    "osm_source",
                    "CACHED",
                )
            ),

            queried_at=(
                row.get("queried_at")
            ),
        )

    except Exception as e:

        logger.warning(
            f"Invalid OSM cache row: {e}"
        )

        return None


def _get_supabase_cached_context(
    hotspot: FIRMSHotspot,
) -> Optional[OSMContext]:

    try:

        # =================================================
        # PRIMARY CACHE KEY = LATITUDE + LONGITUDE
        # =================================================

        result = (
            supabase_service
            .table("osm_context_cache")
            .select("*")
            .eq(
                "latitude",
                hotspot.latitude,
            )
            .eq(
                "longitude",
                hotspot.longitude,
            )
            .limit(1)
            .execute()
        )

        rows = result.data or []

        if rows:

            context = (
                _context_from_cache_row(
                    rows[0]
                )
            )

            if context:

                logger.info(
                    "OSM SUPABASE CACHE HIT: "
                    f"{hotspot.latitude},"
                    f"{hotspot.longitude}"
                )

                return context

        logger.info(
            "OSM SUPABASE CACHE MISS: "
            f"{hotspot.latitude},"
            f"{hotspot.longitude}"
        )

        return None

    except Exception as e:

        logger.warning(
            "Supabase OSM cache lookup failed: "
            f"{e}"
        )

        return None


def _save_supabase_cached_context(
    hotspot: FIRMSHotspot,
    context: OSMContext,
    hotspot_id: Optional[int] = None,
) -> bool:

    try:

        row = _context_to_cache_row(
            hotspot,
            context,
            hotspot_id=hotspot_id,
        )

        # =================================================
        # FIND EXISTING ROW BY COORDINATES
        # =================================================

        existing = (
            supabase_service
            .table("osm_context_cache")
            .select("id")
            .eq(
                "latitude",
                hotspot.latitude,
            )
            .eq(
                "longitude",
                hotspot.longitude,
            )
            .limit(1)
            .execute()
        )

        existing_rows = (
            existing.data or []
        )

        if existing_rows:

            cache_id = (
                existing_rows[0]["id"]
            )

            (
                supabase_service
                .table("osm_context_cache")
                .update(row)
                .eq(
                    "id",
                    cache_id,
                )
                .execute()
            )

        else:

            (
                supabase_service
                .table("osm_context_cache")
                .insert(row)
                .execute()
            )

        logger.info(
            "OSM SUPABASE CACHE SAVED: "
            f"{hotspot.latitude},"
            f"{hotspot.longitude}"
        )

        return True

    except Exception as e:

        logger.error(
            "Failed to save OSM context "
            f"to Supabase cache: {e}"
        )

        return False


# =========================================================
# MEMORY CACHE
# =========================================================

def _is_valid_live_context(
    context: Optional[OSMContext],
) -> bool:

    if not context:
        return False

    if context.osm_source not in (
        "LIVE",
        "CACHED",
    ):
        return False

    if not context.nearby_facilities:
        return False

    if not context.queried_at:
        return False

    try:

        queried_at = datetime.fromisoformat(
            context.queried_at.replace(
                "Z",
                "+00:00",
            )
        )

        return queried_at >= (
            datetime.now(timezone.utc)
            - OSM_CACHE_TTL
        )

    except (
        TypeError,
        ValueError,
    ):

        return False


def _as_cached(
    context: OSMContext,
) -> OSMContext:

    return OSMContext(
        nearby_facilities=(
            context.nearby_facilities
        ),

        nearest_facility_distance=(
            context.nearest_facility_distance
        ),

        nearest_facility_type=(
            context.nearest_facility_type
        ),

        facility_count_in_radius=(
            context.facility_count_in_radius
        ),

        land_use_context=(
            context.land_use_context
        ),

        osm_source="CACHED",

        queried_at=(
            context.queried_at
        ),
    )


# =========================================================
# CONTEXT BUILDER
# =========================================================

def _context_from_facilities(
    facilities: List[Dict[str, Any]],
    source: str,
    hotspot: FIRMSHotspot,
    queried_at: Optional[str] = None,
    land_use_context: Optional[List[str]] = None,
) -> OSMContext:

    nearby = []

    for fac in facilities:

        dist = fac.get(
            "distance_m"
        )

        if dist is None:

            dist = haversine_distance(
                hotspot.latitude,
                hotspot.longitude,
                fac["latitude"],
                fac["longitude"],
            )

        name = (
            fac.get("name")
            or "Unknown Facility"
        )

        nearby.append(
            {
                "type": fac.get(
                    "type",
                    "industrial",
                ),

                "distance_m": round(
                    dist,
                    2,
                ),

                "name": name,
            }
        )

    nearby.sort(
        key=lambda facility:
            facility["distance_m"]
    )

    if not nearby:

        return OSMContext(
            nearby_facilities=[],

            nearest_facility_distance=None,

            nearest_facility_type=None,

            facility_count_in_radius=0,

            land_use_context=(
                land_use_context or []
            ),

            osm_source=source,

            queried_at=queried_at,
        )

    # Prefer named facility.
    named_facilities = [
        facility
        for facility in nearby
        if facility.get("name")
        and facility["name"]
        .strip()
        .lower()
        != "unknown facility"
    ]

    nearest = (
        named_facilities[0]
        if named_facilities
        else nearby[0]
    )

    return OSMContext(
        nearby_facilities=nearby,

        nearest_facility_distance=(
            nearest["distance_m"]
        ),

        nearest_facility_type=(
            nearest["type"]
        ),

        facility_count_in_radius=len(
            nearby
        ),

        land_use_context=(
            land_use_context or []
        ),

        osm_source=source,

        queried_at=queried_at,
    )


# =========================================================
# OVERPASS QUERY
# =========================================================

async def query_overpass(
    lat: float,
    lon: float,
    radius: int = 5000,
) -> Optional[Dict[str, Any]]:

    query = f"""
    [out:json][timeout:25];
    (
      node["man_made"="works"](around:{radius},{lat},{lon});
      way["man_made"="works"](around:{radius},{lat},{lon});
      relation["man_made"="works"](around:{radius},{lat},{lon});

      node["landuse"="industrial"](around:{radius},{lat},{lon});
      way["landuse"="industrial"](around:{radius},{lat},{lon});
      relation["landuse"="industrial"](around:{radius},{lat},{lon});

      node["power"="plant"](around:{radius},{lat},{lon});
      way["power"="plant"](around:{radius},{lat},{lon});
      relation["power"="plant"](around:{radius},{lat},{lon});

      node["power"="generator"](around:{radius},{lat},{lon});
      way["power"="generator"](around:{radius},{lat},{lon});
      relation["power"="generator"](around:{radius},{lat},{lon});

      node["man_made"="mineshaft"](around:{radius},{lat},{lon});
      way["landuse"="quarry"](around:{radius},{lat},{lon});
      relation["landuse"="quarry"](around:{radius},{lat},{lon});

      way["landuse"="farmland"](around:{radius},{lat},{lon});
      relation["landuse"="farmland"](around:{radius},{lat},{lon});

      way["landuse"="orchard"](around:{radius},{lat},{lon});
      relation["landuse"="orchard"](around:{radius},{lat},{lon});

      way["landuse"="vineyard"](around:{radius},{lat},{lon});
      relation["landuse"="vineyard"](around:{radius},{lat},{lon});

      way["landuse"="forest"](around:{radius},{lat},{lon});
      relation["landuse"="forest"](around:{radius},{lat},{lon});

      way["natural"="wood"](around:{radius},{lat},{lon});
      relation["natural"="wood"](around:{radius},{lat},{lon});

      way["natural"="grassland"](around:{radius},{lat},{lon});
      relation["natural"="grassland"](around:{radius},{lat},{lon});

      way["landuse"="brownfield"](around:{radius},{lat},{lon});
      relation["landuse"="brownfield"](around:{radius},{lat},{lon});

      way["landuse"="commercial"](around:{radius},{lat},{lon});
      relation["landuse"="commercial"](around:{radius},{lat},{lon});

      way["landuse"="residential"](around:{radius},{lat},{lon});
      relation["landuse"="residential"](around:{radius},{lat},{lon});

      way["natural"="wetland"](around:{radius},{lat},{lon});
      relation["natural"="wetland"](around:{radius},{lat},{lon});
    );

    out center;
    """

    timeout = httpx.Timeout(
        20.0,
        connect=15.0,
    )

    async with httpx.AsyncClient(
        verify=False,
        timeout=timeout,
        headers=OVERPASS_HEADERS,
    ) as client:

        for attempt in range(2):

            for mirror in OVERPASS_MIRRORS:

                try:

                    response = await client.post(
                        mirror,
                        data={
                            "data": query
                        },
                        headers=OVERPASS_HEADERS,
                    )

                    if response.status_code != 200:

                        logger.warning(
                            f"Overpass mirror "
                            f"{mirror} returned "
                            f"HTTP "
                            f"{response.status_code}"
                        )

                        continue

                    data = response.json()

                    facilities = []

                    land_use_context = set()

                    for el in data.get(
                        "elements",
                        [],
                    ):

                        tags = el.get(
                            "tags",
                            {},
                        )

                        lat_el = (
                            el.get("lat")
                            or el.get(
                                "center",
                                {},
                            ).get("lat")
                        )

                        lon_el = (
                            el.get("lon")
                            or el.get(
                                "center",
                                {},
                            ).get("lon")
                        )

                        if (
                            lat_el is None
                            or lon_el is None
                        ):
                            continue

                        landuse = tags.get(
                            "landuse"
                        )

                        natural = tags.get(
                            "natural"
                        )

                        man_made = tags.get(
                            "man_made"
                        )

                        power = tags.get(
                            "power"
                        )

                        is_facility = (
                            landuse == "industrial"
                            or man_made == "works"
                            or power in (
                                "plant",
                                "generator",
                            )
                            or landuse == "quarry"
                            or man_made
                            == "mineshaft"
                        )

                        if is_facility:

                            if power == "plant":

                                facility_type = (
                                    "power_plant"
                                )

                            elif power == "generator":

                                facility_type = (
                                    "power_generator"
                                )

                            elif landuse == "quarry":

                                facility_type = (
                                    "quarry"
                                )

                            elif (
                                man_made
                                == "mineshaft"
                            ):

                                facility_type = (
                                    "mine"
                                )

                            else:

                                facility_type = (
                                    tags.get(
                                        "industrial"
                                    )
                                    or man_made
                                    or landuse
                                    or "industrial"
                                )

                            facilities.append(
                                {
                                    "name": tags.get(
                                        "name",
                                        "Unknown Facility",
                                    ),

                                    "type":
                                        facility_type,

                                    "latitude":
                                        lat_el,

                                    "longitude":
                                        lon_el,
                                }
                            )

                        context_value = (
                            landuse
                            or natural
                            or power
                        )

                        if context_value:

                            land_use_context.add(
                                context_value
                            )

                    logger.info(
                        f"Overpass success: "
                        f"{mirror} | "
                        f"facilities="
                        f"{len(facilities)}"
                    )

                    return {
                        "facilities":
                            facilities,

                        "land_use_context":
                            sorted(
                                land_use_context
                            ),
                    }

                except Exception as e:

                    logger.warning(
                        f"Overpass mirror "
                        f"{mirror} failed "
                        f"(attempt "
                        f"{attempt + 1}): "
                        f"{e}"
                    )

                    continue

    return None


# =========================================================
# HAVERSINE
# =========================================================

def haversine_distance(
    lat1: float,
    lon1: float,
    lat2: float,
    lon2: float,
) -> float:

    R = 6371000

    phi1 = math.radians(
        lat1
    )

    phi2 = math.radians(
        lat2
    )

    delta_phi = math.radians(
        lat2 - lat1
    )

    delta_lambda = math.radians(
        lon2 - lon1
    )

    a = (
        math.sin(
            delta_phi / 2.0
        ) ** 2

        + math.cos(phi1)
        * math.cos(phi2)
        * math.sin(
            delta_lambda / 2.0
        ) ** 2
    )

    c = 2 * math.atan2(
        math.sqrt(a),
        math.sqrt(1 - a),
    )

    return R * c


# =========================================================
# MAIN ENRICHMENT PIPELINE
# =========================================================

async def enrich_hotspot(
    hotspot: FIRMSHotspot,
    existing_context: Optional[OSMContext] = None,
    force_refresh: bool = False,
    hotspot_id: Optional[int] = None,
) -> OSMContext:

    # =====================================================
    # 1. SUPABASE PERSISTENT CACHE
    # =====================================================

    if not force_refresh:

        persistent_context = (
            _get_supabase_cached_context(
                hotspot
            )
        )

        if persistent_context:

            service_status["osm"] = {
                "status": "CACHED",
                "source": "SUPABASE_CACHE",
            }

            # Populate memory cache too.
            _live_osm_cache[
                _cache_key(
                    hotspot.latitude,
                    hotspot.longitude,
                    5000,
                )
            ] = persistent_context

            return _as_cached(
                persistent_context
            )

    # =====================================================
    # 2. MEMORY CACHE
    # =====================================================

    if not force_refresh:

        cached_context = (
            _live_osm_cache.get(
                _cache_key(
                    hotspot.latitude,
                    hotspot.longitude,
                    5000,
                )
            )
        )

        if _is_valid_live_context(
            cached_context
        ):

            service_status["osm"] = {
                "status": "CACHED",
                "source": "MEMORY",
            }

            return _as_cached(
                cached_context
            )

    # =====================================================
    # 3. EXISTING CONTEXT
    # =====================================================

    if (
        not force_refresh
        and _is_valid_live_context(
            existing_context
        )
    ):

        service_status["osm"] = {
            "status": "CACHED",
            "source": "EXISTING_CONTEXT",
        }

        return _as_cached(
            existing_context
        )

    # =====================================================
    # 4. LIVE OVERPASS
    # =====================================================

    live_context = await query_overpass(
        hotspot.latitude,
        hotspot.longitude,
        5000,
    )

    if live_context is not None:

        # Compatibility with older tests.
        if isinstance(
            live_context,
            list,
        ):

            live_facilities = (
                live_context
            )

            live_land_use = []

        else:

            live_facilities = (
                live_context.get(
                    "facilities",
                    [],
                )
            )

            live_land_use = (
                live_context.get(
                    "land_use_context",
                    [],
                )
            )

        # =================================================
        # LIVE FACILITIES FOUND
        # =================================================

        if live_facilities:

            service_status["osm"] = {
                "status": "ONLINE",
                "source": "LIVE",
            }

            context = (
                _context_from_facilities(
                    live_facilities,
                    "LIVE",
                    hotspot,
                    queried_at=_now_iso(),
                    land_use_context=(
                        live_land_use
                    ),
                )
            )

            # Memory cache.
            _live_osm_cache[
                _cache_key(
                    hotspot.latitude,
                    hotspot.longitude,
                    5000,
                )
            ] = context

            # Persistent Supabase cache.
            _save_supabase_cached_context(
                hotspot,
                context,
                hotspot_id=hotspot_id,
            )

            return context

        # =================================================
        # LIVE OSM BUT ZERO FACILITIES
        # =================================================

        offline_facilities = (
            find_nearby_facilities(
                hotspot.latitude,
                hotspot.longitude,
                5000,
            )
        )

        if offline_facilities:

            service_status["osm"] = {
                "status": "ONLINE",
                "source": "OFFLINE_CATALOG",
            }

            context = (
                _context_from_facilities(
                    offline_facilities,
                    "OFFLINE_CATALOG",
                    hotspot,
                    queried_at=_now_iso(),
                    land_use_context=(
                        live_land_use
                    ),
                )
            )

            _save_supabase_cached_context(
                hotspot,
                context,
                hotspot_id=hotspot_id,
            )

            return context

        # =================================================
        # LIVE QUERY SUCCEEDED BUT NO FACILITY
        # =================================================

        service_status["osm"] = {
            "status": "ONLINE",
            "source": "LIVE_NO_FACILITY",
        }

        context = OSMContext(
            nearby_facilities=[],
            nearest_facility_distance=None,
            nearest_facility_type=None,
            facility_count_in_radius=0,
            land_use_context=(
                live_land_use
            ),
            osm_source="LIVE_NO_FACILITY",
            queried_at=_now_iso(),
        )

        # IMPORTANT:
        # Cache a legitimate zero-result too.
        # Otherwise we would repeatedly hit Overpass.
        _save_supabase_cached_context(
            hotspot,
            context,
            hotspot_id=hotspot_id,
        )

        return context

    # =====================================================
    # 5. OVERPASS FAILED
    # =====================================================

    cached_context = _live_osm_cache.get(
        _cache_key(
            hotspot.latitude,
            hotspot.longitude,
            5000,
        )
    )

    if _is_valid_live_context(
        cached_context
    ):

        service_status["osm"] = {
            "status": "DEGRADED",
            "source": "CACHED",
        }

        return _as_cached(
            cached_context
        )

    # =====================================================
    # 6. EXISTING CONTEXT FALLBACK
    # =====================================================

    if _is_valid_live_context(
        existing_context
    ):

        service_status["osm"] = {
            "status": "DEGRADED",
            "source": "CACHED",
        }

        return _as_cached(
            existing_context
        )

    # =====================================================
    # 7. OFFLINE FACILITY CATALOG
    # =====================================================

    offline_facilities = (
        find_nearby_facilities(
            hotspot.latitude,
            hotspot.longitude,
            5000,
        )
    )

    if offline_facilities:

        service_status["osm"] = {
            "status": "DEGRADED",
            "source": "OFFLINE_CATALOG",
        }

        context = (
            _context_from_facilities(
                offline_facilities,
                "OFFLINE_CATALOG",
                hotspot,
                queried_at=_now_iso(),
            )
        )

        _save_supabase_cached_context(
            hotspot,
            context,
            hotspot_id=hotspot_id,
        )

        return context

    # =====================================================
    # 8. TOTAL FAILURE
    # =====================================================

    service_status["osm"] = {
        "status": "DEGRADED",
        "source": "FAILED",
    }

    return OSMContext(
        nearby_facilities=[],
        nearest_facility_distance=None,
        nearest_facility_type=None,
        facility_count_in_radius=0,
        land_use_context=[],
        osm_source="FAILED",
        queried_at=None,
    )