from fastapi import (
    APIRouter,
    Query,
    BackgroundTasks,
    HTTPException,
    Request,
    Depends,
)

from typing import (
    List,
    Dict,
    Any,
    Optional,
)

import logging

from services.classifier import classify_and_store
from services.firms_service import fetch_realtime_hotspots
from db.supabase_client import supabase_service
from limiter import limiter
from core.security import verify_admin_user


logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/hotspots",
    tags=["Hotspots"],
)


# =========================================================
# MODULE CACHE
# =========================================================

latest_results = []


# =========================================================
# HELPERS
# =========================================================

def _coordinate_key(
    latitude: Any,
    longitude: Any,
) -> Optional[str]:
    """
    Create a stable coordinate key.

    The OSM cache is fundamentally keyed by hotspot
    coordinates, so this allows /classified to merge
    persistent OSM cache data back into hotspot results.
    """

    try:
        lat = float(latitude)
        lon = float(longitude)

        return f"{lat:.6f},{lon:.6f}"

    except (
        TypeError,
        ValueError,
    ):
        return None


def _normalize_osm_context(
    data: Any,
) -> Dict[str, Any]:
    """
    Normalize any stored OSM context into the structure
    expected by the frontend.
    """

    if not isinstance(data, dict):
        data = {}

    nearby_facilities = (
        data.get("nearby_facilities")
        or []
    )

    land_use_context = (
        data.get("land_use_context")
        or []
    )

    facility_count = (
        data.get("facility_count_in_radius")
    )

    if facility_count is None:
        facility_count = len(
            nearby_facilities
        )

    return {
        "nearby_facilities":
            nearby_facilities,

        "nearest_facility_distance":
            data.get(
                "nearest_facility_distance"
            ),

        "nearest_facility_type":
            data.get(
                "nearest_facility_type"
            ),

        "facility_count_in_radius":
            facility_count,

        "land_use_context":
            land_use_context,

        "osm_source":
            data.get(
                "osm_source",
                "PENDING",
            ),

        "queried_at":
            data.get(
                "queried_at"
            ),
    }


def _load_osm_cache() -> Dict[str, Dict[str, Any]]:
    """
    Load the persistent OSM cache once and index it by
    latitude/longitude.

    This is deliberately done as ONE Supabase query instead
    of querying the cache separately for every hotspot.

    Cache key:

        latitude + longitude

    The most recently queried cache row wins.
    """

    cache_by_coordinate: Dict[
        str,
        Dict[str, Any]
    ] = {}

    try:

        result = (
            supabase_service
            .table("osm_context_cache")
            .select("*")
            .order(
                "queried_at",
                desc=True,
            )
            .execute()
        )

        rows = (
            result.data
            or []
        )

        for row in rows:

            if not isinstance(
                row,
                dict,
            ):
                continue

            key = _coordinate_key(
                row.get("latitude"),
                row.get("longitude"),
            )

            if not key:
                continue

            # Because the query is ordered newest first,
            # don't overwrite an already indexed row.
            if key in cache_by_coordinate:
                continue

            context = _normalize_osm_context(
                row
            )

            # The cache row itself represents persisted
            # OSM knowledge. The original source is kept
            # as LIVE/OFFLINE_CATALOG etc. in the database,
            # but the frontend should know this result came
            # from the persistent cache.
            original_source = (
                context.get("osm_source")
            )

            if original_source in (
                "LIVE",
                "LIVE_NO_FACILITY",
                "OFFLINE_CATALOG",
            ):
                context["osm_source"] = (
                    "CACHED"
                    if context[
                        "facility_count_in_radius"
                    ] > 0
                    else "CACHED_NO_FACILITY"
                )

            cache_by_coordinate[key] = context

        logger.info(
            "Loaded %d persistent OSM cache entries",
            len(cache_by_coordinate),
        )

    except Exception as e:

        logger.warning(
            "Could not load persistent OSM cache: %s",
            e,
        )

    return cache_by_coordinate


def _select_primary_classification(
    class_data: Any,
) -> Dict[str, Any]:
    """
    Select the newest classification record.
    """

    if not isinstance(
        class_data,
        list,
    ):
        return {}

    valid = [
        item
        for item in class_data
        if isinstance(
            item,
            dict,
        )
    ]

    if not valid:
        return {}

    valid.sort(
        key=lambda x: x.get("created_at", "") or "",
        reverse=True,
    )

    return valid[0]


def _select_legacy_osm_context(
    stored_contexts: Any,
) -> Dict[str, Any]:
    """
    Select the newest context from the legacy
    osm_contexts table.
    """

    if not isinstance(
        stored_contexts,
        list,
    ):
        return {}

    valid = [
        item
        for item in stored_contexts
        if isinstance(
            item,
            dict,
        )
    ]

    if not valid:
        return {}

    valid.sort(
        key=lambda x:
            x.get(
                "id",
                0,
            )
            or 0,
        reverse=True,
    )

    row = valid[0]

    data = (
        row.get(
            "data",
            {},
        )
        or {}
    )

    if not isinstance(
        data,
        dict,
    ):
        data = {}

    data = dict(
        data
    )

    data.setdefault(
        "facility_count_in_radius",
        row.get(
            "facility_count_in_radius",
            0,
        ),
    )

    return _normalize_osm_context(
        data
    )


# =========================================================
# CLASSIFIED HOTSPOTS
# =========================================================


def _normalize_acq_time(value: Any) -> str:
    """Normalize FIRMS acquisition time so DB/FIRMS records can be matched."""
    if value is None:
        return ""
    text = str(value).strip()
    if not text:
        return ""
    digits = "".join(ch for ch in text if ch.isdigit())
    if digits:
        return digits.zfill(4)[-4:]
    return text


def _stored_observation_key(row: Dict[str, Any]) -> Optional[tuple]:
    """Build an exact FIRMS observation key from a stored hotspot row."""
    try:
        lat = round(float(row.get("latitude")), 6)
        lon = round(float(row.get("longitude")), 6)
    except (TypeError, ValueError):
        return None

    acq_date = str(row.get("acq_date") or "")[:10]
    acq_time = _normalize_acq_time(row.get("acq_time"))
    return lat, lon, acq_date, acq_time


@router.get("/classified")
@limiter.limit("60/minute")
async def get_classified_hotspots(
    request: Request,
    country: str = Query("IND"),
    days: int = Query(1, ge=1, le=30),
    classification: Optional[str] = None,
    min_frp: Optional[float] = None,
    max_frp: Optional[float] = None,
    min_confidence: Optional[str] = None,
    risk_level: Optional[str] = None,
    limit: int = Query(50, ge=1, le=1000),
):
    """
    Return FIRMS observations merged with the latest stored VERTEX
    classification and OSM context.

    days=1 is a true live working set: FIRMS is the source of truth for
    which observations currently exist. Stored database rows only provide
    enrichment for those live observations; old rows cannot keep a stale
    hotspot alive on the dashboard.

    For days>1, the persisted hotspots table is used as the historical
    working set, preserving the existing date-window behavior.
    """

    try:
        from datetime import date, timedelta
        from shapely.geometry import Point
        from services.firms_service import _INDIA_BOUNDARY_SHAPE

        # -------------------------------------------------------------
        # LOAD PERSISTED DATA / CACHE
        # -------------------------------------------------------------
        query = (
            supabase_service
            .table("hotspots")
            .select("*, classifications(*), osm_contexts(*)")
            .order("frp", desc=True)
        )

        if min_frp is not None:
            query = query.gte("frp", min_frp)

        if max_frp is not None:
            query = query.lte("frp", max_frp)

        records = query.execute().data or []
        osm_cache = _load_osm_cache()

        # -------------------------------------------------------------
        # LIVE MODE: FIRMS IS THE SOURCE OF TRUTH
        # -------------------------------------------------------------
        live_observations = None
        stored_by_observation = {}
        stored_by_coordinate = {}

        if days == 1:
            live_observations = await fetch_realtime_hotspots(
                country=country,
                days=1,
            )

            for row in records:
                if not isinstance(row, dict):
                    continue
                exact_key = _stored_observation_key(row)
                if exact_key:
                    stored_by_observation[exact_key] = row

                try:
                    coord_key = (
                        round(float(row.get("latitude")), 6),
                        round(float(row.get("longitude")), 6),
                    )
                    stored_by_coordinate.setdefault(coord_key, row)
                except (TypeError, ValueError):
                    pass

            working_records = []

            for obs in live_observations:
                obs_data = obs.dict()
                exact_key = _stored_observation_key(obs_data)
                stored_row = stored_by_observation.get(exact_key)

                if stored_row is None:
                    try:
                        coord_key = (
                            round(float(obs.longitude), 6),
                            round(float(obs.latitude), 6),
                        )
                    except (TypeError, ValueError):
                        coord_key = None
                    if coord_key is not None:
                        candidate = stored_by_coordinate.get(coord_key)
                        if candidate:
                            same_date = str(candidate.get("acq_date") or "")[:10] == str(obs.acq_date or "")[:10]
                            same_time = _normalize_acq_time(candidate.get("acq_time")) == _normalize_acq_time(obs.acq_time)
                            if same_date and same_time:
                                stored_row = candidate

                working_records.append((obs_data, stored_row))

        else:
            cutoff = date.today() - timedelta(days=max(days - 1, 0))
            working_records = []

            for row in records:
                if not isinstance(row, dict):
                    continue

                acq_date = row.get("acq_date")
                try:
                    if (
                        acq_date
                        and date.fromisoformat(str(acq_date)[:10]) < cutoff
                    ):
                        continue
                except ValueError:
                    pass

                working_records.append((row, row))

        features = []

        for source_data, stored_row in working_records:
            # ---------------------------------------------------------
            # NORMALIZE OBSERVATION
            # ---------------------------------------------------------
            if stored_row is not None:
                r = stored_row
                lat = r.get("latitude")
                lon = r.get("longitude")
            else:
                r = source_data
                lat = source_data.get("latitude")
                lon = source_data.get("longitude")

            try:
                lat_f = float(lat)
                lon_f = float(lon)
            except (TypeError, ValueError):
                continue

            # ---------------------------------------------------------
            # INDIA FILTER
            # ---------------------------------------------------------
            if country.upper() == "IND":
                if (
                    _INDIA_BOUNDARY_SHAPE is None
                    or not _INDIA_BOUNDARY_SHAPE.covers(Point(lon_f, lat_f))
                ):
                    continue

            # ---------------------------------------------------------
            # FRP FILTER
            # ---------------------------------------------------------
            frp_value = source_data.get("frp", r.get("frp", 0))
            try:
                frp_value = float(frp_value or 0)
            except (TypeError, ValueError):
                frp_value = 0.0

            if min_frp is not None and frp_value < float(min_frp):
                continue
            if max_frp is not None and frp_value > float(max_frp):
                continue

            # ---------------------------------------------------------
            # LATEST CLASSIFICATION
            # ---------------------------------------------------------
            primary_class = {}
            if stored_row is not None:
                primary_class = _select_primary_classification(
                    stored_row.get("classifications", []) or []
                )

            if not primary_class:
                primary_class = {
                    "classification": "UNCLASSIFIED",
                    "confidence_score": 0,
                    "explanation": "Awaiting AI classification.",
                    "evidence": [],
                    "risk_score": 0,
                    "risk_level": "LOW",
                }

            # ---------------------------------------------------------
            # OSM CONTEXT
            # ---------------------------------------------------------
            primary_osm: Dict[str, Any] = {}

            if stored_row is not None:
                classification_osm = primary_class.get("osm_context")
                if isinstance(classification_osm, dict) and classification_osm:
                    primary_osm = _normalize_osm_context(classification_osm)

                if not primary_osm:
                    primary_osm = _select_legacy_osm_context(
                        stored_row.get("osm_contexts", []) or []
                    )

            cache_key = _coordinate_key(lat_f, lon_f)
            cached_osm = osm_cache.get(cache_key) if cache_key else None

            if cached_osm:
                primary_osm = cached_osm

            if not primary_osm:
                primary_osm = {
                    "nearby_facilities": [],
                    "nearest_facility_distance": None,
                    "nearest_facility_type": None,
                    "facility_count_in_radius": 0,
                    "land_use_context": [],
                    "osm_source": "PENDING",
                    "queried_at": None,
                }
            else:
                primary_osm = _normalize_osm_context(primary_osm)

            # ---------------------------------------------------------
            # UI FILTERS
            # ---------------------------------------------------------
            if (
                classification
                and primary_class.get("classification") != classification
            ):
                continue

            if (
                risk_level
                and primary_class.get("risk_level") != risk_level
            ):
                continue

            if min_confidence is not None:
                try:
                    if float(primary_class.get("confidence_score", 0) or 0) < float(min_confidence):
                        continue
                except (TypeError, ValueError):
                    pass

            # ---------------------------------------------------------
            # GEOJSON HOTSPOT PAYLOAD
            # ---------------------------------------------------------
            hotspot_payload = dict(r) if isinstance(r, dict) else {}
            hotspot_payload.update({
                "latitude": lat_f,
                "longitude": lon_f,
                "frp": frp_value,
                "acq_date": source_data.get("acq_date", hotspot_payload.get("acq_date")),
                "acq_time": source_data.get("acq_time", hotspot_payload.get("acq_time")),
                "brightness": source_data.get("brightness", hotspot_payload.get("brightness", 0)),
                "scan": source_data.get("scan", hotspot_payload.get("scan", 0)),
                "track": source_data.get("track", hotspot_payload.get("track", 0)),
                "satellite": source_data.get("satellite", hotspot_payload.get("satellite", "")),
                "instrument": source_data.get("instrument", hotspot_payload.get("instrument", "")),
                "confidence": source_data.get("confidence", hotspot_payload.get("confidence", "")),
                "version": source_data.get("version", hotspot_payload.get("version", "")),
                "daynight": source_data.get("daynight", hotspot_payload.get("daynight", "")),
            })

            if hotspot_payload.get("id") is None:
                # Current FIRMS observation not yet persisted in VERTEX.
                # Keep the ID stable enough for this live session without
                # pretending that a database row exists.
                hotspot_payload["id"] = (
                    f"firms-{lat_f:.6f}-{lon_f:.6f}-"
                    f"{hotspot_payload.get('acq_date', '')}-"
                    f"{_normalize_acq_time(hotspot_payload.get('acq_time'))}"
                )

            features.append({
                "type": "Feature",
                "id": hotspot_payload.get("id"),
                "geometry": {
                    "type": "Point",
                    "coordinates": [lon_f, lat_f],
                },
                "properties": {
                    "hotspot": hotspot_payload,
                    "classification": primary_class,
                    "osm_context": primary_osm,
                },
            })

            if len(features) >= limit:
                break

        # Highest FRP first in live mode and historical mode.
        features.sort(
            key=lambda feature: float(
                feature.get("properties", {})
                .get("hotspot", {})
                .get("frp", 0)
                or 0
            ),
            reverse=True,
        )

        return {
            "type": "FeatureCollection",
            "features": features[:limit],
        }

    except Exception as e:
        logger.error(
            "Database/FIRMS connection failed: %s",
            e,
            exc_info=True,
        )

        raise HTTPException(
            status_code=503,
            detail=f"Database/FIRMS connection failed: {e}",
        )


# =========================================================
# SINGLE HOTSPOT
# =========================================================

@router.post("/classify")
@limiter.limit("5/minute")
async def trigger_classification(
    request: Request,
    background_tasks: BackgroundTasks,
    country: str = Query("IND"),
    days: int = Query(1),
    admin_user: Any = Depends(
        verify_admin_user
    ),
):
    """
    Triggers the classification pipeline as a
    background task.
    """

    background_tasks.add_task(
        classify_and_store,
        country,
        days,
    )

    return {
        "message":
            "Classification pipeline started"
    }

@router.get("/{id}")
@limiter.limit("60/minute")
async def get_hotspot_by_id(
    request: Request,
    id: int,
):
    """
    Fetch a single hotspot from Supabase.

    Also attaches the persistent OSM cache when one
    exists for the hotspot coordinates.
    """

    try:

        response = (
            supabase_service
            .table("hotspots")
            .select(
                "*, classifications(*)"
            )
            .eq(
                "id",
                id,
            )
            .single()
            .execute()
        )

        if not response.data:

            raise HTTPException(
                status_code=404,
                detail="Hotspot not found",
            )

        hotspot = response.data

        # -------------------------------------------------
        # Persistent OSM cache
        # -------------------------------------------------

        cache_key = _coordinate_key(
            hotspot.get(
                "latitude"
            ),
            hotspot.get(
                "longitude"
            ),
        )

        if cache_key:

            try:

                cache_result = (
                    supabase_service
                    .table(
                        "osm_context_cache"
                    )
                    .select("*")
                    .eq(
                        "latitude",
                        hotspot.get(
                            "latitude"
                        ),
                    )
                    .eq(
                        "longitude",
                        hotspot.get(
                            "longitude"
                        ),
                    )
                    .order(
                        "queried_at",
                        desc=True,
                    )
                    .limit(1)
                    .execute()
                )

                cache_rows = (
                    cache_result.data
                    or []
                )

                if cache_rows:

                    hotspot[
                        "osm_context"
                    ] = (
                        _normalize_osm_context(
                            cache_rows[0]
                        )
                    )

            except Exception as cache_error:

                logger.warning(
                    "Could not load OSM cache "
                    "for hotspot %s: %s",
                    id,
                    cache_error,
                )

        return hotspot

    except HTTPException:
        raise

    except Exception as e:

        logger.error(
            "Error fetching hotspot %s: %s",
            id,
            e,
        )

        raise HTTPException(
            status_code=500,
            detail=str(e),
        )


# =========================================================
# TRIGGER CLASSIFICATION
# =========================================================




# =========================================================
# SWEEP PENDING
# =========================================================

@router.post("/sweep_pending")
async def sweep_pending_records():

    res = (
        supabase_service
        .table(
            "classifications"
        )
        .select("*")
        .limit(1)
        .execute()
    )

    if res.data:

        keys = list(
            res.data[0].keys()
        )

        return {
            "keys":
                keys
        }

    return {
        "message":
            "No data"
    }
