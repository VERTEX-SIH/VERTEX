import logging
from typing import List
from models.hotspot import FIRMSHotspot
from models.classification import ClassifiedHotspot, ClassificationResult, ClassificationEnum
from services.firms_service import fetch_realtime_hotspots
from services.osm_service import enrich_hotspot
from services.gemini_service import classify_with_gemini

logger = logging.getLogger(__name__)

def calculate_risk_score(classification: ClassificationEnum, frp: float, dist: float, conf: str) -> tuple[float, str]:
    weights = {
        ClassificationEnum.INDUSTRIAL_FIRE: 0.9,
        ClassificationEnum.GAS_FLARE: 0.7,
        ClassificationEnum.WILDFIRE_FOREST_FIRE: 0.6,
        ClassificationEnum.PERSISTENT_INDUSTRIAL_SOURCE: 0.4,
        ClassificationEnum.MINING_THERMAL_ACTIVITY: 0.5,
        ClassificationEnum.AGRICULTURAL_BURN: 0.3,
        ClassificationEnum.OTHER_THERMAL_ANOMALY: 0.2,
        ClassificationEnum.UNKNOWN_UNCERTAIN: 0.1,
        ClassificationEnum.UNKNOWN: 0.1,
    }
    
    type_weight = weights.get(classification, 0.1)
    frp_norm = min(frp / 500.0, 1.0)
    
    dist_norm = 0.0
    if dist is not None and dist > 0:
        dist_norm = min(1000.0 / dist, 1.0) if dist >= 100 else 1.0
        
    conf_score = 0.5
    if conf in ('h', 'high', '100'):
        conf_score = 1.0
    elif conf in ('l', 'low', '0'):
        conf_score = 0.2
        
    score = (type_weight * 0.4 + frp_norm * 0.3 + dist_norm * 0.2 + conf_score * 0.1) * 100
    
    if score >= 80:
        return score, 'CRITICAL'
    elif score >= 60:
        return score, 'HIGH'
    elif score >= 40:
        return score, 'MODERATE'
    else:
        return score, 'LOW'

async def classify_hotspots(hotspots: List[FIRMSHotspot]) -> List[ClassifiedHotspot]:
    """
    Classify selected FIRMS hotspots using Gemini as the primary
    classification decision-maker.

    Context enrichment remains deterministic and is performed before
    Gemini so the model receives whatever geographic/facility evidence
    is actually available.

    IMPORTANT:
    - AI_CLASSIFICATION_LIMIT is enforced by classify_and_store().
    - This function does not classify anything outside the supplied list.
    - Missing industrial context does NOT imply agricultural burning.
    """
    classified_results = []

    for hotspot in hotspots:
        if hotspot.frp is None or hotspot.frp <= 0:
            continue

        # Gather deterministic geographic/facility context first.
        # This may come from LIVE OSM, CACHED OSM, or the OFFLINE_CATALOG.
        osm_context = await enrich_hotspot(hotspot)

        # Gemini is now the primary classification decision-maker.
        classification_result = await classify_with_gemini(
            hotspot,
            osm_context
        )

        # Defensive fallback if Gemini unexpectedly returns nothing.
        if not classification_result:
            classification_result = ClassificationResult(
                classification=ClassificationEnum.UNKNOWN_UNCERTAIN,
                confidence_score=0.1,
                explanation="Gemini did not return a usable classification.",
                evidence=["AI classification result unavailable."],
                source_data={"method": "fallback"}
            )

        # Preserve provenance and facility evidence explicitly.
        if not classification_result.source_data:
            classification_result.source_data = {}

        classification_result.source_data["osm_source"] = osm_context.osm_source

        classification_result.source_data["facility_context"] = {
            "osm_source": osm_context.osm_source,
            "nearby_facilities": osm_context.nearby_facilities,
            "nearest_facility_distance": osm_context.nearest_facility_distance,
            "nearest_facility_type": osm_context.nearest_facility_type,
            "facility_count_in_radius": osm_context.facility_count_in_radius,
            "land_use_context": osm_context.land_use_context,
        }

        if osm_context.nearby_facilities:
            nearest_facility = osm_context.nearby_facilities[0]

            classification_result.source_data["facility_name"] = (
                nearest_facility.get("name")
            )

            classification_result.source_data["facility_type"] = (
                nearest_facility.get("type")
            )

            classification_result.source_data["distance_m"] = (
                nearest_facility.get("distance_m")
            )

        # Risk remains a deterministic calculation based on
        # Gemini's classification and the FIRMS/context evidence.
        risk_score, risk_level = calculate_risk_score(
            classification_result.classification,
            hotspot.frp,
            osm_context.nearest_facility_distance,
            hotspot.confidence
        )

        classification_result.risk_score = risk_score
        classification_result.risk_level = risk_level

        classified_results.append(
            ClassifiedHotspot(
                hotspot=hotspot,
                classification=classification_result,
                osm_context=osm_context
            )
        )

    return classified_results

async def classify_and_store(country: str = 'IND', days: int = 1) -> List[ClassifiedHotspot]:
    from config import settings
    from db.supabase_client import supabase_service
    
    # 1. Fetch raw nationwide dataset
    hotspots = await fetch_realtime_hotspots(country=country, days=days)
    if not hotspots:
        return []
        
    # 2. Get existing classifications from the database
    try:
        # Fetch recent records to build a fast duplicate lookup table
        recent_records = supabase_service.table("hotspots").select("id, latitude, longitude, acq_date, acq_time, classifications(id)").order("created_at", desc=True).limit(2000).execute().data
        
        db_lookup = {}
        for r in (recent_records or []):
            key = f"{r.get('latitude')}_{r.get('longitude')}_{r.get('acq_date')}_{r.get('acq_time')}"
            db_lookup[key] = r
    except Exception as e:
        logger.warning(f"Failed to fetch recent DB hotspots: {e}")
        db_lookup = {}
        
    new_hotspots_to_insert = []
    unclassified_candidates = []
    already_classified_count = 0
    
    for h in hotspots:
        key = f"{h.latitude}_{h.longitude}_{str(h.acq_date)}_{h.acq_time}"
        
        if key in db_lookup:
            db_record = db_lookup[key]
            # Temporarily attach the db_id to the pydantic model instance
            setattr(h, '_db_id', db_record["id"])
            
            if db_record.get("classifications") and len(db_record["classifications"]) > 0:
                already_classified_count += 1
            else:
                unclassified_candidates.append(h)
        else:
            new_hotspots_to_insert.append(h)
            
    # Insert new hotspots into DB to get their IDs
    if new_hotspots_to_insert:
        try:
            insert_payload = []
            for h in new_hotspots_to_insert:
                insert_payload.append({
                    "latitude": h.latitude,
                    "longitude": h.longitude,
                    "brightness": h.brightness,
                    "scan": h.scan,
                    "track": h.track,
                    "acq_date": str(h.acq_date),
                    "acq_time": h.acq_time,
                    "satellite": h.satellite,
                    "instrument": h.instrument,
                    "confidence": h.confidence,
                    "version": h.version,
                    "bright_t31": h.bright_t31,
                    "frp": h.frp,
                    "daynight": h.daynight,
                    "raw_data": h.model_dump(mode="json")
                })
            
            # Batch size chunking to avoid limits
            chunk_size = 300
            for i in range(0, len(insert_payload), chunk_size):
                chunk = insert_payload[i:i + chunk_size]
                res = supabase_service.table("hotspots").insert(chunk).execute()
                if res.data:
                    for idx, r in enumerate(res.data):
                        # Map back to the original FIRMSHotspot
                        hs = new_hotspots_to_insert[i + idx]
                        setattr(hs, '_db_id', r["id"])
                        unclassified_candidates.append(hs)
        except Exception as e:
            logger.error(f"Bulk insert of new hotspots failed: {e}")
            
    # 3. Priority Selection
    unclassified_candidates.sort(key=lambda x: x.frp, reverse=True)
    limit = getattr(settings, 'AI_CLASSIFICATION_LIMIT', 50)
    selected_for_ai = unclassified_candidates[:limit]
    remaining = len(unclassified_candidates) - len(selected_for_ai)
    
    logger.info(f"Candidates: {len(hotspots)} | Already classified: {already_classified_count} | Selected for AI: {len(selected_for_ai)} | Remaining: {remaining}")
    
    # 4. Classify ONLY the top priority ones
    classified_subset = await classify_hotspots(selected_for_ai)
    
    for c_hotspot in classified_subset:
        hs = c_hotspot.hotspot
        db_id = getattr(hs, '_db_id', None)
        if db_id:
            try:
                cls = c_hotspot.classification
                osm = c_hotspot.osm_context
                
                cls_data = {
                    "hotspot_id": db_id,
                    "classification": cls.classification.value,
                    "confidence_score": cls.confidence_score,
                    "explanation": cls.explanation,
                    "evidence": cls.evidence,
                    "risk_score": cls.risk_score,
                    "risk_level": cls.risk_level,
                    "source_data": cls.source_data,
                    "osm_context": {
                        "nearby_facilities": osm.nearby_facilities,
                        "nearest_facility_distance": osm.nearest_facility_distance,
                        "nearest_facility_type": osm.nearest_facility_type,
                        "land_use_context": osm.land_use_context,
                        "osm_source": osm.osm_source,
                        "queried_at": osm.queried_at,
                    }
                }
                supabase_service.table("classifications").insert(cls_data).execute()
                
            except Exception as e:
                logger.error(f"Failed to insert classification for hotspot {db_id}: {e}")
                
    return classified_subset
