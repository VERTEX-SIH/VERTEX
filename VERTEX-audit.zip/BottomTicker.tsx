'use client';
import { ClassifiedHotspot, CLASSIFICATION_LABELS } from '@/types';
import { useGlobalState } from '@/lib/GlobalStateContext';

interface BottomTickerProps {
  hotspots?: ClassifiedHotspot[];
}

export function BottomTicker({ hotspots = [] }: BottomTickerProps) {
  const { isDemoMode } = useGlobalState();
  const counts = hotspots.reduce((acc, h) => {
    const type = h.classification.classification;
    acc[type] = (acc[type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const statsString = Object.entries(counts)
    .map(([type, count]) => `${(CLASSIFICATION_LABELS as any)[type] || type}: ${count}`)
    .join('  |  ');

  return (
    <footer className="bg-inverse-surface h-[32px] w-full flex items-center border-t border-outline fixed bottom-0 left-0 z-50 px-4 justify-between overflow-hidden">
      <div className="font-mono text-[10px] font-bold text-inverse-primary tracking-widest uppercase flex space-x-6 shrink-0">
        <span>VERTEX PLATFORM v1.0</span>
        <span>THERMAL INTELLIGENCE</span>
      </div>
      
      <div className="flex-1 overflow-hidden mx-4">
        <div className="font-mono text-[11px] text-inverse-on-surface whitespace-nowrap animate-pulse opacity-80">
          {statsString || 'AWAITING TELEMETRY'}
        </div>
      </div>

      <div className="flex gap-4 font-mono text-[11px] text-inverse-on-surface shrink-0">
        <span className="flex items-center gap-1">
          <span className="w-2 h-2 rounded-none bg-primary animate-pulse"></span>
          SYS: ONLINE
        </span>
        <span className="flex items-center gap-1">
          <span className="w-2 h-2 rounded-none bg-primary animate-pulse"></span>
          {isDemoMode ? 'DB: DEMO CACHE' : 'DB: CONNECTED'}
        </span>
      </div>
    </footer>
  );
}
