import math
import logging
import time
from typing import List, Dict, Any
from db.supabase_client import supabase_service

logger = logging.getLogger(__name__)

# The catalog is small (36 source records) but is still fetched from Supabase,
# not the JSON file, so deployed catalog updates remain authoritative.
_cached_facilities: List[Dict[str, Any]] = []
_cache_loaded_at: float = 0.0
FACILITY_CACHE_TTL_SECONDS = 300

def invalidate_facility_cache() -> None:
    """Clear the in-process catalog cache (useful after a Supabase catalog update)."""
    global _cached_facilities, _cache_loaded_at
    _cached_facilities = []
    _cache_loaded_at = 0.0

def _get_all_facilities(force_refresh: bool = False) -> List[Dict[str, Any]]:
    global _cached_facilities, _cache_loaded_at
    cache_is_valid = _cached_facilities and (time.monotonic() - _cache_loaded_at) < FACILITY_CACHE_TTL_SECONDS
    if cache_is_valid and not force_refresh:
        return _cached_facilities
        
    try:
        res = supabase_service.table('industrial_facilities').select(
            'id,name,type,latitude,longitude,radius_m'
        ).execute()
        if res.data:
            _cached_facilities = res.data
            _cache_loaded_at = time.monotonic()
            return _cached_facilities
    except Exception as e:
        logger.error(f'Error fetching facilities from Supabase: {e}')
    
    return []

def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6371000  # radius of Earth in meters
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)
    
    a = math.sin(delta_phi/2.0)**2 + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda/2.0)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    return R * c

def find_nearby_facilities(lat: float, lon: float, radius_m: int = 5000, force_refresh: bool = False) -> List[Dict[str, Any]]:
    facilities = _get_all_facilities(force_refresh=force_refresh)
    if not facilities:
        return []
        
    nearby = []
    for fac in facilities:
        effective_radius = fac.get('radius_m')
        if effective_radius is None:
            effective_radius = radius_m
            
        dist = haversine_distance(lat, lon, fac['latitude'], fac['longitude'])
        if dist <= effective_radius:
            nearby.append({
                'name': fac['name'],
                'type': fac['type'],
                'latitude': fac['latitude'],
                'longitude': fac['longitude'],
                'distance_m': round(dist, 2)
            })
            
    # Sort by nearest first
    nearby.sort(key=lambda x: x['distance_m'])
    return nearby
