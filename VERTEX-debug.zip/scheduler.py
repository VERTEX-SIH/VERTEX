import logging
from datetime import datetime

from apscheduler.schedulers.asyncio import AsyncIOScheduler

from services.classifier import classify_and_store


logger = logging.getLogger(__name__)


scheduler = AsyncIOScheduler()


async def scheduled_classify_job():
    logger.info(
        "Starting scheduled classification job..."
    )

    try:
        await classify_and_store(
            country="IND",
            days=1,
        )

        logger.info(
            "Scheduled classification job completed successfully."
        )

    except Exception as exc:
        logger.exception(
            "Error in scheduled classification job: %s",
            exc,
        )


def setup_scheduler():
    scheduler.add_job(
        scheduled_classify_job,
        "interval",
        minutes=30,
        id="classify_job",
        replace_existing=True,
        next_run_time=datetime.now(),
        coalesce=True,
        max_instances=1,
    )

    logger.info(
        "Scheduler configured for immediate + "
        "30-minute classification runs."
    )


def start_scheduler():
    if scheduler.running:
        return

    setup_scheduler()
    scheduler.start()

    logger.info(
        "Scheduler started."
    )


def stop_scheduler():
    if scheduler.running:
        scheduler.shutdown(
            wait=False
        )

    logger.info(
        "Scheduler stopped."
    )